-------------------------------------------------------------------------------
-- Minimap.lua  (CoreUI)
-- Draws a circular 180×180 minimap in the top-right corner with player direction
-- arrow, quest indicators, clutter filtering, and zoom controls.
--
-- Layout
--   MinimapFrame        – outer panel (top-right)
--   MinimapWorldMapBtn  – small "M" button that opens the WorldMapFrame
--   MinimapZoomInBtn    – "+" button to zoom in
--   MinimapZoomOutBtn   – "-" button to zoom out
-------------------------------------------------------------------------------

local FRAME_W = 180
local FRAME_H = 180
local PADDING = 12   -- distance from screen edge
local MinimapZoom = 2.0
local ZOOM_MIN = 2.0  -- never show beyond the locally-loaded area
local ZOOM_MAX = 5.0  -- max zoom-in factor

-------------------------------------------------------------------------------
-- Helper: map world coord to minimap pixel coord
--   mmOX, mmOZ: world-space origin of the minimap (top-left corner)
--   mmWS:       world-space size of the minimap square
--   Returns sx, sy in screen pixels (absolute).
-------------------------------------------------------------------------------
local function worldToMinimap(ex, ez, mapX, mapY, mapW, mapH, mmOX, mmOZ, mmWS)
    local u = (ex - mmOX) / mmWS
    local v = (ez - mmOZ) / mmWS
    u = math.max(0, math.min(1, u))
    v = math.max(0, math.min(1, v))
    return mapX + u * mapW, mapY + v * mapH
end

-------------------------------------------------------------------------------
-- Quest Objectives Detection Helpers
-------------------------------------------------------------------------------
local KIND_MAP = {
    none = 0, player = 1, container = 2, rabbit = 3, chicken = 4,
    loot = 5, fox = 6, ore_node = 7, flower_node = 8, shopkeeper = 9, questgiver = 10
}

local MOB_DROPS = {
    [3] = { [17] = true, [19] = true, [27] = true, [14] = true }, -- rabbit drops
    [4] = { [17] = true, [16] = true, [18] = true, [22] = true, [23] = true, [12] = true }, -- chicken drops
    [6] = { [17] = true, [20] = true, [21] = true, [9] = true, [10] = true, [2] = true, [4] = true, [28] = true, [13] = true, [29] = true, [26] = true } -- fox drops
}

local function getActiveQuestObjectives()
    local active = C_Quest.GetActiveQuests()
    if not active then return nil end

    local objectives = {}

    local function getInventoryItemCount(itemId)
        if itemId == 30 then
            local stats = C_Quest.GetPlayerStats()
            return stats and stats.coins or 0
        end
        local count = 0
        if GetInventorySlotInfo then
            for slot = 1, INVENTORY_SLOTS do
                local id, c = GetInventorySlotInfo(slot)
                if id == itemId then
                    count = count + c
                end
            end
        end
        return count
    end

    for _, aq in ipairs(active) do
        if not TrackedQuests or TrackedQuests[aq.quest_id] ~= false then
            local qName, _, obj1_type, obj1_target, obj1_count, obj2_type, obj2_target, obj2_count = C_Quest.GetQuestInfo(aq.quest_id)
            if qName then
                -- Check Objective 1
                if obj1_type > 0 then
                    local current = 0
                    if obj1_type == 1 then -- KILL
                        current = aq.progress1
                    elseif obj1_type == 2 then -- GATHER
                        current = getInventoryItemCount(obj1_target)
                    end
                    if current < obj1_count then
                        table.insert(objectives, {
                            type = obj1_type,
                            target = obj1_target,
                        })
                    end
                end

                -- Check Objective 2
                if obj2_type > 0 then
                    local current = 0
                    if obj2_type == 1 then -- KILL
                        current = aq.progress2
                    elseif obj2_type == 2 then -- GATHER
                        current = getInventoryItemCount(obj2_target)
                    end
                    if current < obj2_count then
                        table.insert(objectives, {
                            type = obj2_type,
                            target = obj2_target,
                        })
                    end
                end
            end
        end
    end

    return objectives
end

local function isEntityQuestObjective(kind, ex, ez, activeObjs)
    if not activeObjs or #activeObjs == 0 then return false end
    local kindNum = KIND_MAP[kind]
    if not kindNum then return false end

    for _, obj in ipairs(activeObjs) do
        if obj.type == 1 then -- KILL
            if kindNum == obj.target then
                return true
            end
        elseif obj.type == 2 then -- GATHER
            -- Check if direct source node
            if kindNum == 7 then -- ore_node
                local is_iron = (math.floor(ex * 10.0 + ez * 10.0) % 2) == 0
                local item_id = is_iron and 21 or 20
                if item_id == obj.target then
                    return true
                end
            elseif kindNum == 8 then -- flower_node
                local is_lavender = (math.floor(ex * 10.0 + ez * 10.0) % 2) == 0
                local item_id = is_lavender and 23 or 22
                if item_id == obj.target then
                    return true
                end
            end

            -- Check if mob drop
            local drops = MOB_DROPS[kindNum]
            if drops and drops[obj.target] then
                return true
            end
        elseif obj.type == 3 then -- TALK
            if kindNum == obj.target then
                return true
            end
        end
    end

    return false
end

-------------------------------------------------------------------------------
-- Entity colour lookup

-------------------------------------------------------------------------------
local function entityColor(kind, isPlayer)
    if isPlayer                          then return 0.95, 0.20, 0.20 end  -- red
    if kind == "container"               then return 0.95, 0.87, 0.30 end  -- yellow
    if kind == "loot"                    then return 0.95, 0.63, 0.24 end  -- orange
    if kind == "player"                  then return 0.40, 0.60, 1.00 end  -- blue (other players)
    return 0.70, 0.70, 0.70                                                -- gray fallback
end

-------------------------------------------------------------------------------
-- MinimapFrame (No BasicPanelTemplate to avoid square navy background)
-------------------------------------------------------------------------------
MinimapFrame = CreateFrame("Frame", "MinimapFrame", UIParent)
MinimapFrame:SetSize(FRAME_W, FRAME_H)
MinimapFrame:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -PADDING, -PADDING)
MinimapFrame:SetFrameStrata("LOW")
MinimapFrame:SetMovable(true)
MinimapFrame:EnableMouse(true)

-------------------------------------------------------------------------------
-- OnDraw – called every frame while MinimapFrame is visible
-------------------------------------------------------------------------------
MinimapFrame:SetScript("OnDraw", function(self)
    local fx, fy, fw, fh = self:GetRect()
    local cx = fx + fw * 0.5
    local cy = fy + fh * 0.5
    local radius = fw * 0.5
    local maxDist = radius - 4

    -- 1. Blit the minimap tile texture (no-op until map is loaded)
    if GetMinimapBuilt() then
        local px, pz = UnitPosition("player")
        -- GetMinimapTextureOrigin returns the chunk-aligned world-space top-left of
        -- the texture — unlike GetMinimapBounds(1.0) which is always player-centred
        -- (making u always 0.5 and the terrain never moving).
        local texOX, texOZ, texWS = GetMinimapTextureOrigin()
        local u, v = 0.5, 0.5
        if texWS > 0 then
            u = (px - texOX) / texWS
            v = (pz - texOZ) / texWS
        end
        C_Minimap.DrawTexture(fx, fy, fw, fh, u, v, MinimapZoom)
    else
        -- Placeholder: dark tinted circle until the map arrives
        Draw2D.Circle(cx, cy, radius, 0.05, 0.07, 0.10, 1.0)
        Draw2D.Text("Loading map...", fx + fw * 0.5 - 40, fy + fh * 0.5 - 8, 12,
                    0.55, 0.55, 0.60, 1.0)
    end

    -- 2. Draw entity dots & icons

    local mmOX, mmOZ, mmWS = GetMinimapBounds(MinimapZoom)
    if mmWS > 0 then
        local px, pz = UnitPosition("player")
        local activeObjectives = getActiveQuestObjectives()

        for i = 0, MAX_ENTITIES - 1 do
            local kind, ex, ez, mhint, alive = GetEntityInfo(i)
            if alive then
                -- Determine if this entity is the local player
                local isPlayer = (kind == "player")
                              and math.abs(ex - px) < 0.5
                              and math.abs(ez - pz) < 0.5

                -- Filter out clutter NPCs (rabbits, chickens, foxes, gathering nodes)
                local shouldDraw = false
                if isPlayer then
                    shouldDraw = true
                elseif kind == "player" then
                    shouldDraw = true
                elseif kind == "container" or kind == "loot" then
                    shouldDraw = true
                elseif kind == "shopkeeper" or kind == "questgiver" then
                    shouldDraw = true
                end

                local isQuestTarget = false
                if not isPlayer and kind ~= "player" and kind ~= "shopkeeper" and kind ~= "questgiver" and kind ~= "container" and kind ~= "loot" then
                    if isEntityQuestObjective(kind, ex, ez, activeObjectives) then
                        isQuestTarget = true
                        shouldDraw = true
                    end
                end

                if shouldDraw then
                    local sx, sy = worldToMinimap(ex, ez, fx, fy, fw, fh, mmOX, mmOZ, mmWS)
                    local dx = sx - cx
                    local dy = sy - cy
                    if dx*dx + dy*dy <= maxDist*maxDist then
                        if isPlayer then
                            -- Draw player direction arrow
                            local yaw = UnitFacing("player")
                            Draw2D.Arrow(sx, sy, 9, yaw, 0.95, 0.20, 0.20, 0.95)
                        elseif isQuestTarget then
                            -- Draw quest target: cyan dot with a black border
                            Draw2D.Circle(sx, sy, 4, 0.0, 0.0, 0.0, 0.8)
                            Draw2D.Circle(sx, sy, 3, 0.1, 0.9, 0.9, 0.95)
                        elseif kind == "questgiver" then
                            -- Draw quest status indicator
                            local qStatus = C_Quest.GetNPCQuestStatus(i)
                            local txt = ""
                            local r, g, b = 0.6, 0.6, 0.6
                            if qStatus == 2 then
                                txt = "?"
                                r, g, b = 0.95, 0.85, 0.10
                            elseif qStatus == 0 then
                                txt = "!"
                                r, g, b = 0.95, 0.85, 0.10
                            elseif qStatus == 1 then
                                txt = "?"
                                r, g, b = 0.6, 0.6, 0.6
                            elseif qStatus == 3 then
                                txt = "!"
                                r, g, b = 0.6, 0.6, 0.6
                            end

                            if txt ~= "" then
                                Draw2D.Text(txt, sx - 3, sy - 6, 16, 0, 0, 0, 0.8)
                                Draw2D.Text(txt, sx - 4, sy - 7, 16, r, g, b, 1.0)
                            else
                                Draw2D.Circle(sx, sy, 3, 0.70, 0.70, 0.70, 0.92)
                            end
                        elseif kind == "shopkeeper" then
                            Draw2D.Circle(sx, sy, 4, 0.6, 0.3, 0.9, 0.95) -- purple
                        else
                            local r, g, b = entityColor(kind, false)
                            Draw2D.Circle(sx, sy, 3, r, g, b, 0.92)
                        end
                    end
                end
            end
        end
    end

    -- 3. Compass label "N" at top-centre of the circle
    Draw2D.Text("N", cx - 4, fy + 8, 13, 0.95, 0.95, 0.80, 1.0)

    -- 4. Circular border ring (gold-ish style)
    Draw2D.CircleLines(cx, cy, radius, 0.70, 0.60, 0.35, 1.0)
    Draw2D.CircleLines(cx, cy, radius - 1, 0.70, 0.60, 0.35, 0.5)

    -- 5. Draw active buffs/effects bar left of the minimap
    local stats = C_Quest.GetPlayerStats()
    local buffs = {}
    if stats then
        if stats.is_stealthed then
            table.insert(buffs, { name = "Stealth", text = "ST", color = {0.55, 0.35, 0.75}, duration = nil })
        end
        if stats.sprint_timer and stats.sprint_timer > 0 then
            table.insert(buffs, { name = "Sprint", text = "SP", color = {0.25, 0.60, 0.78}, duration = stats.sprint_timer })
        end
        if stats.war_cry_timer and stats.war_cry_timer > 0 then
            table.insert(buffs, { name = "War Cry", text = "WC", color = {0.80, 0.55, 0.15}, duration = stats.war_cry_timer })
        end
        if stats.dodge_timer and stats.dodge_timer > 0 then
            table.insert(buffs, { name = "Dodge", text = "DG", color = {0.20, 0.65, 0.80}, duration = stats.dodge_timer })
        end
        if stats.heal_timer and stats.heal_timer > 0 then
            table.insert(buffs, { name = "Regen", text = "RG", color = {0.25, 0.75, 0.35}, duration = stats.heal_timer })
        end
    end

    local bx = fx - 30
    local by = fy + 12
    for _, buff in ipairs(buffs) do
        -- Square icon background and custom border
        Draw2D.Rect(bx, by, 22, 22, 0.12, 0.12, 0.15, 0.8)
        Draw2D.RectBorder(bx, by, 22, 22, 1.5, buff.color[1], buff.color[2], buff.color[3], 0.95)
        -- Text indicator inside icon
        Draw2D.Text(buff.text, bx + 4, by + 5, 9, 1.0, 1.0, 1.0, 1.0)
        -- Duration text underneath
        if buff.duration then
            local durStr = string.format("%.1fs", buff.duration)
            Draw2D.Text(durStr, bx - 6, by + 23, 7, 0.9, 0.9, 0.9, 0.95)
        else
            Draw2D.Text("inf", bx + 4, by + 23, 7, 0.7, 0.7, 0.7, 0.8)
        end
        by = by + 34
    end
end)

-------------------------------------------------------------------------------
-- OnUpdate – scroll wheel zoom support
-------------------------------------------------------------------------------
MinimapFrame:SetScript("OnUpdate", function(self, dt)
    local fx, fy, fw, fh = self:GetRect()
    local mx, my = GetMousePosition()
    if mx >= fx and mx <= fx + fw and my >= fy and my <= fy + fh then
        local wheel = GetMouseWheelMove()
        if wheel ~= 0 then
            MinimapZoom = math.max(ZOOM_MIN, math.min(ZOOM_MAX, MinimapZoom + wheel * 0.5))
            ConsumeMouseWheel()
        end
    end
end)

-------------------------------------------------------------------------------
-- "M" button – opens/closes the WorldMapFrame
-------------------------------------------------------------------------------
local worldMapBtn = CreateFrame("Button", "MinimapWorldMapBtn", MinimapFrame,
                                "UIPanelButtonTemplate")
worldMapBtn:SetSize(22, 22)
worldMapBtn:SetPoint("TOPRIGHT", MinimapFrame, "TOPRIGHT", -2, -2)
worldMapBtn:SetText("M")
worldMapBtn:SetFrameStrata("MEDIUM")
worldMapBtn:EnableMouse(true)
worldMapBtn:SetScript("OnClick", function()
    if ToggleWorldMap then
        ToggleWorldMap()
    end
end)

-------------------------------------------------------------------------------
-- Zoom controls
-------------------------------------------------------------------------------
local zoomInBtn = CreateFrame("Button", "MinimapZoomInBtn", MinimapFrame,
                              "UIPanelButtonTemplate")
zoomInBtn:SetSize(20, 20)
zoomInBtn:SetPoint("BOTTOMRIGHT", MinimapFrame, "BOTTOMRIGHT", -24, -4)
zoomInBtn:SetText("+")
zoomInBtn:SetFrameStrata("MEDIUM")
zoomInBtn:EnableMouse(true)
zoomInBtn:SetScript("OnClick", function()
    MinimapZoom = math.min(ZOOM_MAX, MinimapZoom + 0.5)
end)

local zoomOutBtn = CreateFrame("Button", "MinimapZoomOutBtn", MinimapFrame,
                               "UIPanelButtonTemplate")
zoomOutBtn:SetSize(20, 20)
zoomOutBtn:SetPoint("BOTTOMRIGHT", MinimapFrame, "BOTTOMRIGHT", -4, -4)
zoomOutBtn:SetText("-")
zoomOutBtn:SetFrameStrata("MEDIUM")
zoomOutBtn:EnableMouse(true)
zoomOutBtn:SetScript("OnClick", function()
    MinimapZoom = math.max(ZOOM_MIN, MinimapZoom - 0.5)
end)
