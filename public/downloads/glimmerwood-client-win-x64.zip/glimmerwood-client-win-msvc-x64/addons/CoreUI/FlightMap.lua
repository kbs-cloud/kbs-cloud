-------------------------------------------------------------------------------
-- FlightMap.lua  (CoreUI)
-- Flight selection map. Opened when talking to a flightmaster.
-------------------------------------------------------------------------------

local FM_W = 500
local FM_H = 500

-- Create flight map frame
FlightMapFrame = CreateFrame("Frame", "FlightMapFrame", UIParent, "BasicPanelTemplate")
FlightMapFrame:SetSize(FM_W, FM_H)
FlightMapFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
FlightMapFrame:SetFrameStrata("HIGH")
FlightMapFrame:SetMovable(true)
FlightMapFrame:EnableMouse(true)
FlightMapFrame:Hide()

-- Background OnDraw
FlightMapFrame:SetScript("OnDraw", function(self)
    local sx, sy, sw, sh = self:GetRect()
    -- Smooth dark gradient simulation/glassmorphism
    Draw2D.Rect(sx, sy, sw, sh, 0.04, 0.05, 0.08, 0.96)
    -- Sleek glowing blue-cyan border
    Draw2D.RectBorder(sx, sy, sw, sh, 2, 0.1, 0.5, 0.8, 1.0)
    
    -- Draw title
    Draw2D.Text("Flight Map", sx + sw * 0.5 - 40, sy + 15, 16, 0.9, 0.95, 1.0, 1.0)
    
    -- Draw subtitle or instructions
    Draw2D.Text("Select a destination camp to take flight", sx + sw * 0.5 - 120, sy + sh - 25, 12, 0.6, 0.7, 0.8, 0.8)
    
    -- Draw grid lines for a nice starry map aesthetic
    local gridSpacing = 32
    local gridColor = { 0.15, 0.25, 0.4, 0.15 }
    for x = sx + 20, sx + sw - 20, gridSpacing do
        Draw2D.Line(x, sy + 40, x, sy + sh - 40, 1, unpack(gridColor))
    end
    for y = sy + 40, sy + sh - 40, gridSpacing do
        Draw2D.Line(sx + 20, y, sx + sw - 20, y, 1, unpack(gridColor))
    end
end)

-- Header Title Drag Handle
local titleHandle = CreateFrame("Button", "FlightMapTitleHandle", FlightMapFrame)
titleHandle:SetPoint("TOPLEFT", FlightMapFrame, "TOPLEFT", 0, 0)
titleHandle:SetPoint("TOPRIGHT", FlightMapFrame, "TOPRIGHT", -32, 0)
titleHandle:SetHeight(32)
titleHandle:EnableMouse(true)
titleHandle:SetMovable(true)
titleHandle:SetScript("OnClick", function()
    FlightMapFrame:StartMoving()
end)

-- Close Button
local closeBtn = CreateFrame("Button", "FlightMapCloseBtn", FlightMapFrame, "UIPanelButtonTemplate")
closeBtn:SetSize(22, 22)
closeBtn:SetPoint("TOPRIGHT", FlightMapFrame, "TOPRIGHT", -8, -8)
closeBtn:SetText("x")
closeBtn:SetScript("OnClick", function()
    FlightMapFrame:Hide()
end)

-- Draw local map display inside FlightMapFrame
-- This contains the center current node and connecting path lines
local mapDisplay = CreateFrame("Frame", "FlightMapDisplay", FlightMapFrame)
mapDisplay:SetSize(480, 425)
mapDisplay:SetPoint("TOPLEFT", FlightMapFrame, "TOPLEFT", 10, -40)

-- Button pool (32 buttons) childed to mapDisplay for correct layering and alignment
local flightButtons = {}
for i = 1, 32 do
    local btn = CreateFrame("Button", "FlightMapNodeBtn" .. i, mapDisplay)
    btn:SetSize(16, 16)
    btn:Hide()
    btn:EnableMouse(true)
    btn:SetHighlightColor(0, 0, 0, 0)
    
    btn:SetScript("OnEnter", function(self)
        if GameTooltip then
            GameTooltip:SetPoint("BOTTOMLEFT", self, "TOPRIGHT", 8, 8)
            GameTooltip.title:SetText(self.name)
            GameTooltip.desc:SetText(string.format("Distance: %dm\nClick to take flight!", math.floor(self.distance)))
            
            -- Set custom tooltip size
            local w1 = #self.name * 8
            local w2 = 25 * 5.5
            local w = math.max(w1, w2, 120) + 16
            GameTooltip:SetSize(w, 44)
            GameTooltip:Show()
        end
    end)
    
    btn:SetScript("OnLeave", function(self)
        if GameTooltip then GameTooltip:Hide() end
    end)
    
    btn:SetScript("OnClick", function(self, button)
        if button == "Left" then
            if GameTooltip then GameTooltip:Hide() end
            C_Flight.TakeFlight(self.cx, self.cy)
            FlightMapFrame:Hide()
        end
    end)
    
    flightButtons[i] = btn
end

-- Source node Details
local srcNode = { cx = 0, cy = 0, x = 0, z = 0, name = "" }
local connectedPoints = {}
local currentScale = 0.35

mapDisplay:SetScript("OnDraw", function(self)
    if not FlightMapFrame:IsShown() then return end
    
    local sx, sy, sw, sh = self:GetRect()
    local cx, cy = sx + sw * 0.5, sy + sh * 0.5
    
    -- 1. Draw central starting flightmaster node (bright green/cyan)
    Draw2D.Circle(cx, cy, 9, 0.2, 0.9, 0.4, 0.95)
    Draw2D.CircleLines(cx, cy, 14, 0.2, 0.9, 0.4, 0.45)
    
    -- Draw name of the current camp
    Draw2D.Text(srcNode.name or "Current Camp", cx - 60, cy - 22, 12, 0.4, 0.9, 0.6, 0.9)
    
    -- 2. Draw connecting paths and destination node circles
    local scale = currentScale
    
    for i, pt in ipairs(connectedPoints) do
        local dx = pt.x - srcNode.x
        local dz = pt.z - srcNode.z
        
        -- Screen destination coords
        local tx = cx + dx * scale
        local ty = cy + dz * scale
        
        -- Draw connection line
        Draw2D.Line(cx, cy, tx, ty, 2, 0.1, 0.6, 0.9, 0.4)
        
        -- Draw a small arrowhead or direction marker along the path
        local midx = cx + dx * scale * 0.5
        local midy = cy + dz * scale * 0.5
        Draw2D.Circle(midx, midy, 2, 0.1, 0.6, 0.9, 0.6)
        
        -- Draw destination node circle (check hover status from the corresponding button)
        local btn = flightButtons[i]
        local isHovered = false
        if btn then
            local bx, by, bw, bh = btn:GetRect()
            local mx, my = GetMousePosition()
            if bx and by and bw and bh and mx >= bx and mx <= bx + bw and my >= by and my <= by + bh then
                isHovered = true
            end
        end
        
        if isHovered then
            -- Hovered: glowing gold circle
            Draw2D.Circle(tx, ty, 9, 1.0, 0.8, 0.1, 0.95)
            Draw2D.CircleLines(tx, ty, 14, 1.0, 0.8, 0.1, 0.5)
        else
            -- Normal: glowing cyan/blue circle
            Draw2D.Circle(tx, ty, 7, 0.1, 0.6, 0.9, 0.9)
            Draw2D.CircleLines(tx, ty, 11, 0.1, 0.6, 0.9, 0.4)
        end
    end
end)

-- Refresh flight points and position buttons dynamically
local function refreshFlightMap()
    local fm = C_Flight.GetCurrentFlightmaster()
    if not fm then
        FlightMapFrame:Hide()
        return
    end
    
    srcNode.cx = fm.cx
    srcNode.cy = fm.cy
    srcNode.x = fm.x
    srcNode.z = fm.z
    srcNode.name = fm.name
    
    connectedPoints = C_Flight.GetConnectedFlightpoints() or {}
    
    -- Calculate dynamic scale to fit all points
    local max_coord = 0
    for _, pt in ipairs(connectedPoints) do
        local dx = math.abs(pt.x - srcNode.x)
        local dz = math.abs(pt.z - srcNode.z)
        max_coord = math.max(max_coord, dx, dz)
    end
    if max_coord > 0 then
        currentScale = math.min(0.35, 180.0 / max_coord)
    else
        currentScale = 0.35
    end
    local scale = currentScale
    
    -- Hide all buttons first
    for _, btn in ipairs(flightButtons) do
        btn:Hide()
    end
    
    -- Reposition and show buttons for each connected node
    local wx, wy, ww, wh = mapDisplay:GetRect()
    if not ww or ww == 0 then ww = 480 end
    if not wh or wh == 0 then wh = 425 end
    
    for i, pt in ipairs(connectedPoints) do
        if i <= #flightButtons then
            local btn = flightButtons[i]
            btn.cx = pt.cx
            btn.cy = pt.cy
            btn.name = pt.name
            btn.distance = pt.distance
            
            local dx = pt.x - srcNode.x
            local dz = pt.z - srcNode.z
            
            -- Target positions relative to mapDisplay TOPLEFT
            local ox = (ww * 0.5) + dx * scale
            local oy = -((wh * 0.5) + dz * scale)
            
            btn:SetPoint("CENTER", mapDisplay, "TOPLEFT", ox, oy)
            btn:Show()
        end
    end
end

-- Event registration
FlightMapFrame:RegisterEvent("FLIGHT_MAP_OPEN")
FlightMapFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "FLIGHT_MAP_OPEN" then
        FlightMapFrame:Show()
        refreshFlightMap()
    end
end)
