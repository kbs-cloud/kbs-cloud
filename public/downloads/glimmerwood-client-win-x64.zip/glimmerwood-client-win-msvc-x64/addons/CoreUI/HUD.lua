-------------------------------------------------------------------------------
-- HUD.lua  (CoreUI)
-- In-game heads-up display: player health bar, stamina bar, and an equipment
-- / derived-stats readout.
--
-- Layout (bottom-left area)
--
--   PlayerFrame  220×70
--   ├─ hpLabel        FontString  "HP"
--   ├─ hpBar          StatusBar   (red)
--   ├─ spLabel        FontString  "SP"
--   ├─ spBar          StatusBar   (blue – placeholder, always full)
--   └─ statsText      FontString  equipment + derived stats
-------------------------------------------------------------------------------

local PANEL_W = 220
local PANEL_H = 148
local BAR_H   = 12
local MARGIN  = 8    -- inner padding
local BOTTOM_OFFSET = -80   -- see anchor note below

-------------------------------------------------------------------------------
-- Anchor note
-- SetPoint("TOPLEFT", UIParent, "TOPLEFT", ox, oy)
-- Places the panel 80 pixels below the top-left to clear the debug overlay.
-------------------------------------------------------------------------------

PlayerFrame = CreateFrame("Frame", "PlayerFrame", UIParent, "BasicPanelTemplate")
PlayerFrame:SetSize(PANEL_W, PANEL_H)
PlayerFrame:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 12, -80)
PlayerFrame:SetFrameStrata("LOW")
PlayerFrame:SetMovable(true)
PlayerFrame:EnableMouse(true)

-------------------------------------------------------------------------------
-- HP label
-------------------------------------------------------------------------------
local hpLabel = PlayerFrame:CreateFontString(nil, "HIGH")
hpLabel:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", MARGIN, -MARGIN)
hpLabel:SetSize(PANEL_W - MARGIN * 2, 14)
hpLabel:SetFont(12)
hpLabel:SetJustifyH("LEFT")
hpLabel:SetTextColor(0.90, 0.35, 0.30)
hpLabel:SetText("HP  0 / 0")

local combatIndicator = PlayerFrame:CreateFontString(nil, "HIGH")
combatIndicator:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 120, -MARGIN)
combatIndicator:SetSize(80, 14)
combatIndicator:SetFont(11)
combatIndicator:SetJustifyH("LEFT")
combatIndicator:SetTextColor(1.0, 0.2, 0.2)
combatIndicator:SetText("⚡ IN COMBAT")
combatIndicator:Hide()

-------------------------------------------------------------------------------
-- HP bar
-------------------------------------------------------------------------------
local hpBar = CreateFrame("StatusBar", "PlayerHPBar", PlayerFrame)
hpBar:SetPoint("TOPLEFT",     PlayerFrame, "TOPLEFT",     MARGIN,           -(MARGIN + 16))
hpBar:SetPoint("TOPRIGHT",    PlayerFrame, "TOPRIGHT",    -MARGIN,          -(MARGIN + 16))
hpBar:SetHeight(BAR_H)
hpBar:SetMinMaxValues(0, 1)
hpBar:SetValue(1)
hpBar:SetStatusBarColor(0.78, 0.24, 0.20, 1.0)   -- dark red

-------------------------------------------------------------------------------
-- SP label (placeholder – stamina / mana not yet wired server-side)
-------------------------------------------------------------------------------
local spLabel = PlayerFrame:CreateFontString(nil, "HIGH")
spLabel:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", MARGIN, -(MARGIN + 16 + BAR_H + 6))
spLabel:SetSize(PANEL_W - MARGIN * 2, 14)
spLabel:SetFont(12)
spLabel:SetJustifyH("LEFT")
spLabel:SetTextColor(0.30, 0.55, 0.90)
spLabel:SetText("SP  --")

-------------------------------------------------------------------------------
-- SP bar (always full until SP is implemented)
-------------------------------------------------------------------------------
local spBar = CreateFrame("StatusBar", "PlayerSPBar", PlayerFrame)
spBar:SetPoint("TOPLEFT",  PlayerFrame, "TOPLEFT",  MARGIN,  -(MARGIN + 16 + BAR_H + 6 + 16))
spBar:SetPoint("TOPRIGHT", PlayerFrame, "TOPRIGHT", -MARGIN, -(MARGIN + 16 + BAR_H + 6 + 16))
spBar:SetHeight(BAR_H)
spBar:SetMinMaxValues(0, 1)
spBar:SetValue(1)
spBar:SetStatusBarColor(0.24, 0.44, 0.80, 1.0)   -- blue

-------------------------------------------------------------------------------
-- XP label
-------------------------------------------------------------------------------
local xpLabel = PlayerFrame:CreateFontString(nil, "HIGH")
xpLabel:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", MARGIN, -(MARGIN + 16 + BAR_H + 6 + 16 + BAR_H + 6))
xpLabel:SetSize(PANEL_W - MARGIN * 2, 14)
xpLabel:SetFont(12)
xpLabel:SetJustifyH("LEFT")
xpLabel:SetTextColor(0.80, 0.40, 0.85) -- purple/pinkish XP color
xpLabel:SetText("Level 1  (XP 0 / 100)")

-------------------------------------------------------------------------------
-- XP bar
-------------------------------------------------------------------------------
local xpBar = CreateFrame("StatusBar", "PlayerXPBar", PlayerFrame)
xpBar:SetPoint("TOPLEFT",  PlayerFrame, "TOPLEFT",  MARGIN,  -(MARGIN + 16 + BAR_H + 6 + 16 + BAR_H + 6 + 16))
xpBar:SetPoint("TOPRIGHT", PlayerFrame, "TOPRIGHT", -MARGIN, -(MARGIN + 16 + BAR_H + 6 + 16 + BAR_H + 6 + 16))
xpBar:SetHeight(BAR_H)
xpBar:SetMinMaxValues(0, 100)
xpBar:SetValue(0)
xpBar:SetStatusBarColor(0.60, 0.20, 0.70, 1.0)   -- purple

-------------------------------------------------------------------------------
-- Info Label (Merged from top-left infoFrame: Position, Tile)
-------------------------------------------------------------------------------
local infoLabel = PlayerFrame:CreateFontString(nil, "HIGH")
infoLabel:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", MARGIN, -(MARGIN + 16 + BAR_H + 6 + 16 + BAR_H + 6 + 16 + BAR_H + 6))
infoLabel:SetSize(PANEL_W - MARGIN * 2, 30)
infoLabel:SetFont(11)
infoLabel:SetJustifyH("LEFT")
infoLabel:SetTextColor(0.85, 0.85, 0.80)
infoLabel:SetText("Pos: --, --\nTile: --")

-------------------------------------------------------------------------------
-- Local state cache
-------------------------------------------------------------------------------
local cachedHP    = 0
local cachedHPMax = 20
local cachedSP    = 100
local cachedSPMax = 100
local cachedLevel = 1
local cachedXP    = 0
local cachedXPMax = 100
local combatTimer = 0
local infoUpdateAccum = 0.0

-------------------------------------------------------------------------------
-- Refresh HP bar + label immediately
-------------------------------------------------------------------------------
local function refreshHP(hp, hpMax)
    cachedHP    = hp
    cachedHPMax = hpMax > 0 and hpMax or 1
    hpBar:SetMinMaxValues(0, cachedHPMax)
    hpBar:SetValue(cachedHP)
    hpLabel:SetText(string.format("HP  %d / %d", cachedHP, cachedHPMax))

    -- Tint bar brighter red when critical (< 30 %)
    if cachedHP / cachedHPMax < 0.30 then
        hpBar:SetStatusBarColor(1.00, 0.20, 0.15, 1.0)
    elseif cachedHP / cachedHPMax < 0.60 then
        hpBar:SetStatusBarColor(0.90, 0.45, 0.10, 1.0)
    else
        hpBar:SetStatusBarColor(0.78, 0.24, 0.20, 1.0)
    end
end

-------------------------------------------------------------------------------
-- Refresh SP bar + label immediately
-------------------------------------------------------------------------------
local function refreshSP(sp, spMax)
    cachedSP    = sp
    cachedSPMax = spMax > 0 and spMax or 1
    spBar:SetMinMaxValues(0, cachedSPMax)
    spBar:SetValue(cachedSP)
    spLabel:SetText(string.format("SP  %d / %d", cachedSP, cachedSPMax))
end

-------------------------------------------------------------------------------
-- Refresh XP bar + label immediately
-------------------------------------------------------------------------------
local function refreshXP(level, xp, xpMax)
    cachedLevel = level
    cachedXP    = xp
    cachedXPMax = xpMax > 0 and xpMax or 100
    xpBar:SetMinMaxValues(0, cachedXPMax)
    xpBar:SetValue(cachedXP)
    xpLabel:SetText(string.format("Level %d  (XP %d / %d)", cachedLevel, cachedXP, cachedXPMax))
end



-------------------------------------------------------------------------------
-- Event handler
-------------------------------------------------------------------------------
PlayerFrame:RegisterEvent("PLAYER_HP_UPDATE")
PlayerFrame:RegisterEvent("PLAYER_SP_UPDATE")
PlayerFrame:RegisterEvent("PLAYER_XP_UPDATE")
PlayerFrame:RegisterEvent("PLAYER_SPAWNED")
PlayerFrame:RegisterEvent("COMBAT_EVENT")
PlayerFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_HP_UPDATE" then
        local hp, hpMax = ...
        refreshHP(hp, hpMax)
        if hp <= 0 then
            CancelCasting()
        end
    elseif event == "PLAYER_SP_UPDATE" then
        local sp, spMax = ...
        refreshSP(sp, spMax)
    elseif event == "PLAYER_XP_UPDATE" then
        local lvl, xp, xpMax = ...
        refreshXP(lvl, xp, xpMax)
    elseif event == "PLAYER_SPAWNED" then
        -- Re-read HP and SP after a respawn
        CancelCasting()
        refreshHP(UnitHealth("player"), UnitHealthMax("player"))
        refreshSP(UnitPower("player"), UnitPowerMax("player"))
        refreshXP(UnitLevel("player"), UnitXP("player"), UnitXPMax("player"))
    elseif event == "COMBAT_EVENT" then
        local ev_type, npc_idx, npc_kind, damage = ...
        if ev_type == 0 or ev_type == 1 then
            combatTimer = 5.0
            combatIndicator:Show()
        end
    end
end)

-------------------------------------------------------------------------------
-- Casting Bar Frame
-------------------------------------------------------------------------------
CastingBarFrame = CreateFrame("Frame", "CastingBarFrame", UIParent, "BasicPanelTemplate")
CastingBarFrame:SetSize(220, 28)
CastingBarFrame:SetPoint("CENTER", UIParent, "CENTER", 0, -120) -- center, slightly below character
CastingBarFrame:Hide()

-- Cast bar title (spell name)
CastingBarFrame.text = CastingBarFrame:CreateFontString(nil, "HIGH")
CastingBarFrame.text:SetPoint("TOP", CastingBarFrame, "TOP", 0, -2)
CastingBarFrame.text:SetFont(11)
CastingBarFrame.text:SetTextColor(1.0, 1.0, 1.0)
CastingBarFrame.text:SetText("")

-- Cast bar status bar
CastingBarFrame.bar = CreateFrame("StatusBar", nil, CastingBarFrame)
CastingBarFrame.bar:SetPoint("TOPLEFT", CastingBarFrame, "TOPLEFT", 4, -14)
CastingBarFrame.bar:SetPoint("BOTTOMRIGHT", CastingBarFrame, "BOTTOMRIGHT", -4, 4)
CastingBarFrame.bar:SetMinMaxValues(0, 1)
CastingBarFrame.bar:SetValue(0)
CastingBarFrame.bar:SetStatusBarColor(1.0, 0.7, 0.0, 1.0) -- Gold/Yellow cast bar

local currentCastAbilityId = 0
local currentCastTimer = 0
local currentCastDuration = 0
local currentCastCallback = nil
local lastPlayerX, lastPlayerZ = 0, 0

function StartCasting(abilityId, duration, name, callback)
    currentCastAbilityId = abilityId
    currentCastTimer = 0
    currentCastDuration = duration
    currentCastCallback = callback
    lastPlayerX, lastPlayerZ = UnitPosition("player")
    
    CastingBarFrame.text:SetText(name)
    CastingBarFrame.bar:SetMinMaxValues(0, duration)
    CastingBarFrame.bar:SetValue(0)
    CastingBarFrame:Show()
end

function CancelCasting()
    currentCastAbilityId = 0
    currentCastCallback = nil
    CastingBarFrame:Hide()
end

-------------------------------------------------------------------------------
-- OnUpdate – handle combat indicator fading and casting progress
-------------------------------------------------------------------------------
PlayerFrame:SetScript("OnUpdate", function(self, dt)
    if combatTimer and combatTimer > 0 then
        combatTimer = combatTimer - dt
        if combatTimer <= 0 then
            combatIndicator:Hide()
        else
            combatIndicator:Show()
            local opacity = 0.5 + 0.5 * math.sin(GetTime() * 8.0)
            combatIndicator:SetTextColor(1.0, 0.2, 0.2, opacity)
        end
    end

    if currentCastAbilityId > 0 then
        currentCastTimer = currentCastTimer + dt
        if currentCastTimer >= currentCastDuration then
            local cb = currentCastCallback
            CastingBarFrame:Hide()
            currentCastAbilityId = 0
            currentCastCallback = nil
            if cb then cb() end
        else
            CastingBarFrame.bar:SetValue(currentCastTimer)
            -- Check if player moved
            local px, pz = UnitPosition("player")
            local dx = px - lastPlayerX
            local dz = pz - lastPlayerZ
            if dx*dx + dz*dz > 0.01 then
                CancelCasting()
            end
        end
    end

    infoUpdateAccum = infoUpdateAccum + dt
    if infoUpdateAccum >= 0.25 then
        infoUpdateAccum = 0.0
        local x, z = UnitPosition("player")
        local tile = GetTileAt(x, z)
        infoLabel:SetText(string.format("Pos: %.1f,  %.1f\nTile: %s", x, z, tile or "?"))
    end
end)

-------------------------------------------------------------------------------
-- Seed initial values
-------------------------------------------------------------------------------
refreshHP(UnitHealth("player"), UnitHealthMax("player"))
refreshXP(UnitLevel("player"), UnitXP("player"), UnitXPMax("player"))

-------------------------------------------------------------------------------
-- Combat/Chat Log Frame (Movable, Resizable, Scrollable)
-------------------------------------------------------------------------------
local LOG_W = 280
local LOG_H = 100
local LOG_LINE_H = 13
local MAX_LOG_HISTORY = 100

local activeChannel = "General"
local chatTabs = {}

local CombatLogFrame = CreateFrame("Frame", "CombatLogFrame", UIParent, "BasicPanelTemplate")
CombatLogFrame:SetSize(LOG_W, LOG_H)
CombatLogFrame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 12, 132)  -- raised for dual bottom bars
CombatLogFrame:SetFrameStrata("LOW")
CombatLogFrame:SetMovable(true)
CombatLogFrame:SetResizable(true)
CombatLogFrame:EnableMouse(true)

local logTitle = CombatLogFrame:CreateFontString(nil, "HIGH")
logTitle:SetPoint("TOPLEFT", CombatLogFrame, "TOPLEFT", 8, -6)
logTitle:SetSize(LOG_W - 16, 12)
logTitle:SetFont(10)
logTitle:SetJustifyH("LEFT")
logTitle:SetTextColor(0.6, 0.6, 0.7)
logTitle:SetText("MESSAGE LOG")
logTitle:Hide() -- Hide default title to show tabs instead

-- Channel Tabs
local channels = {"General", "Say", "Yell", "Party"}
for i, name in ipairs(channels) do
    local tab = CreateFrame("Button", "ChatTab_" .. name, CombatLogFrame, "UIPanelButtonTemplate")
    tab:SetSize(52, 18)
    tab:SetPoint("TOPLEFT", CombatLogFrame, "TOPLEFT", 8 + (i - 1) * 58, -6)
    tab:SetText(name)
    tab:SetFont(10)
    tab:SetFrameStrata("LOW")
    
    if name == activeChannel then
        tab:SetBackdropColor(0.25, 0.35, 0.55, 0.95)
    else
        tab:SetBackdropColor(0.12, 0.15, 0.22, 0.8)
    end
    
    tab:SetScript("OnClick", function()
        activeChannel = name
        for _, t in ipairs(chatTabs) do
            if t.chan == activeChannel then
                t:SetBackdropColor(0.25, 0.35, 0.55, 0.95)
            else
                t:SetBackdropColor(0.12, 0.15, 0.22, 0.8)
            end
        end
        scrollOffset = 0
        updateLogDisplay()
    end)
    tab.chan = name
    table.insert(chatTabs, tab)
end

-- Scrollbar components
local ScrollTrack = CreateFrame("Frame", "CombatLogScrollTrack", CombatLogFrame)
ScrollTrack:SetBackdropColor(0.05, 0.05, 0.08, 0.6)
ScrollTrack:SetBackdropBorderColor(0.2, 0.2, 0.25)
ScrollTrack:EnableMouse(true)

local ScrollThumb = CreateFrame("Button", "CombatLogScrollThumb", ScrollTrack)
ScrollThumb:SetBackdropColor(0.3, 0.3, 0.4, 0.9)
ScrollThumb:SetBackdropBorderColor(0.5, 0.5, 0.6)
ScrollThumb:EnableMouse(true)

local logMessages = {}
local logLines = {}
local scrollOffset = 0
local draggingThumb = false
local dragStartY = 0
local dragStartScroll = 0

local function getOrCreateLine(index)
    if not logLines[index] then
        local line = CombatLogFrame:CreateFontString(nil, "HIGH")
        line:SetFont(10)
        line:SetJustifyH("LEFT")
        logLines[index] = line
    end
    return logLines[index]
end

local function wrapText(text, maxLen)
    local lines = {}
    local currentLine = ""
    local currentWord = ""
    
    -- Iterate through characters
    for i = 1, #text do
        local c = string.sub(text, i, i)
        if c == " " or c == "\n" then
            -- Word boundary
            if string.len(currentLine) + string.len(currentWord) + (currentLine == "" and 0 or 1) <= maxLen then
                if currentLine == "" then
                    currentLine = currentWord
                else
                    currentLine = currentLine .. " " .. currentWord
                end
            else
                if currentLine ~= "" then
                    table.insert(lines, currentLine)
                end
                currentLine = currentWord
                -- If the word itself is too long
                while string.len(currentLine) > maxLen do
                    table.insert(lines, string.sub(currentLine, 1, maxLen))
                    currentLine = string.sub(currentLine, maxLen + 1)
                end
            end
            currentWord = ""
            if c == "\n" then
                table.insert(lines, currentLine)
                currentLine = ""
            end
        else
            currentWord = currentWord .. c
        end
    end
    
    -- Handle last word
    if currentWord ~= "" then
        if string.len(currentLine) + string.len(currentWord) + (currentLine == "" and 0 or 1) <= maxLen then
            if currentLine == "" then
                currentLine = currentWord
            else
                currentLine = currentLine .. " " .. currentWord
            end
        else
            if currentLine ~= "" then
                table.insert(lines, currentLine)
            end
            currentLine = currentWord
            while string.len(currentLine) > maxLen do
                table.insert(lines, string.sub(currentLine, 1, maxLen))
                currentLine = string.sub(currentLine, maxLen + 1)
            end
        end
    end
    if currentLine ~= "" then
        table.insert(lines, currentLine)
    end
    
    return lines
end

local function updateLogDisplay()
    local w = CombatLogFrame:GetWidth()
    local h = CombatLogFrame:GetHeight()
    
    -- Filter messages based on active tab channel
    local visibleMsgs = {}
    for _, msg in ipairs(logMessages) do
        if activeChannel == "General" or msg.channel == "General" then
            table.insert(visibleMsgs, msg)
        elseif activeChannel == msg.channel then
            table.insert(visibleMsgs, msg)
        end
    end
    
    -- Dynamically wrap messages into lines
    local charWidth = 5.7 -- estimated average character width for size 10 font
    local maxChars = math.floor((w - 24) / charWidth)
    if maxChars < 10 then maxChars = 10 end
    
    local allLines = {}
    for _, msg in ipairs(visibleMsgs) do
        local wrapped = wrapText(msg.text, maxChars)
        for _, wl in ipairs(wrapped) do
            table.insert(allLines, { text = wl, r = msg.r, g = msg.g, b = msg.b })
        end
    end
    
    local visibleLines = math.floor((h - 34) / LOG_LINE_H)
    if visibleLines < 1 then visibleLines = 1 end

    local numLines = #allLines
    local maxScroll = math.max(0, numLines - visibleLines)
    
    if scrollOffset > maxScroll then
        scrollOffset = maxScroll
    end
    if scrollOffset < 0 then
        scrollOffset = 0
    end

    -- Update/draw visible lines
    for i = 1, math.max(visibleLines, #logLines) do
        local line = getOrCreateLine(i)
        if i <= visibleLines then
            local lineIndex = numLines - scrollOffset - (visibleLines - i)
            local lineData = allLines[lineIndex]
            if lineData then
                line:SetPoint("TOPLEFT", CombatLogFrame, "TOPLEFT", 8, -32 - (i - 1) * LOG_LINE_H)
                line:SetSize(w - 24, LOG_LINE_H)
                line:SetText(lineData.text)
                line:SetTextColor(lineData.r, lineData.g, lineData.b)
                line:Show()
            else
                line:Hide()
            end
        else
            line:Hide()
        end
    end

    -- Position scrollbar
    if maxScroll <= 0 then
        ScrollTrack:Hide()
    else
        ScrollTrack:Show()
        ScrollTrack:SetPoint("TOPRIGHT", CombatLogFrame, "TOPRIGHT", -6, -32)
        ScrollTrack:SetSize(10, h - 38)

        local trackH = h - 38
        local thumbH = math.max(15, (visibleLines / numLines) * trackH)
        ScrollThumb:SetSize(10, thumbH)

        local ratio = 1 - (scrollOffset / maxScroll)
        local thumbY = ratio * (trackH - thumbH)
        ScrollThumb:SetPoint("TOPLEFT", ScrollTrack, "TOPLEFT", 0, -thumbY)
    end
end

local function addLogMessage(text, r, g, b, channel)
    channel = channel or "General"
    table.insert(logMessages, { text = text, r = r, g = g, b = b, channel = channel })
    if #logMessages > MAX_LOG_HISTORY then
        table.remove(logMessages, 1)
    end
    updateLogDisplay()
end

local EntityKindNames = {
    [1] = "Player",
    [2] = "Chest",
    [3] = "Rabbit",
    [4] = "Chicken",
    [5] = "Loot",
    [6] = "Fox"
}

local lastXP, lastLvl, lastXPMax

CombatLogFrame:RegisterEvent("COMBAT_EVENT")
CombatLogFrame:RegisterEvent("PLAYER_SPAWNED")
CombatLogFrame:RegisterEvent("PLAYER_XP_UPDATE")
CombatLogFrame:RegisterEvent("LOOT_RECEIVED")

CombatLogFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "COMBAT_EVENT" then
        local ev_type, npc_idx, npc_kind, damage = ...
        local name = EntityKindNames[npc_kind] or "Target"
        if ev_type == 0 then
            addLogMessage(string.format("You hit %s for %d damage.", name, damage), 0.95, 0.95, 0.3)
        elseif ev_type == 1 then
            addLogMessage(string.format("%s hits you for %d damage!", name, damage), 1.0, 0.25, 0.25)
        elseif ev_type == 2 then
            addLogMessage(string.format("%s has been slain.", name), 0.3, 0.9, 0.3)
        elseif ev_type == 3 then
            addLogMessage("YOU HAVE LEVELED UP!", 1.0, 0.84, 0.0)
        end
    elseif event == "PLAYER_SPAWNED" then
        addLogMessage("You have spawned.", 0.6, 0.6, 0.95)
    elseif event == "PLAYER_XP_UPDATE" then
        local lvl, xp, xpMax = ...
        if lastXP and xp > lastXP and lvl == lastLvl then
            addLogMessage(string.format("You gained %d experience.", xp - lastXP), 0.80, 0.40, 0.85)
        elseif lastXP and lvl > lastLvl then
            local xpGained = (lastXPMax - lastXP) + xp
            addLogMessage(string.format("You gained %d experience.", xpGained), 0.80, 0.40, 0.85)
        end
        lastXP = xp
        lastLvl = lvl
        lastXPMax = xpMax
    elseif event == "LOOT_RECEIVED" then
        local itemId, count = ...
        local name = GetItemInfo(itemId) or "Unknown Item"
        if count > 1 then
            addLogMessage(string.format("You looted: %s x%d.", name, count), 0.0, 0.75, 1.0)
        else
            addLogMessage(string.format("You looted: %s.", name), 0.0, 0.75, 1.0)
        end
    end
end)

local isTyping = false
local inputText = ""

local ChatEditFrame = CreateFrame("Frame", "ChatEditFrame", CombatLogFrame, "BasicPanelTemplate")
ChatEditFrame:SetSize(LOG_W, 24)
ChatEditFrame:SetPoint("TOPLEFT", CombatLogFrame, "BOTTOMLEFT", 0, -4)
ChatEditFrame:SetFrameStrata("LOW")
ChatEditFrame:Hide()

local ChatEditText = ChatEditFrame:CreateFontString(nil, "HIGH")
ChatEditText:SetPreEscaped(true)
ChatEditText:SetPoint("TOPLEFT", ChatEditFrame, "TOPLEFT", 8, -6)
ChatEditText:SetSize(LOG_W - 16, 12)
ChatEditText:SetFont(10)
ChatEditText:SetJustifyH("LEFT")
ChatEditText:SetTextColor(0.9, 0.9, 0.9)
ChatEditText:SetText("")

local function submitChatMessage(text)
    local channel = activeChannel
    local msg = text
    
    -- Check for prefix commands
    if string.sub(text, 1, 5) == "/say " then
        channel = "Say"
        msg = string.sub(text, 6)
    elseif string.sub(text, 1, 3) == "/s " then
        channel = "Say"
        msg = string.sub(text, 4)
    elseif string.sub(text, 1, 6) == "/yell " then
        channel = "Yell"
        msg = string.sub(text, 7)
    elseif string.sub(text, 1, 3) == "/y " then
        channel = "Yell"
        msg = string.sub(text, 4)
    elseif string.sub(text, 1, 7) == "/party " then
        channel = "Party"
        msg = string.sub(text, 8)
    elseif string.sub(text, 1, 3) == "/p " then
        channel = "Party"
        msg = string.sub(text, 4)
    elseif string.sub(text, 1, 1) == "/" then
        addLogMessage("Unknown command: " .. text, 1.0, 0.4, 0.4, "General")
        return
    end
    
    -- If active channel is General, default to Say
    if channel == "General" then
        channel = "Say"
    end
    
    local player_name = UnitName("player") or "Player"
    local formatted = string.format("[%s] %s: %s", channel, player_name, msg)
    
    local r, g, b = 0.85, 0.85, 0.9
    if channel == "Say" then
        r, g, b = 0.4, 0.9, 0.4
    elseif channel == "Yell" then
        r, g, b = 1.0, 0.4, 0.2
    elseif channel == "Party" then
        r, g, b = 0.9, 0.4, 0.9
    end
    
    addLogMessage(formatted, r, g, b, channel)
end

local lastW, lastH = LOG_W, LOG_H
CombatLogFrame:SetScript("OnUpdate", function(self, dt)
    local w = self:GetWidth()
    local h = self:GetHeight()

    if w ~= lastW or h ~= lastH then
        lastW, lastH = w, h
        ChatEditFrame:SetWidth(w)
        ChatEditText:SetWidth(w - 16)
        updateLogDisplay()
    end

    -- Chat text editing logic
    if isTyping then
        -- Blink cursor
        local cursor = (math.floor(GetTime() * 2) % 2 == 0) and "_" or ""
        ChatEditText:SetText(inputText .. cursor)

        -- Check Ctrl+C, Ctrl+V, and Ctrl+X clipboard actions
        local clipboardHandled = false
        if IsControlKeyDown() then
            if IsKeyPressed(86) then -- Ctrl+V (Paste)
                local clip = GetClipboardText()
                if clip and clip ~= "" then
                    local clean = string.gsub(clip, "[\r\n\t]", "")
                    local remaining = 255 - string.len(inputText)
                    if remaining > 0 then
                        inputText = inputText .. string.sub(clean, 1, remaining)
                    end
                end
                clipboardHandled = true
            elseif IsKeyPressed(67) then -- Ctrl+C (Copy)
                SetClipboardText(inputText)
                clipboardHandled = true
            elseif IsKeyPressed(88) then -- Ctrl+X (Cut)
                SetClipboardText(inputText)
                inputText = ""
                clipboardHandled = true
            end
            
            if clipboardHandled then
                -- Drain the character queue to prevent double-triggering character read
                local char = GetCharPressed()
                while char > 0 do
                    char = GetCharPressed()
                end
            end
        end

        -- Read keyboard characters
        local char = GetCharPressed()
        while char > 0 do
            if char >= 32 and char <= 126 then -- printable ASCII
                if string.len(inputText) < 255 then
                    inputText = inputText .. string.char(char)
                end
            end
            char = GetCharPressed()
        end

        -- Check control keys (Backspace, Enter, Escape)
        if IsKeyPressed(259) then -- Backspace
            if string.len(inputText) > 0 then
                inputText = string.sub(inputText, 1, -2)
            end
        end
        if IsKeyPressed(257) then -- Enter
            if string.len(inputText) > 0 then
                submitChatMessage(inputText)
            end
            inputText = ""
            isTyping = false
            ChatEditFrame:Hide()
            SetChatActive(false)
        end
        if IsKeyPressed(256) then -- Escape
            inputText = ""
            isTyping = false
            ChatEditFrame:Hide()
            SetChatActive(false)
        end
    else
        -- Check if user wants to start typing (Enter or Slash)
        if IsKeyPressed(257) or IsKeyPressed(47) then
            isTyping = true
            inputText = ""
            if IsKeyPressed(47) then
                inputText = "/"
            end
            -- Drain the character queue to prevent double-triggering character read
            local char = GetCharPressed()
            while char > 0 do
                char = GetCharPressed()
            end
            ChatEditFrame:Show()
            SetChatActive(true)
        end
    end

    local mx, my = GetMousePosition()
    local cx, cy, fw, fh = self:GetRect()
    local isOverFrame = (mx >= cx and mx <= cx + fw and my >= cy and my <= cy + fh)

    if isOverFrame then
        local wheel = GetMouseWheelMove()
        if wheel ~= 0 then
            local visibleLines = math.floor((h - 34) / LOG_LINE_H)
            if visibleLines < 1 then visibleLines = 1 end
            local maxScroll = math.max(0, #logMessages - visibleLines)
            
            scrollOffset = scrollOffset + wheel
            if scrollOffset > maxScroll then scrollOffset = maxScroll end
            if scrollOffset < 0 then scrollOffset = 0 end
            updateLogDisplay()
            ConsumeMouseWheel()
        end
    end

    if draggingThumb then
        if IsMouseButtonDown(0) then
            local dy = my - dragStartY
            local trackH = ScrollTrack:GetHeight()
            local thumbH = ScrollThumb:GetHeight()
            local visibleLines = math.floor((h - 34) / LOG_LINE_H)
            if visibleLines < 1 then visibleLines = 1 end
            local maxScroll = math.max(0, #logMessages - visibleLines)

            if trackH > thumbH and maxScroll > 0 then
                local deltaScroll = -(dy / (trackH - thumbH)) * maxScroll
                scrollOffset = dragStartScroll + deltaScroll
                if scrollOffset > maxScroll then scrollOffset = maxScroll end
                if scrollOffset < 0 then scrollOffset = 0 end
                updateLogDisplay()
            end
        else
            draggingThumb = false
        end
    else
        if IsMouseButtonPressed(0) then
            local tx, ty, tw, th = ScrollThumb:GetRect()
            if mx >= tx and mx <= tx + tw and my >= ty and my <= ty + th then
                draggingThumb = true
                dragStartY = my
                dragStartScroll = scrollOffset
            end
        end
    end
end)

-- Expose global function to add messages to the log window
function AddMessageToLog(text, r, g, b, channel)
    r = r or 0.85
    g = g or 0.85
    b = b or 0.9
    addLogMessage(text, r, g, b, channel or "General")
end

-- Process any messages printed before HUD.lua loaded
if earlyLogBuffer then
    for _, msg in ipairs(earlyLogBuffer) do
        addLogMessage(msg, 0.85, 0.85, 0.9)
    end
    earlyLogBuffer = nil
end

addLogMessage("Message log initialized.", 0.5, 0.5, 0.6)
