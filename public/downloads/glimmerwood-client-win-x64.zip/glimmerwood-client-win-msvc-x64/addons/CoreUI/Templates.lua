-------------------------------------------------------------------------------
-- Templates.lua  (CoreUI)
-- Reusable frame templates registered into the global FrameTemplates table.
-- These mirror the XML template system: CreateFrame("Frame", name, parent,
-- "TemplateName") will run OnLoad(self) after the frame is created.
-------------------------------------------------------------------------------

earlyLogBuffer = earlyLogBuffer or {}
local oldPrint = print
print = function(...)
    local n = select("#", ...)
    local t = {}
    for i = 1, n do
        t[i] = tostring(select(i, ...))
    end
    local msg = table.concat(t, "\t")
    oldPrint(msg)
    if AddMessageToLog then
        AddMessageToLog(msg, 0.85, 0.85, 0.9)
    else
        table.insert(earlyLogBuffer, msg)
    end
end


-------------------------------------------------------------------------------
-- BasicPanelTemplate
-- A dark semi-transparent panel with a subtle border.  Used as the base for
-- most UI windows (inventory, HUD panels, etc.).
-------------------------------------------------------------------------------
FrameTemplates["BasicPanelTemplate"] = {
    OnLoad = function(self)
        -- Dark navy background at 85 % opacity
        self:SetBackdropColor(0.1, 0.1, 0.15, 0.85)
        -- Muted blue-gray border
        self:SetBackdropBorderColor(0.4, 0.4, 0.5)
    end,
}

-------------------------------------------------------------------------------
-- UIPanelButtonTemplate
-- A styled button with a blue-gray base tint, hover highlight, and readable
-- font.  Used for all interactive buttons (close, equip, etc.).
-------------------------------------------------------------------------------
FrameTemplates["UIPanelButtonTemplate"] = {
    OnLoad = function(self)
        self:SetBackdropColor(0.18, 0.22, 0.32, 0.90)
        self:SetBackdropBorderColor(0.45, 0.52, 0.70)
        self:SetHighlightColor(0.35, 0.45, 0.70, 0.55)
        self:EnableMouse(true)

        -- Find or create a label FontString for the button text
        local lbl = self:CreateFontString(nil, "HIGH")
        lbl:SetAllPoints(self)
        lbl:SetFont(16)
        lbl:SetJustifyH("CENTER")
        lbl:SetTextColor(0.92, 0.92, 0.92)

        -- Store reference so callers can update via self:SetText()
        -- The frame wrapper SetText/GetText delegate to the FontString.
        -- (The C layer already provides Button:SetText / Button:GetText, so
        -- this OnLoad just ensures visual styling is applied.)
    end,
}

-------------------------------------------------------------------------------
-- StatusBarTemplate
-- A thin panel that contains a pre-configured StatusBar child.
-- After creation: access the bar via self.bar
-------------------------------------------------------------------------------
FrameTemplates["StatusBarTemplate"] = {
    OnLoad = function(self)
        -- Outer panel
        self:SetBackdropColor(0.08, 0.08, 0.10, 0.80)
        self:SetBackdropBorderColor(0.30, 0.30, 0.38)

        -- Inner bar fills the panel with a small inset
        local bar = CreateFrame("StatusBar", nil, self)
        bar:SetPoint("TOPLEFT",     self, "TOPLEFT",     2,  -2)
        bar:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", -2,  2)
        bar:SetMinMaxValues(0, 1)
        bar:SetValue(1)
        bar:SetStatusBarColor(0.25, 0.65, 0.25, 1.0)  -- default green

        self.bar = bar
    end,
}

-------------------------------------------------------------------------------
-- TooltipTemplate
-- Very dark background for hoverable tooltips.  Strata is set to TOOLTIP so
-- it always renders on top of everything else.
-------------------------------------------------------------------------------
FrameTemplates["TooltipTemplate"] = {
    OnLoad = function(self)
        self:SetBackdropColor(0.06, 0.06, 0.09, 0.95)
        self:SetBackdropBorderColor(0.55, 0.50, 0.22)   -- gold-ish border
        self:SetFrameStrata("TOOLTIP")
        self:Hide()   -- tooltips start hidden; shown on demand
    end,
}

-------------------------------------------------------------------------------
-- GameTooltip
-- Global tooltip frame used for showing item info on hover.
-------------------------------------------------------------------------------
GameTooltip = CreateFrame("Frame", "GameTooltip", UIParent, "TooltipTemplate")
GameTooltip:SetSize(220, 44)

-- Title / Item Name
GameTooltip.title = GameTooltip:CreateFontString(nil, "HIGH")
GameTooltip.title:SetPoint("TOPLEFT", GameTooltip, "TOPLEFT", 8, -6)
GameTooltip.title:SetFont(14)
GameTooltip.title:SetTextColor(1.0, 1.0, 1.0)

-- Description / Stats
GameTooltip.desc = GameTooltip:CreateFontString(nil, "HIGH")
GameTooltip.desc:SetPoint("TOPLEFT", GameTooltip.title, "BOTTOMLEFT", 0, -4)
GameTooltip.desc:SetFont(10)
GameTooltip.desc:SetTextColor(0.75, 0.75, 0.78)

function GameTooltip:SetText(text)
    self.title:SetText(text)
    self.lines = {}
    self.desc:SetText("")
    self:SetSize(math.max(#text * 8, 120) + 16, 44)
    self:Show()
end

function GameTooltip:AddLine(text, r, g, b)
    if not self.lines then self.lines = {} end
    table.insert(self.lines, { text = text, r = r, g = g, b = b })
    
    local fullText = ""
    local maxW = #self.title:GetText() * 8
    for idx, line in ipairs(self.lines) do
        if idx > 1 then fullText = fullText .. "\n" end
        fullText = fullText .. line.text
        local lw = #line.text * 5.5
        if lw > maxW then maxW = lw end
    end
    self.desc:SetText(fullText)
    
    local w = math.max(maxW, 120) + 16
    local h = 26 + #self.lines * 14
    self:SetSize(w, h)
end

function GameTooltip:SetItem(itemId, priceStr)
    if not itemId or itemId <= 0 then
        self:Hide()
        return
    end
    local name, cat, equipSlot, attack, defense, light_radius, value, heal_amount, heal_duration, heal_per_second = GetItemInfo(itemId)
    if not name then
        self:Hide()
        return
    end

    self.title:SetText(name)

    -- Format stats line dynamically
    local catUpper = cat:sub(1,1):upper() .. cat:sub(2)
    local stats = {}

    if attack and attack > 0 then
        table.insert(stats, "atk " .. attack)
    end
    if defense and defense > 0 then
        table.insert(stats, "def " .. defense)
    end
    if light_radius and light_radius > 0 then
        table.insert(stats, "light " .. light_radius)
    end

    if heal_amount and heal_amount > 0 and heal_per_second and heal_per_second > 0 then
        table.insert(stats, string.format("heals %d + %d/sec for %ds", heal_amount, heal_per_second, heal_duration))
    elseif heal_amount and heal_amount > 0 then
        table.insert(stats, string.format("heals %d", heal_amount))
    elseif heal_per_second and heal_per_second > 0 then
        table.insert(stats, string.format("heals %d/sec for %ds", heal_per_second, heal_duration))
    end

    if value and value > 0 then
        table.insert(stats, "val " .. value)
    end

    local descText = catUpper
    if #stats > 0 then
        descText = descText .. "  |  " .. table.concat(stats, "  ")
    end
    if priceStr then
        descText = descText .. "  |  " .. priceStr
    end
    self.desc:SetText(descText)

    -- Auto-size the tooltip frame based on character length approximations
    local w1 = #name * 8
    local w2 = #descText * 5.5
    local w = math.max(w1, w2, 120) + 16
    self:SetSize(w, 44)
    self:Show()
end
