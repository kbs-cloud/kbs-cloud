-------------------------------------------------------------------------------
-- Inventory.lua  (CoreUI)
-- Inventory bag window, paper-doll equipment window, container loot window,
-- and merchant shop window.
--
-- Architecture
-- ─────────────
-- The C layer still processes the "I" / Tab key and exposes two functions
-- that Lua polls:
--   GetBagOpen()       → bool    (reads ClientState.p_ui_show)
--   SetBagOpen(bool)             (writes ClientState.p_ui_show)
--
-- These are assumed to exist in lua_api.c (they are simple pass-throughs).
-- OnUpdate polls GetBagOpen() each frame and shows/hides accordingly.
--
-- Windows
-- ────────
-- InventoryFrame  (400×500)  – 32-slot grid, DIALOG strata, bottom-right
-- EquipmentFrame  (200×400)  – paper-doll, DIALOG strata, independent center-left
-- ContainerFrame  (310×300)  – loot grid, appears when a chest is opened
-- ShopFrame       (310×300)  – merchant grid, appears when a shop is opened
--
-- Globals set here (consumed by ActionBar.lua):
--   GLIMMERWOOD_BAG_OPEN          bool
--   GLIMMERWOOD_HOVERED_INV_SLOT  int (1-based; 0 = none)
-------------------------------------------------------------------------------

-- Ensure globals exist even if ActionBar loaded first
GLIMMERWOOD_BAG_OPEN         = false
GLIMMERWOOD_HOVERED_INV_SLOT = 0

-------------------------------------------------------------------------------
-- Constants
-------------------------------------------------------------------------------
local SLOT_SIZE  = 44
local SLOT_GAP   = 4
local COLS       = 8
local ROWS       = math.ceil(INVENTORY_SLOTS / COLS)  -- 4 rows of 8
local INV_W      = COLS * (SLOT_SIZE + SLOT_GAP) + SLOT_GAP * 2 + 4   -- ~384
local INV_H      = 500
local EQ_W       = 200
local EQ_H       = 400

-------------------------------------------------------------------------------
-- Item category colour (shared palette)
-------------------------------------------------------------------------------
local function itemColor(cat)
    if cat == "weapon"     then return 0.78, 0.31, 0.27 end
    if cat == "shield"     then return 0.35, 0.47, 0.78 end
    if cat == "armor"      then return 0.55, 0.55, 0.59 end
    if cat == "jewelry"    then return 0.82, 0.59, 0.86 end
    if cat == "consumable" then return 0.47, 0.78, 0.47 end
    if cat == "material"   then return 0.67, 0.55, 0.43 end
    if cat == "light"      then return 0.90, 0.78, 0.35 end
    return 0.47, 0.47, 0.47
end

-------------------------------------------------------------------------------
-- Helper: add a title FontString at the top of a panel frame
-------------------------------------------------------------------------------
local function addTitle(parent, text)
    local fs = parent:CreateFontString(nil, "HIGH")
    fs:SetPoint("TOPLEFT",  parent, "TOPLEFT",  8, -6)
    fs:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -8, -6)
    fs:SetHeight(18)
    fs:SetFont(15)
    fs:SetJustifyH("CENTER")
    fs:SetTextColor(0.88, 0.82, 0.60)
    fs:SetText(text)
    return fs
end

-------------------------------------------------------------------------------
-- Helper: add a small close "×" button to a panel frame
-------------------------------------------------------------------------------
local function addCloseButton(parent, onClose)
    local btn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    btn:SetSize(22, 22)
    btn:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -4, -4)
    btn:SetText("x")
    btn:EnableMouse(true)
    btn:SetScript("OnClick", onClose)
    return btn
end

-------------------------------------------------------------------------------
-- ═══════════════════════════════════════════════════════════════════════════
-- INVENTORY FRAME
-- ═══════════════════════════════════════════════════════════════════════════
-------------------------------------------------------------------------------
InventoryFrame = CreateFrame("Frame", "InventoryFrame", UIParent, "BasicPanelTemplate")
InventoryFrame:SetSize(INV_W, INV_H)
-- Shifted left to avoid the two right-side action bars (each ~58px wide + gap)
InventoryFrame:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -130, 80)
InventoryFrame:SetFrameStrata("DIALOG")
InventoryFrame:SetMovable(true)
InventoryFrame:EnableMouse(true)
InventoryFrame:Hide()

addTitle(InventoryFrame, "Inventory")
addCloseButton(InventoryFrame, function()
    SetBagOpen(false)
end)

-- Slot frames (32 total)
local invSlotFrames = {}

for s = 1, INVENTORY_SLOTS do
    local col = (s - 1) % COLS
    local row = math.floor((s - 1) / COLS)
    local ox  = SLOT_GAP + col * (SLOT_SIZE + SLOT_GAP) + 4
    local oy  = -(28 + row * (SLOT_SIZE + SLOT_GAP))   -- below title

    local slot = CreateFrame("Button", "InvSlot" .. s, InventoryFrame,
                             "UIPanelButtonTemplate")
    slot:SetSize(SLOT_SIZE, SLOT_SIZE)
    slot:SetPoint("TOPLEFT", InventoryFrame, "TOPLEFT", ox, oy)
    slot:SetBackdropColor(0.10, 0.10, 0.13, 0.88)
    slot:EnableMouse(true)
    slot.slotIndex = s

    -- Slot number (faint, top-left corner)
    local numLabel = slot:CreateFontString(nil, "HIGH")
    numLabel:SetPoint("TOPLEFT", slot, "TOPLEFT", 2, -1)
    numLabel:SetFont(9)
    numLabel:SetTextColor(0.40, 0.40, 0.42)
    numLabel:SetText(tostring(s))

    -- Item count (bottom-right)
    local cntLabel = slot:CreateFontString(nil, "HIGH")
    cntLabel:SetPoint("BOTTOMRIGHT", slot, "BOTTOMRIGHT", -2, 2)
    cntLabel:SetFont(11)
    cntLabel:SetTextColor(1.0, 1.0, 0.8)
    cntLabel:SetText("")
    slot.cntLabel = cntLabel

    slot:SetScript("OnDraw", function(self)
        local sx, sy, sw, sh = self:GetRect()
        local itemId, count = GetInventorySlotInfo(self.slotIndex)
        if itemId and itemId > 0 then
            Draw2D.ItemIcon(itemId, sx + 2, sy + 2, sw - 4, sh - 4)
            if count and count > 1 then
                self.cntLabel:SetText(tostring(count))
            else
                self.cntLabel:SetText("")
            end
        else
            Draw2D.RectBorder(sx + 3, sy + 3, sw - 6, sh - 6, 1,
                              0.22, 0.22, 0.25, 0.45)
            self.cntLabel:SetText("")
        end

        -- Hover highlight (when this slot is "hovered" for hotbar assignment)
        if GLIMMERWOOD_HOVERED_INV_SLOT == self.slotIndex then
            Draw2D.RectBorder(sx, sy, sw, sh, 2, 1.0, 0.85, 0.20, 0.90)
        end
    end)

    -- Click: equip, use or drag
    slot:SetScript("OnClick", function(self, button)
        local idx = self.slotIndex
        if button == "Right" then
            local itemId, _ = GetInventorySlotInfo(idx)
            if not itemId or itemId == 0 then return end
            if GLIMMERWOOD_HELD_ITEM and GLIMMERWOOD_HELD_ITEM.slot == idx then
                GLIMMERWOOD_HELD_ITEM = nil
            end
            
            -- If Shop or Container is open, right-click transfers/sells
            local containerOpen = GetContainerOpen()
            if containerOpen then
                local count = IsShiftKeyDown() and 1 or 0
                C_Container.TransferToContainer(idx, nil, nil, count)
            else
                local _, cat, _ = GetItemInfo(itemId)
                cat = cat or ""
                if cat == "weapon" or cat == "shield" or
                   cat == "armor"  or cat == "jewelry" or cat == "light" then
                    C_Item.EquipItem(idx)
                elseif cat == "consumable" then
                    C_Item.UseItem(idx)
                end
            end
        else
            if GLIMMERWOOD_HELD_ITEM then
                C_Item.MoveItem(GLIMMERWOOD_HELD_ITEM.slot, idx)
                GLIMMERWOOD_HELD_ITEM = nil
            else
                local itemId, count = GetInventorySlotInfo(idx)
                if itemId and itemId > 0 then
                    GLIMMERWOOD_HELD_ITEM = { slot = idx, itemId = itemId, count = count, source = "inventory" }
                end
            end
        end
    end)

    -- Track hover for hotbar-assign feature and tooltips
    slot:SetScript("OnEnter", function(self)
        GLIMMERWOOD_HOVERED_INV_SLOT = self.slotIndex
        local itemId, _ = GetInventorySlotInfo(self.slotIndex)
        if itemId and itemId > 0 and GameTooltip then
            GameTooltip:SetPoint("BOTTOMLEFT", self, "TOPRIGHT", 8, 8)
            GameTooltip:SetItem(itemId)
        end
    end)
    slot:SetScript("OnLeave", function(self)
        if GLIMMERWOOD_HOVERED_INV_SLOT == self.slotIndex then
            GLIMMERWOOD_HOVERED_INV_SLOT = 0
        end
        if GameTooltip then
            GameTooltip:Hide()
        end
    end)

    invSlotFrames[s] = slot
end

local coinFS = InventoryFrame:CreateFontString(nil, "HIGH")
coinFS:SetPoint("BOTTOMLEFT", InventoryFrame, "BOTTOMLEFT", 14, 14)
coinFS:SetSize(200, 20)
coinFS:SetFont(14)
coinFS:SetJustifyH("LEFT")
coinFS:SetTextColor(0.95, 0.85, 0.20) -- Gold color
coinFS:SetText("Coins: 0")

-------------------------------------------------------------------------------
-- ═══════════════════════════════════════════════════════════════════════════
-- EQUIPMENT FRAME  (paper-doll)
-- ═══════════════════════════════════════════════════════════════════════════
-------------------------------------------------------------------------------
EquipmentFrame = CreateFrame("Frame", "EquipmentFrame", UIParent, "BasicPanelTemplate")
EquipmentFrame:SetSize(EQ_W, EQ_H)
-- Placed near the center left of the screen
EquipmentFrame:SetPoint("CENTER", UIParent, "CENTER", -100, 0)
EquipmentFrame:SetFrameStrata("DIALOG")
EquipmentFrame:SetMovable(true)
EquipmentFrame:EnableMouse(true)
EquipmentFrame:Hide()

addTitle(EquipmentFrame, "Equipment")
addCloseButton(EquipmentFrame, function()
    EquipmentFrame:Hide()
end)

-- Equipment slot definitions: display name, API slot name, position anchor
local EQ_SLOTS = {
    { label = "Head",      api = "head",      ox = 70,  oy = -50  },
    { label = "Main Hand", api = "main_hand", ox = 10,  oy = -130 },
    { label = "Body",      api = "body",      ox = 70,  oy = -130 },
    { label = "Off Hand",  api = "off_hand",  ox = 130, oy = -130 },
    { label = "Neck",      api = "neck",      ox = 10,  oy = -210 },
    { label = "Ring",      api = "ring",      ox = 70,  oy = -210 },
    { label = "Light",     api = "light",     ox = 130, oy = -210 },
}
local EQ_SLOT_W = 60
local EQ_SLOT_H = 60

for _, def in ipairs(EQ_SLOTS) do
    -- Label above the slot
    local lbl = EquipmentFrame:CreateFontString(nil, "HIGH")
    lbl:SetPoint("TOPLEFT", EquipmentFrame, "TOPLEFT", def.ox, def.oy - 14)
    lbl:SetSize(EQ_SLOT_W, 13)
    lbl:SetFont(10)
    lbl:SetJustifyH("CENTER")
    lbl:SetTextColor(0.65, 0.65, 0.70)
    lbl:SetText(def.label)

    -- Slot button
    local btn = CreateFrame("Button", "EqSlot_" .. def.api, EquipmentFrame,
                            "UIPanelButtonTemplate")
    btn:SetSize(EQ_SLOT_W, EQ_SLOT_H)
    btn:SetPoint("TOPLEFT", EquipmentFrame, "TOPLEFT", def.ox, def.oy)
    btn:SetBackdropColor(0.10, 0.10, 0.13, 0.88)
    btn:EnableMouse(true)
    btn.apiSlot = def.api

    btn:SetScript("OnDraw", function(self)
        local sx, sy, sw, sh = self:GetRect()
        local itemId, name = GetEquipmentSlotInfo(self.apiSlot)
        if itemId and itemId > 0 then
            Draw2D.ItemIcon(itemId, sx + 2, sy + 2, sw - 4, sh - 4)
        else
            -- Empty slot indicator
            Draw2D.RectBorder(sx + 4, sy + 4, sw - 8, sh - 8, 1,
                              0.28, 0.28, 0.32, 0.55)
        end
    end)

    -- Click: unequip or equip from cursor
    btn:SetScript("OnClick", function(self, button)
        if button == "Left" and GLIMMERWOOD_HELD_ITEM then
            C_Item.EquipItem(GLIMMERWOOD_HELD_ITEM.slot)
            GLIMMERWOOD_HELD_ITEM = nil
        else
            C_Item.UnequipItem(self.apiSlot)
        end
    end)

    btn:SetScript("OnEnter", function(self)
        local itemId, _ = GetEquipmentSlotInfo(self.apiSlot)
        if itemId and itemId > 0 and GameTooltip then
            GameTooltip:SetPoint("BOTTOMLEFT", self, "TOPRIGHT", 8, 8)
            GameTooltip:SetItem(itemId)
        end
    end)
    btn:SetScript("OnLeave", function(self)
        if GameTooltip then
            GameTooltip:Hide()
        end
    end)
end

-------------------------------------------------------------------------------
-- ═══════════════════════════════════════════════════════════════════════════
-- CONTAINER FRAME  (chest / loot)
-- ═══════════════════════════════════════════════════════════════════════════
-------------------------------------------------------------------------------
local CONT_COLS   = 8
local CONT_SLOT_W = 34
local CONT_SLOT_G = 4
local CONT_W      = CONT_COLS * (CONT_SLOT_W + CONT_SLOT_G) + CONT_SLOT_G * 2 + 4
local CONT_H      = 220

ContainerFrame = CreateFrame("Frame", "ContainerFrame", UIParent, "BasicPanelTemplate")
ContainerFrame:SetSize(CONT_W, CONT_H)
-- Placed near the center right of the screen
ContainerFrame:SetPoint("CENTER", UIParent, "CENTER", -100, 50)
ContainerFrame:SetFrameStrata("DIALOG")
ContainerFrame:SetMovable(true)
ContainerFrame:EnableMouse(true)
ContainerFrame:Hide()

local contTitle = addTitle(ContainerFrame, "Container")
addCloseButton(ContainerFrame, function()
    C_Container.Close()
end)

-- Container slots (INVENTORY_SLOTS worth of slots – same size as inventory)
local contSlotFrames = {}
for s = 1, INVENTORY_SLOTS do
    local col = (s - 1) % CONT_COLS
    local row = math.floor((s - 1) / CONT_COLS)
    local ox  = CONT_SLOT_G + col * (CONT_SLOT_W + CONT_SLOT_G) + 4
    local oy  = -(28 + row * (CONT_SLOT_W + CONT_SLOT_G))

    local slot = CreateFrame("Button", "ContSlot" .. s, ContainerFrame,
                             "UIPanelButtonTemplate")
    slot:SetSize(CONT_SLOT_W, CONT_SLOT_W)
    slot:SetPoint("TOPLEFT", ContainerFrame, "TOPLEFT", ox, oy)
    slot:SetBackdropColor(0.10, 0.10, 0.13, 0.88)
    slot:EnableMouse(true)
    slot.slotIndex = s

    local cntLabel = slot:CreateFontString(nil, "HIGH")
    cntLabel:SetPoint("BOTTOMRIGHT", slot, "BOTTOMRIGHT", -1, 1)
    cntLabel:SetFont(9)
    cntLabel:SetTextColor(1.0, 1.0, 0.8)
    cntLabel:SetText("")
    slot.cntLabel = cntLabel

    slot:SetScript("OnDraw", function(self)
        local sx, sy, sw, sh = self:GetRect()
        local itemId, count = GetContainerSlotInfo(self.slotIndex)
        if itemId and itemId > 0 then
            Draw2D.ItemIcon(itemId, sx + 2, sy + 2, sw - 4, sh - 4)
            if count and count > 1 then
                self.cntLabel:SetText(tostring(count))
            else
                self.cntLabel:SetText("")
            end
        else
            Draw2D.RectBorder(sx + 2, sy + 2, sw - 4, sh - 4, 1,
                              0.22, 0.22, 0.25, 0.40)
            self.cntLabel:SetText("")
        end
    end)

    -- Click: transfer item
    slot:SetScript("OnClick", function(self, button)
        local open, eid = GetContainerOpen()
        if open then
            if GLIMMERWOOD_HELD_ITEM then
                local count = IsShiftKeyDown() and 1 or 0
                C_Container.TransferToContainer(GLIMMERWOOD_HELD_ITEM.slot, nil, nil, count)
                GLIMMERWOOD_HELD_ITEM = nil
            else
                local count = IsShiftKeyDown() and 1 or 0
                C_Container.TransferToPlayer(self.slotIndex, count)
            end
        end
    end)

    slot:SetScript("OnEnter", function(self)
        local itemId, _ = GetContainerSlotInfo(self.slotIndex)
        if itemId and itemId > 0 and GameTooltip then
            GameTooltip:SetPoint("BOTTOMLEFT", self, "TOPRIGHT", 8, 8)
            local priceStr = nil
            if GetContainerIsShop and GetContainerIsShop() then
                priceStr = GetContainerSlotPrice(self.slotIndex)
            end
            GameTooltip:SetItem(itemId, priceStr)
        end
    end)
    slot:SetScript("OnLeave", function(self)
        if GameTooltip then
            GameTooltip:Hide()
        end
    end)

    contSlotFrames[s] = slot
end

-- "Take All" button
local takeAllBtn = CreateFrame("Button", "ContTakeAllBtn", ContainerFrame,
                               "UIPanelButtonTemplate")
takeAllBtn:SetSize(90, 22)
takeAllBtn:SetPoint("BOTTOM", ContainerFrame, "BOTTOM", -50, 6)
takeAllBtn:SetText("Take All")
takeAllBtn:EnableMouse(true)
takeAllBtn:SetScript("OnClick", function()
    local open, eid = GetContainerOpen()
    if open then
        for s = 1, INVENTORY_SLOTS do
            local itemId, _ = GetContainerSlotInfo(s)
            if itemId and itemId > 0 then
                C_Container.TransferToPlayer(s, 0)
            end
        end
    end
end)

-- "Close" button (alias – addCloseButton already added one; this is "Close" label)
local closeContBtn = CreateFrame("Button", "ContCloseBtn", ContainerFrame,
                                 "UIPanelButtonTemplate")
closeContBtn:SetSize(70, 22)
closeContBtn:SetPoint("BOTTOM", ContainerFrame, "BOTTOM", 50, 6)
closeContBtn:SetText("Close")
closeContBtn:EnableMouse(true)
closeContBtn:SetScript("OnClick", function()
    C_Container.Close()
end)

-------------------------------------------------------------------------------
-- ═══════════════════════════════════════════════════════════════════════════
-- SHOP FRAME  (merchant / store)
-- ═══════════════════════════════════════════════════════════════════════════
-------------------------------------------------------------------------------
ShopFrame = CreateFrame("Frame", "ShopFrame", UIParent, "BasicPanelTemplate")
ShopFrame:SetSize(CONT_W, CONT_H)
-- Placed near the center of the screen
ShopFrame:SetPoint("CENTER", UIParent, "CENTER", -100, 0)
ShopFrame:SetFrameStrata("DIALOG")
ShopFrame:SetMovable(true)
ShopFrame:EnableMouse(true)
ShopFrame:Hide()

local shopTitle = addTitle(ShopFrame, "Merchant")
addCloseButton(ShopFrame, function()
    C_Container.Close()
end)

local shopSlotFrames = {}
for s = 1, INVENTORY_SLOTS do
    local col = (s - 1) % CONT_COLS
    local row = math.floor((s - 1) / CONT_COLS)
    local ox  = CONT_SLOT_G + col * (CONT_SLOT_W + CONT_SLOT_G) + 4
    local oy  = -(28 + row * (CONT_SLOT_W + CONT_SLOT_G))

    local slot = CreateFrame("Button", "ShopSlot" .. s, ShopFrame,
                             "UIPanelButtonTemplate")
    slot:SetSize(CONT_SLOT_W, CONT_SLOT_W)
    slot:SetPoint("TOPLEFT", ShopFrame, "TOPLEFT", ox, oy)
    slot:SetBackdropColor(0.10, 0.10, 0.13, 0.88)
    slot:EnableMouse(true)
    slot.slotIndex = s

    local cntLabel = slot:CreateFontString(nil, "HIGH")
    cntLabel:SetPoint("BOTTOMRIGHT", slot, "BOTTOMRIGHT", -1, 1)
    cntLabel:SetFont(9)
    cntLabel:SetTextColor(1.0, 1.0, 0.8)
    cntLabel:SetText("")
    slot.cntLabel = cntLabel

    slot:SetScript("OnDraw", function(self)
        local sx, sy, sw, sh = self:GetRect()
        local itemId, count = GetContainerSlotInfo(self.slotIndex)
        if itemId and itemId > 0 then
            Draw2D.ItemIcon(itemId, sx + 2, sy + 2, sw - 4, sh - 4)
            if count and count > 1 then
                self.cntLabel:SetText(tostring(count))
            else
                self.cntLabel:SetText("")
            end
        else
            Draw2D.RectBorder(sx + 2, sy + 2, sw - 4, sh - 4, 1,
                              0.22, 0.22, 0.25, 0.40)
            self.cntLabel:SetText("")
        end
    end)

    -- Click: Buy item (right or left click)
    slot:SetScript("OnClick", function(self, button)
        local open, eid = GetContainerOpen()
        if open and GetContainerIsShop() then
            local count = IsShiftKeyDown() and 1 or 0
            C_Container.TransferToPlayer(self.slotIndex, count)
        end
    end)

    slot:SetScript("OnEnter", function(self)
        local itemId, _ = GetContainerSlotInfo(self.slotIndex)
        if itemId and itemId > 0 and GameTooltip then
            GameTooltip:SetPoint("BOTTOMLEFT", self, "TOPRIGHT", 8, 8)
            local priceStr = nil
            if GetContainerIsShop and GetContainerIsShop() then
                priceStr = GetContainerSlotPrice(self.slotIndex)
            end
            GameTooltip:SetItem(itemId, priceStr)
        end
    end)
    slot:SetScript("OnLeave", function(self)
        if GameTooltip then
            GameTooltip:Hide()
        end
    end)

    shopSlotFrames[s] = slot
end

-------------------------------------------------------------------------------
-- ═══════════════════════════════════════════════════════════════════════════
-- SHOW / HIDE LOGIC & KEY polling
-- ═══════════════════════════════════════════════════════════════════════════
-------------------------------------------------------------------------------

-- Key listener for 'C' (keycode 67) to toggle character sheet independently
local cDebounce = false
local equipKeyPoller = CreateFrame("Frame", "EquipmentKeyPoller", UIParent)
equipKeyPoller:SetScript("OnUpdate", function(self, dt)
    local cPressed = IsKeyPressed(67)
    if cPressed and not cDebounce then
        cDebounce = true
        if EquipmentFrame:IsShown() then
            EquipmentFrame:Hide()
        else
            -- Opening character screen closes any open container / shop
            if ShopFrame:IsShown() or ContainerFrame:IsShown() then
                C_Container.Close()
            end
            EquipmentFrame:Show()
        end
    elseif not cPressed then
        cDebounce = false
    end
end)

GLIMMERWOOD_CONT_WAS_OPEN = false

-- Master OnUpdate: poll bag state and container state each frame
local masterPoll = CreateFrame("Frame", "UIStatePollFrame", UIParent)
masterPoll:SetScript("OnUpdate", function(self, dt)
    -- Inventory window follows GetBagOpen()
    local bagOpen = GetBagOpen and GetBagOpen() or false
    if GLIMMERWOOD_BAG_OPEN and not bagOpen then
        if GameTooltip then GameTooltip:Hide() end
        GLIMMERWOOD_HELD_ITEM = nil
    end
    GLIMMERWOOD_BAG_OPEN = bagOpen
    InventoryFrame:SetShown(bagOpen)

    -- Drop hovered item with 'O' key (keyCode 79)
    if bagOpen and IsKeyPressed(79) then
        if GLIMMERWOOD_HOVERED_INV_SLOT and GLIMMERWOOD_HOVERED_INV_SLOT > 0 then
            local itemId, count = GetInventorySlotInfo(GLIMMERWOOD_HOVERED_INV_SLOT)
            if itemId and itemId > 0 then
                C_Item.DropItem(GLIMMERWOOD_HOVERED_INV_SLOT, count)
                if GLIMMERWOOD_HELD_ITEM and GLIMMERWOOD_HELD_ITEM.slot == GLIMMERWOOD_HOVERED_INV_SLOT then
                    GLIMMERWOOD_HELD_ITEM = nil
                end
            end
        end
    end

    if bagOpen then
        local stats = C_Quest.GetPlayerStats()
        local coins = stats and stats.coins or 0
        coinFS:SetText(string.format("Coins: %d", coins))
    end

    -- Container window / Shop window follows GetContainerOpen()
    local contOpen, eid = GetContainerOpen()
    if GLIMMERWOOD_CONT_OPEN and not contOpen then
        if GameTooltip then GameTooltip:Hide() end
    end
    
    -- Transition handlers
    if contOpen and not GLIMMERWOOD_CONT_WAS_OPEN then
        -- Opened container or shop! Auto-open bags, hide equipment
        SetBagOpen(true)
        EquipmentFrame:Hide()
    elseif not contOpen and GLIMMERWOOD_CONT_WAS_OPEN then
        -- Closed container or shop! Auto-close bags
        SetBagOpen(false)
    end
    GLIMMERWOOD_CONT_WAS_OPEN = contOpen
    GLIMMERWOOD_CONT_OPEN = contOpen

    -- Set visibility of container vs shop frames
    if contOpen then
        local isShop = GetContainerIsShop and GetContainerIsShop() or false
        if isShop then
            ShopFrame:Show()
            ContainerFrame:Hide()
        else
            ContainerFrame:Show()
            ShopFrame:Hide()
        end
    else
        ShopFrame:Hide()
        ContainerFrame:Hide()
    end
end)

-- Refresh slot visuals when inventory changes
InventoryFrame:RegisterEvent("INVENTORY_UPDATE")
EquipmentFrame:RegisterEvent("INVENTORY_UPDATE")
ContainerFrame:RegisterEvent("INVENTORY_UPDATE")
ContainerFrame:RegisterEvent("CONTAINER_UPDATE")
ShopFrame:RegisterEvent("INVENTORY_UPDATE")
ShopFrame:RegisterEvent("CONTAINER_UPDATE")

local function onInvUpdate(self, event, ...)
    -- Nothing to do explicitly – OnDraw reads current state each frame
end

InventoryFrame:SetScript("OnEvent", onInvUpdate)
EquipmentFrame:SetScript("OnEvent", onInvUpdate)
ContainerFrame:SetScript("OnEvent", onInvUpdate)
ShopFrame:SetScript("OnEvent", onInvUpdate)

-------------------------------------------------------------------------------
-- ═══════════════════════════════════════════════════════════════════════════
-- CURSOR / DRAG-AND-DROP SYSTEM
-- ═══════════════════════════════════════════════════════════════════════════
-------------------------------------------------------------------------------

GLIMMERWOOD_HELD_ITEM = nil

-- Full-screen click catcher for dropping items
local dropFrame = CreateFrame("Frame", "WorldDropFrame", UIParent)
dropFrame:SetSize(GetScreenWidth(), GetScreenHeight())
dropFrame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 0, 0)
dropFrame:SetFrameStrata("BACKGROUND")
dropFrame:EnableMouse(true)

dropFrame:SetScript("OnClick", function(self, button)
    if button == "Left" and GLIMMERWOOD_HELD_ITEM then
        -- Drop the item on the ground!
        C_Item.DropItem(GLIMMERWOOD_HELD_ITEM.slot, GLIMMERWOOD_HELD_ITEM.count)
        GLIMMERWOOD_HELD_ITEM = nil
    end
end)

dropFrame:SetScript("OnUpdate", function(self)
    self:SetSize(GetScreenWidth(), GetScreenHeight())
end)

-- Visual cursor follower for held items
local cursorFrame = CreateFrame("Frame", "CursorFollowerFrame", UIParent)
cursorFrame:SetSize(44, 44)
cursorFrame:SetFrameStrata("TOOLTIP")
cursorFrame:Hide()

cursorFrame:SetScript("OnDraw", function(self)
    if GLIMMERWOOD_HELD_ITEM then
        local sx, sy, sw, sh = self:GetRect()
        local itemId = GLIMMERWOOD_HELD_ITEM.itemId
        
        Draw2D.ItemIcon(itemId, sx + 2, sy + 2, sw - 4, sh - 4)
        Draw2D.RectBorder(sx, sy, sw, sh, 2, 1, 1, 1, 0.9)
        
        if GLIMMERWOOD_HELD_ITEM.count > 1 then
            Draw2D.Text(tostring(GLIMMERWOOD_HELD_ITEM.count), sx + sw - 14, sy + 4, 10, 1, 1, 0.8, 1.0)
        end
    end
end)

cursorFrame:SetScript("OnUpdate", function(self)
    if GLIMMERWOOD_HELD_ITEM then
        local mx, my = GetMousePosition()
        self:SetPoint("TOPLEFT", UIParent, "TOPLEFT", mx - 22, my - 22)
        self:Show()
    else
        self:Hide()
    end
end)

-------------------------------------------------------------------------------
-- ═══════════════════════════════════════════════════════════════════════════
-- MICRO MENU
-- ═══════════════════════════════════════════════════════════════════════════
-------------------------------------------------------------------------------
local MENU_BTN_W = 52
local MENU_BTN_H = 22
local MENU_GAP   = 4
local MENU_COUNT = 6   -- Craft removed (now in Codex tabs)
local MENU_W     = MENU_COUNT * MENU_BTN_W + (MENU_COUNT - 1) * MENU_GAP + 8
local MENU_H     = MENU_BTN_H + 8

local MicroMenuFrame = CreateFrame("Frame", "MicroMenuFrame", UIParent, "BasicPanelTemplate")
MicroMenuFrame:SetSize(MENU_W, MENU_H)
-- Positioned at bottom-left under the combat log to avoid overlap with wider action bars
MicroMenuFrame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 12, 12)
MicroMenuFrame:SetFrameStrata("DIALOG")

local menuDefs = {
    { text = "Char",  onClick = function()
        if EquipmentFrame:IsShown() then
            EquipmentFrame:Hide()
        else
            if ShopFrame:IsShown() or ContainerFrame:IsShown() then
                C_Container.Close()
            end
            EquipmentFrame:Show()
        end
    end },
    { text = "Codex", onClick = function()
        if CodexFrame then
            if CodexFrame:IsShown() then
                CodexFrame:Hide()
            else
                CodexFrame:Show()
                CodexFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 20)
            end
        end
    end },
    { text = "Quest", onClick = function()
        if QuestLogFrame then
            if QuestLogFrame:IsShown() then
                QuestLogFrame:Hide()
            else
                QuestLogFrame:Show()
            end
        end
    end },
    { text = "Ach",   onClick = function()
        if AchievementsFrame then
            if AchievementsFrame:IsShown() then
                AchievementsFrame:Hide()
            else
                AchievementsFrame:Show()
            end
        end
    end },
    { text = "Bags",  onClick = function()
        SetBagOpen(not GetBagOpen())
    end },
    { text = "Menu",  onClick = function()
        if TogglePauseMenu then
            TogglePauseMenu()
        end
    end }
}

for idx, def in ipairs(menuDefs) do
    local btn = CreateFrame("Button", "MicroMenuBtn_" .. def.text, MicroMenuFrame, "UIPanelButtonTemplate")
    btn:SetSize(MENU_BTN_W, MENU_BTN_H)
    local ox = 4 + (idx - 1) * (MENU_BTN_W + MENU_GAP)
    btn:SetPoint("LEFT", MicroMenuFrame, "LEFT", ox, 0)
    btn:SetText(def.text)
    btn:EnableMouse(true)
    btn:SetScript("OnClick", def.onClick)
end
