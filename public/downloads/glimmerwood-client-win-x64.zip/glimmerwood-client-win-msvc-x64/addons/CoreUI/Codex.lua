-------------------------------------------------------------------------------
-- Codex.lua  (CoreUI)
-- WoW-style spellbook / ability codex with tabs:
--   General | Path of Strength | Path of Agility | Path of Magic
--   | Metalworking | Cooking | Herbalism | Leatherworking
--
-- Abilities can be picked up (GLIMMERWOOD_HELD_ITEM) and placed on action bars.
-- Crafting tabs show the in-game recipe list using the C_Craft API.
-- Opens/closes with 'K'.
-------------------------------------------------------------------------------

local CODEX_W      = 500
local CODEX_H      = 520
local TAB_H        = 26
local MARGIN       = 10
local ROW_H        = 64
local ROW_GAP      = 6
local SCROLL_SPEED = 3

-------------------------------------------------------------------------------
-- Tab definitions
-------------------------------------------------------------------------------
local TABS = {
    { id = "general",       label = "General",       kind = "abilities" },
    { id = "strength",      label = "Strength",      kind = "abilities" },
    { id = "agility",       label = "Agility",       kind = "abilities" },
    { id = "magic",         label = "Magic",         kind = "abilities" },
    { id = "metalworking",  label = "Metalwork",     kind = "crafting",  profession = "Metalworking" },
    { id = "cooking",       label = "Cooking",       kind = "crafting",  profession = "Cooking" },
    { id = "herbalism",     label = "Herbalism",     kind = "crafting",  profession = "Herbalism" },
    { id = "leatherwork",   label = "Leatherwork",   kind = "crafting",  profession = "Leatherworking" },
    { id = "talents",       label = "Talents",       kind = "talents" },
}

local TAB_COUNT = #TABS
local TAB_W     = math.floor((CODEX_W - MARGIN * 2) / TAB_COUNT)

-------------------------------------------------------------------------------
-- Ability database (shared by all, filtered per tab)
-- -------------------------------------------------------------------------------
local AllAbilities = {
    -- General
    {
        id = 1001, tab = "general",
        name = "Slash", cdText = "No Cooldown",
        color = { 0.78, 0.25, 0.25 },
        castTime = "Instant", range = "Melee",
        desc = "A quick melee sweep dealing physical damage to enemies in front.",
    },
    {
        id = 1002, tab = "general",
        name = "Sprint", cdText = "10s Cooldown",
        color = { 0.25, 0.60, 0.78 },
        castTime = "Instant", range = "Self",
        desc = "Boost movement speed by 50% for 3 seconds.",
    },
    {
        id = 1003, tab = "general",
        name = "Regen", cdText = "15s Cooldown",
        color = { 0.25, 0.75, 0.35 },
        castTime = "1.0s cast", range = "Self",
        desc = "Restore 15 HP over 5 seconds.",
    },
    -- Strength path
    {
        id = 1004, tab = "strength",
        name = "Fireball", cdText = "5s Cooldown",
        color = { 0.88, 0.45, 0.15 },
        castTime = "1.5s cast", range = "20m range",
        desc = "Hurl a ball of fire at the nearest target within 20m for 8 damage.",
    },
    {
        id = 1010, tab = "strength",
        name = "Bash", cdText = "8s Cooldown",
        color = { 0.75, 0.35, 0.20 },
        castTime = "Instant", range = "Melee",
        desc = "A powerful overhead strike that stuns the target briefly.",
    },
    {
        id = 1011, tab = "strength",
        name = "War Cry", cdText = "20s Cooldown",
        color = { 0.80, 0.55, 0.15 },
        castTime = "Instant", range = "Self",
        desc = "Unleash a battle cry that boosts your attack power for 8 seconds.",
    },
    -- Agility path
    {
        id = 1020, tab = "agility",
        name = "Backstab", cdText = "6s Cooldown",
        color = { 0.45, 0.75, 0.30 },
        castTime = "Instant", range = "Melee",
        desc = "Strike from the shadows dealing double damage if behind the target.",
    },
    {
        id = 1021, tab = "agility",
        name = "Dodge", cdText = "12s Cooldown",
        color = { 0.20, 0.65, 0.80 },
        castTime = "Instant", range = "Self",
        desc = "Sidestep attacks for 2 seconds, reducing incoming damage by 80%.",
    },
    {
        id = 1022, tab = "agility",
        name = "Poison Dart", cdText = "4s Cooldown",
        color = { 0.55, 0.80, 0.20 },
        castTime = "Instant", range = "10m range",
        desc = "Launch a poison dart that deals damage over 6 seconds.",
    },
    {
        id = 1023, tab = "agility",
        name = "Stealth", cdText = "10s Cooldown",
        color = { 0.50, 0.40, 0.60 },
        castTime = "Instant", range = "Self",
        desc = "Enter stealth, making you transparent and hard to detect by enemies.",
    },
    -- Magic path
    {
        id = 1030, tab = "magic",
        name = "Frostbolt", cdText = "3s Cooldown",
        color = { 0.30, 0.65, 0.90 },
        castTime = "1.0s cast", range = "12m range",
        desc = "A bolt of frost that slows and damages the target.",
    },
    {
        id = 1031, tab = "magic",
        name = "Arcane Surge", cdText = "18s Cooldown",
        color = { 0.65, 0.25, 0.90 },
        castTime = "Instant", range = "Self",
        desc = "Release arcane energy in a burst, damaging all nearby enemies.",
    },
    {
        id = 1032, tab = "magic",
        name = "Mend", cdText = "10s Cooldown",
        color = { 0.35, 0.85, 0.60 },
        castTime = "1.5s cast", range = "12m range",
        desc = "Channel arcane energy to restore 30 HP to yourself or an ally.",
    },
}

-------------------------------------------------------------------------------
-- Codex frame
-------------------------------------------------------------------------------
CodexFrame = CreateFrame("Frame", "CodexFrame", UIParent, "BasicPanelTemplate")
CodexFrame:SetSize(CODEX_W, CODEX_H)
CodexFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 20)
CodexFrame:SetFrameStrata("HIGH")
CodexFrame:SetMovable(true)
CodexFrame:EnableMouse(true)
CodexFrame:Hide()

-- Title
local titleFS = CodexFrame:CreateFontString(nil, "HIGH")
titleFS:SetPoint("TOPLEFT",  CodexFrame, "TOPLEFT",  MARGIN, -5)
titleFS:SetPoint("TOPRIGHT", CodexFrame, "TOPRIGHT", -MARGIN, -5)
titleFS:SetHeight(18)
titleFS:SetFont(15)
titleFS:SetJustifyH("CENTER")
titleFS:SetTextColor(0.88, 0.82, 0.60)
titleFS:SetText("Codex")

-- Close button
local closeBtn = CreateFrame("Button", "CodexCloseBtn", CodexFrame, "UIPanelButtonTemplate")
closeBtn:SetSize(22, 22)
closeBtn:SetPoint("TOPRIGHT", CodexFrame, "TOPRIGHT", -4, -4)
closeBtn:SetText("x")
closeBtn:EnableMouse(true)
closeBtn:SetScript("OnClick", function() CodexFrame:Hide() end)

-------------------------------------------------------------------------------
-- State
-------------------------------------------------------------------------------
local activeTabIdx = 1
local scrollOffset = 0   -- in rows
local selectedRecipeIdx = 1

-------------------------------------------------------------------------------
-- Content area bounds
-------------------------------------------------------------------------------
local CONTENT_Y     = -(TAB_H + 28)          -- top of content, relative to CodexFrame top
local CONTENT_H     = CODEX_H + CONTENT_Y - 55  -- height of scrollable area (leave footer)
local VISIBLE_ROWS  = math.floor(CONTENT_H / (ROW_H + ROW_GAP))

-------------------------------------------------------------------------------
-- Helper: item count in bag
-------------------------------------------------------------------------------
local function GetItemCountInBag(itemId)
    local total = 0
    for s = 1, INVENTORY_SLOTS do
        local id, count = GetInventorySlotInfo(s)
        if id == itemId then total = total + count end
    end
    return total
end

-------------------------------------------------------------------------------
-- Build tab buttons
-------------------------------------------------------------------------------
local tabBtns = {}
for i, tab in ipairs(TABS) do
    local btn = CreateFrame("Button", "CodexTab_" .. tab.id, CodexFrame, "UIPanelButtonTemplate")
    btn:SetSize(TAB_W, TAB_H)
    btn:SetPoint("TOPLEFT", CodexFrame, "TOPLEFT", MARGIN + (i-1)*TAB_W, -24)
    btn:SetText(tab.label)
    btn:SetFont(9)
    btn:EnableMouse(true)
    btn.tabIdx = i

    btn:SetScript("OnDraw", function(self)
        local sx, sy, sw, sh = self:GetRect()
        if activeTabIdx == self.tabIdx then
            Draw2D.Rect(sx+1, sy+1, sw-2, sh-2, 0.30, 0.35, 0.50, 0.80)
        else
            Draw2D.Rect(sx+1, sy+1, sw-2, sh-2, 0.12, 0.13, 0.18, 0.80)
        end
        Draw2D.RectBorder(sx, sy, sw, sh, 1, 0.35, 0.35, 0.45, 0.6)
    end)

    btn:SetScript("OnClick", function(self)
        activeTabIdx = self.tabIdx
        scrollOffset = 0
        selectedRecipeIdx = 1
    end)

    tabBtns[i] = btn
end

-------------------------------------------------------------------------------
-- Content rows (reusable row frames for abilities)
-------------------------------------------------------------------------------
local rowFrames = {}
for ri = 1, VISIBLE_ROWS + 1 do
    local row = CreateFrame("Frame", "CodexRow" .. ri, CodexFrame)
    row:SetSize(CODEX_W - MARGIN * 2, ROW_H)
    row:Hide()
    row:SetScript("OnDraw", function(self)
        if not self:IsShown() then return end
        local sx, sy, sw, sh = self:GetRect()
        Draw2D.Rect(sx+1, sy+1, sw-2, sh-2, 0.10, 0.11, 0.15, 0.55)
        Draw2D.RectBorder(sx, sy, sw, sh, 1, 0.28, 0.28, 0.35, 0.50)
    end)

    -- Icon button
    local iconBtn = CreateFrame("Button", "CodexRowIcon" .. ri, row, "UIPanelButtonTemplate")
    iconBtn:SetSize(48, 48)
    iconBtn:SetPoint("LEFT", row, "LEFT", 6, 0)
    iconBtn:EnableMouse(true)

    iconBtn:SetScript("OnDraw", function(self)
        if not self.data then return end
        local sx, sy, sw, sh = self:GetRect()
        local r, g, b = self.data.color[1], self.data.color[2], self.data.color[3]
        Draw2D.Rect(sx+2, sy+2, sw-4, sh-4, r, g, b, 0.75)
        Draw2D.RectBorder(sx+2, sy+2, sw-4, sh-4, 1, 0.9, 0.8, 0.5, 0.8)
        local sn = self.data.name:sub(1, 5)
        Draw2D.Text(sn, sx+4, sy+sh*0.35, 9, 1, 1, 1, 0.95)
    end)

    iconBtn:RegisterForDrag("Left")
    iconBtn:SetScript("OnDragStart", function(self)
        if self.data then
            C_Cursor.StartDrag("ability", tostring(self.data.id), -1, self.data.name, self.data.color[1], self.data.color[2], self.data.color[3])
            if GameTooltip then GameTooltip:Hide() end
        end
    end)

    iconBtn:SetScript("OnEnter", function(self)
        if self.data then
            self:SetHighlightColor(0.8, 0.8, 0.9, 0.3)
            if GameTooltip then
                GameTooltip:SetPoint("BOTTOMLEFT", self, "TOPRIGHT", 8, 8)
                GameTooltip:SetText(self.data.name)
                local info = (self.data.castTime or "Instant") .. "  |  " .. (self.data.range or "Melee")
                GameTooltip:AddLine(info, 1.0, 0.85, 0.40)
                GameTooltip:AddLine(self.data.desc, 0.8, 0.8, 0.8)
                GameTooltip:AddLine(self.data.cdText, 0.65, 0.40, 0.80)
            end
        end
    end)

    iconBtn:SetScript("OnLeave", function(self)
        self:SetHighlightColor(0, 0, 0, 0)
        if GameTooltip then GameTooltip:Hide() end
    end)

    row.iconBtn = iconBtn

    -- Name FS
    local nameFS = row:CreateFontString(nil, "HIGH")
    nameFS:SetPoint("TOPLEFT", row, "TOPLEFT", 64, -6)
    nameFS:SetSize(200, 14)
    nameFS:SetFont(12)
    nameFS:SetTextColor(0.95, 0.90, 0.70)
    nameFS:SetJustifyH("LEFT")
    row.nameFS = nameFS

    -- CD / type label
    local cdFS = row:CreateFontString(nil, "HIGH")
    cdFS:SetPoint("TOPRIGHT", row, "TOPRIGHT", -10, -6)
    cdFS:SetSize(120, 14)
    cdFS:SetFont(10)
    cdFS:SetTextColor(0.65, 0.40, 0.80)
    cdFS:SetJustifyH("RIGHT")
    row.cdFS = cdFS

    -- Description FS
    local descFS = row:CreateFontString(nil, "HIGH")
    descFS:SetPoint("TOPLEFT",     row, "TOPLEFT",     64, -22)
    descFS:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", -8,  4)
    descFS:SetFont(10)
    descFS:SetTextColor(0.70, 0.70, 0.70)
    descFS:SetJustifyH("LEFT")
    row.descFS = descFS

    rowFrames[ri] = row
end

-------------------------------------------------------------------------------
-- Crafting panel widgets (reused for all crafting tabs)
-------------------------------------------------------------------------------
local CRAFT_LIST_H = math.floor(CONTENT_H * 0.55)
local CRAFT_DET_H  = math.floor(CONTENT_H * 0.42)

-- Recipe list buttons (up to 10 visible at once)
local MAX_CRAFT_ROWS = 10
local craftRecipeBtns = {}
for ri = 1, MAX_CRAFT_ROWS do
    local btn = CreateFrame("Button", "CodexCraftBtn" .. ri, CodexFrame, "UIPanelButtonTemplate")
    btn:SetSize(CODEX_W - MARGIN * 2, 24)
    btn:Hide()
    btn:EnableMouse(true)
    btn.rowIndex = ri

    btn:SetScript("OnDraw", function(self)
        if not self:IsShown() then return end
        local sx, sy, sw, sh = self:GetRect()
        if selectedRecipeIdx == self.recipeIdx then
            Draw2D.Rect(sx+1, sy+1, sw-2, sh-2, 0.35, 0.40, 0.55, 0.70)
        else
            Draw2D.Rect(sx+1, sy+1, sw-2, sh-2, 0.10, 0.12, 0.18, 0.55)
        end
        Draw2D.RectBorder(sx, sy, sw, sh, 1, 0.25, 0.25, 0.32, 0.40)
        if self.recipeLabel then
            local canCraft = (self.recipeId and C_Craft.CanCraft(self.recipeId)) or false
            local r, g, b = canCraft and 0.3 or 0.6, canCraft and 0.9 or 0.6, canCraft and 0.3 or 0.6
            Draw2D.Text(self.recipeLabel, sx+8, sy+sh*0.28, 11, r, g, b, 0.95)
        end
    end)

    btn:SetScript("OnClick", function(self)
        if self.recipeIdx then selectedRecipeIdx = self.recipeIdx end
    end)

    craftRecipeBtns[ri] = btn
end

-- Detail panel
local craftDetail = CreateFrame("Frame", "CodexCraftDetail", CodexFrame)
craftDetail:SetSize(CODEX_W - MARGIN * 2, CRAFT_DET_H)
craftDetail:Hide()
craftDetail:SetScript("OnDraw", function(self)
    if not self:IsShown() then return end
    local sx, sy, sw, sh = self:GetRect()
    Draw2D.Rect(sx, sy, sw, sh, 0.08, 0.09, 0.13, 0.70)
    Draw2D.RectBorder(sx, sy, sw, sh, 1, 0.30, 0.30, 0.40, 0.55)
end)

local craftDetailTitle = craftDetail:CreateFontString(nil, "HIGH")
craftDetailTitle:SetPoint("TOPLEFT", craftDetail, "TOPLEFT", 8, -8)
craftDetailTitle:SetFont(12)
craftDetailTitle:SetTextColor(0.90, 0.85, 0.60)

local craftIngLines = {}
for i = 1, 4 do
    local fs = craftDetail:CreateFontString(nil, "HIGH")
    fs:SetPoint("TOPLEFT", craftDetail, "TOPLEFT", 12, -24 - (i-1)*18)
    fs:SetFont(11)
    craftIngLines[i] = fs
end

local craftBtn = CreateFrame("Button", "CodexCraftItemBtn", craftDetail, "UIPanelButtonTemplate")
craftBtn:SetSize(140, 24)
craftBtn:SetPoint("BOTTOM", craftDetail, "BOTTOM", 0, 8)
craftBtn:SetText("Craft")
craftBtn:EnableMouse(true)
craftBtn:SetScript("OnClick", function()
    if not selectedRecipeIdx then return end
    local id, _, _, _, _ = C_Craft.GetRecipeInfo(selectedRecipeIdx)
    if id and C_Craft.CanCraft(id) then
        C_Craft.Craft(id)
    end
end)

-------------------------------------------------------------------------------
-- Scroll state for crafting list
-------------------------------------------------------------------------------
local craftScrollOffset = 0
local craftFilter = "All"

-------------------------------------------------------------------------------
-- TalentTrees configuration
-------------------------------------------------------------------------------
local TalentTrees = {
    -- Warrior
    [0] = {
        { index = 0, name = "Cruelty", row = 1, col = 1, maxRank = 3, desc = "Increases Slash damage by +2 per rank." },
        { index = 1, name = "Imp. Sprint", row = 1, col = 2, maxRank = 2, desc = "Increases Sprint speed by +20% per rank." },
        { index = 2, name = "Shield Block", row = 2, col = 1, maxRank = 3, reqIdx = 0, reqRank = 3, desc = "Increases defense by +2 per rank." },
        { index = 3, name = "Blood Frenzy", row = 3, col = 1, maxRank = 1, reqIdx = 2, reqRank = 3, desc = "Unlocks War Cry ability." },
        { index = 4, name = "Mace Spec.", row = 2, col = 2, maxRank = 3, reqIdx = 1, reqRank = 2, desc = "Increases basic physical damage." },
    },
    -- Mage
    [1] = {
        { index = 0, name = "Impact", row = 1, col = 1, maxRank = 3, desc = "Increases Fireball damage by +2 per rank." },
        { index = 1, name = "Arcane Inst.", row = 1, col = 2, maxRank = 3, desc = "Increases spell damage by +10% per rank." },
        { index = 2, name = "Frostbite", row = 2, col = 1, maxRank = 3, reqIdx = 0, reqRank = 3, desc = "Increases Frostbolt slow effects." },
        { index = 3, name = "Presence of Mind", row = 3, col = 1, maxRank = 1, reqIdx = 2, reqRank = 3, desc = "Unlocks Arcane Surge ability." },
        { index = 4, name = "Mending Touch", row = 2, col = 2, maxRank = 3, reqIdx = 1, reqRank = 3, desc = "Increases Mend healing by +5 per rank." },
    },
    -- Rogue
    [2] = {
        { index = 0, name = "Malice", row = 1, col = 1, maxRank = 3, desc = "Increases Backstab damage by +3 per rank." },
        { index = 1, name = "Camo", row = 1, col = 2, maxRank = 3, desc = "Increases Stealth movement speed by +15% per rank." },
        { index = 2, name = "Puncture", row = 2, col = 1, maxRank = 3, reqIdx = 0, reqRank = 3, desc = "Increases critical strike chance." },
        { index = 3, name = "Master of Shadows", row = 3, col = 2, maxRank = 1, reqIdx = 1, reqRank = 3, desc = "Reduces Stealth SP cost to 0." },
        { index = 4, name = "Assassination", row = 3, col = 1, maxRank = 1, reqIdx = 2, reqRank = 3, desc = "Makes Backstab deal 3x damage from behind." },
    }
}

-------------------------------------------------------------------------------
-- Filter panel / row (crafting only)
-------------------------------------------------------------------------------
local filterBtns = {}
local filterOptions = { "All", "Available", "Unavailable", "Learned", "Unlearned" }

local filterRowFrame = CreateFrame("Frame", "CodexCraftFilterRow", CodexFrame)
filterRowFrame:SetSize(CODEX_W - MARGIN * 2, 20)
filterRowFrame:SetPoint("TOPLEFT", CodexFrame, "TOPLEFT", MARGIN, CONTENT_Y - 4)

for i, opt in ipairs(filterOptions) do
    local btn = CreateFrame("Button", "CodexFilterBtn_" .. opt, filterRowFrame)
    btn:SetSize(80, 16)
    btn:SetPoint("LEFT", filterRowFrame, "LEFT", (i-1)*85, 0)
    btn:EnableMouse(true)
    
    local text = btn:CreateFontString(nil, "OVERLAY")
    text:SetPoint("CENTER", btn, "CENTER", 0, 0)
    text:SetText(opt)
    text:SetFont(10)
    btn.text = text
    
    btn:SetScript("OnClick", function()
        craftFilter = opt
        craftScrollOffset = 0
        updateContent()
    end)
    filterBtns[opt] = btn
end

-------------------------------------------------------------------------------
-- Talent panel
-------------------------------------------------------------------------------
local talentPanel = CreateFrame("Frame", "CodexTalentsPanel", CodexFrame)
talentPanel:SetSize(CODEX_W - MARGIN * 2, CODEX_H - TAB_H - 60)
talentPanel:SetPoint("TOPLEFT", CodexFrame, "TOPLEFT", MARGIN, CONTENT_Y)
talentPanel:Hide()

local talentPointsFS = talentPanel:CreateFontString(nil, "OVERLAY")
talentPointsFS:SetPoint("TOPLEFT", talentPanel, "TOPLEFT", 10, 5)
talentPointsFS:SetFont(12)

local talentResetBtn = CreateFrame("Button", "CodexTalentResetBtn", talentPanel, "UIPanelButtonTemplate")
talentResetBtn:SetSize(100, 22)
talentResetBtn:SetPoint("TOPRIGHT", talentPanel, "TOPRIGHT", -10, 5)
talentResetBtn:SetText("Reset Tree")
talentResetBtn:SetScript("OnClick", function()
    C_Quest.ResetTalents()
end)

local talentBtns = {}
for i = 1, 10 do
    local btn = CreateFrame("Button", "CodexTalentBtn_" .. i, talentPanel, "UIPanelButtonTemplate")
    btn:SetSize(120, 50)
    btn:EnableMouse(true)
    
    local nameFS = btn:CreateFontString(nil, "OVERLAY")
    nameFS:SetPoint("TOP", btn, "TOP", 0, -4)
    nameFS:SetFont(11)
    btn.nameFS = nameFS
    
    local rankFS = btn:CreateFontString(nil, "OVERLAY")
    rankFS:SetPoint("BOTTOM", btn, "BOTTOM", 0, 4)
    rankFS:SetFont(10)
    btn.rankFS = rankFS
    
    talentBtns[i] = btn
end

local talentLines = {}
for i = 1, 10 do
    local line = CreateFrame("Frame", nil, talentPanel)
    line:Hide()
    line:SetBackdropBorderColor(0, 0, 0, 0)
    talentLines[i] = line
end

-------------------------------------------------------------------------------
-- Helper: get filtered recipe indices for a profession
-------------------------------------------------------------------------------
local function getFilteredRecipes(profession)
    local results = {}
    local count = C_Craft.GetRecipeCount()
    local stats = C_Quest.GetPlayerStats()
    local profLevels = stats.professions or {0, 0, 0, 0}
    local profIdx = 0
    if profession == "Metalworking" then profIdx = 0
    elseif profession == "Cooking" then profIdx = 1
    elseif profession == "Herbalism" then profIdx = 2
    elseif profession == "Leatherworking" then profIdx = 3
    end
    local currentLevel = profLevels[profIdx] or 0

    for i = 1, count do
        local id, name, out_id, out_cnt, ing_count, min_level, prof = C_Craft.GetRecipeInfo(i)
        if id and prof == profession then
            local isLearned = (currentLevel >= min_level)
            local canCraft = C_Craft.CanCraft(id)
            
            local match = false
            if craftFilter == "All" then
                match = true
            elseif craftFilter == "Available" then
                match = canCraft and isLearned
            elseif craftFilter == "Unavailable" then
                match = not canCraft and isLearned
            elseif craftFilter == "Learned" then
                match = isLearned
            elseif craftFilter == "Unlearned" then
                match = not isLearned
            end
            
            if match then
                table.insert(results, { globalIdx = i, id = id, name = name,
                                        out_id = out_id, out_cnt = out_cnt,
                                        min_level = min_level, profession = prof })
            end
        end
    end
    return results
end

-------------------------------------------------------------------------------
-- Update display: called each frame
-------------------------------------------------------------------------------
local function updateContent()
    local tab = TABS[activeTabIdx]
    if not tab then return end

    -- Hide everything
    for _, r in ipairs(rowFrames) do r:Hide() end
    for _, b in ipairs(craftRecipeBtns) do b:Hide() end
    craftDetail:Hide()
    filterRowFrame:Hide()
    talentPanel:Hide()

    local contentY = CONTENT_Y
    local contentX = MARGIN

    if tab.kind == "abilities" then
        -- Filter abilities for this tab
        local visAbils = {}
        for _, ab in ipairs(AllAbilities) do
            if ab.tab == tab.id then
                table.insert(visAbils, ab)
            end
        end

        local startIdx = scrollOffset + 1
        local shown = 0
        for i = startIdx, #visAbils do
            if shown >= VISIBLE_ROWS then break end
            shown = shown + 1
            local ab = visAbils[i]
            local row = rowFrames[shown]
            row:SetPoint("TOPLEFT", CodexFrame, "TOPLEFT", contentX,
                         contentY - (shown-1)*(ROW_H + ROW_GAP))
            row:Show()
            row.iconBtn.data = ab
            row.nameFS:SetText(ab.name)
            row.cdFS:SetText(ab.cdText)
            row.descFS:SetText(ab.desc)
        end

        -- Scroll hint
        if #visAbils == 0 then
            local row = rowFrames[1]
            row:SetPoint("TOPLEFT", CodexFrame, "TOPLEFT", contentX, contentY)
            row:Show()
            row.iconBtn.data = nil
            row.nameFS:SetText("(No abilities yet)")
            row.cdFS:SetText("")
            row.descFS:SetText("Abilities for this path will be unlocked as you level up.")
        end

    elseif tab.kind == "crafting" then
        filterRowFrame:Show()
        -- Update filter button text colors based on active filter
        for opt, btn in pairs(filterBtns) do
            if craftFilter == opt then
                btn.text:SetTextColor(0.9, 0.8, 0.2) -- yellow active
            else
                btn.text:SetTextColor(0.6, 0.6, 0.6) -- gray inactive
            end
        end

        local recipes = getFilteredRecipes(tab.profession)
        local MAX_VISIBLE_CRAFT = 7
        local listY = contentY - 24

        -- Display recipe list
        local startR = craftScrollOffset + 1
        local shown = 0
        for i = startR, #recipes do
            if shown >= MAX_VISIBLE_CRAFT then break end
            shown = shown + 1
            local rec = recipes[i]
            local btn = craftRecipeBtns[shown]
            btn:SetPoint("TOPLEFT", CodexFrame, "TOPLEFT", contentX,
                         listY - (shown-1)*26)
            btn.recipeIdx = rec.globalIdx
            btn.recipeId  = rec.id
            local stats = C_Quest.GetPlayerStats()
            local profLevels = stats.professions or {0, 0, 0, 0}
            local profIdx = 0
            if rec.profession == "Metalworking" then profIdx = 0
            elseif rec.profession == "Cooking" then profIdx = 1
            elseif rec.profession == "Herbalism" then profIdx = 2
            elseif rec.profession == "Leatherworking" then profIdx = 3
            end
            local currentLevel = profLevels[profIdx] or 0
            local isLearned = (currentLevel >= (rec.min_level or 0))
            local canCraft = C_Craft.CanCraft(rec.id) and isLearned
            btn.recipeLabel = string.format("%s (x%d)", rec.name or "?", rec.out_cnt or 1)
            btn:Show()
        end

        if #recipes == 0 then
            local btn = craftRecipeBtns[1]
            btn:SetPoint("TOPLEFT", CodexFrame, "TOPLEFT", contentX, listY)
            btn.recipeIdx  = nil
            btn.recipeId   = nil
            btn.recipeLabel = "(No recipes)"
            btn:Show()
        end

        -- Detail panel
        local detailY = listY - MAX_VISIBLE_CRAFT * 26 - 8
        craftDetail:SetPoint("TOPLEFT", CodexFrame, "TOPLEFT", contentX, detailY)
        craftDetail:Show()

        -- Fill detail
        if selectedRecipeIdx and selectedRecipeIdx > 0 then
            local id, name, out_id, out_cnt, ing_count, min_level, prof = C_Craft.GetRecipeInfo(selectedRecipeIdx)
            if id then
                local outName = GetItemInfo(out_id) or "?"
                local reqText = ""
                if min_level and min_level > 0 then
                    reqText = string.format(" (Req. Lvl %d)", min_level)
                end
                craftDetailTitle:SetText(string.format("Craft: %s (x%d)%s", outName, out_cnt or 1, reqText))
                for ci = 1, 4 do
                    if ci <= (ing_count or 0) then
                        local ing_id, ing_req = C_Craft.GetRecipeIngredient(id, ci)
                        if ing_id then
                            local iname = GetItemInfo(ing_id) or "?"
                            local have = GetItemCountInBag(ing_id)
                            craftIngLines[ci]:SetText(string.format("  %s: %d / %d", iname, have, ing_req))
                            if have >= ing_req then
                                craftIngLines[ci]:SetTextColor(0.35, 0.90, 0.35)
                            else
                                craftIngLines[ci]:SetTextColor(0.90, 0.30, 0.30)
                            end
                        else
                            craftIngLines[ci]:SetText("")
                        end
                    else
                        craftIngLines[ci]:SetText("")
                    end
                end
                
                local stats = C_Quest.GetPlayerStats()
                local profLevels = stats.professions or {0, 0, 0, 0}
                local profIdx = 0
                if prof == "Metalworking" then profIdx = 0
                elseif prof == "Cooking" then profIdx = 1
                elseif prof == "Herbalism" then profIdx = 2
                elseif prof == "Leatherworking" then profIdx = 3
                end
                local currentLevel = profLevels[profIdx] or 0
                local levelOk = (currentLevel >= (min_level or 0))
                
                local canCraft = C_Craft.CanCraft(id) and levelOk
                if not levelOk then
                    craftBtn:SetText("Requires Lvl " .. min_level)
                    craftBtn:Disable()
                elseif not C_Craft.CanCraft(id) then
                    craftBtn:SetText("Lacking Materials")
                    craftBtn:Disable()
                else
                    craftBtn:SetText("Craft " .. (name or ""))
                    craftBtn:Enable()
                end
            else
                craftDetailTitle:SetText("Select a recipe")
                for ci = 1, 4 do craftIngLines[ci]:SetText("") end
                craftBtn:SetText("Craft")
                craftBtn:Disable()
            end
        else
            craftDetailTitle:SetText("Select a recipe")
            for ci = 1, 4 do craftIngLines[ci]:SetText("") end
            craftBtn:SetText("Craft")
            craftBtn:Disable()
        end

    elseif tab.kind == "talents" then
        talentPanel:Show()
        
        local stats = C_Quest.GetPlayerStats()
        local classId = stats.class_id or 0
        local level = stats.level or 1
        local talents = stats.talents or {}
        
        local totalSpent = 0
        for idx = 0, 15 do
            totalSpent = totalSpent + (talents[idx] or 0)
        end
        local totalAvail = level - 1 + 20
        if totalAvail < 20 then totalAvail = 20 end
        local remainingPoints = totalAvail - totalSpent
        if remainingPoints < 0 then remainingPoints = 0 end
        
        talentPointsFS:SetText(string.format("Talent Points: %d / %d Spent (%d Remaining)", totalSpent, totalAvail, remainingPoints))
        
        local tree = TalentTrees[classId] or {}
        
        -- Hide all lines first
        for _, line in ipairs(talentLines) do line:Hide() end
        
        local lineIdx = 0
        for i, t in ipairs(tree) do
            local btn = talentBtns[i]
            if btn then
                -- Position
                local x = 40 + (t.col - 1) * 160
                local y = -45 - (t.row - 1) * 90
                btn:SetPoint("TOPLEFT", talentPanel, "TOPLEFT", x, y)
                btn:Show()
                
                local currentRank = talents[t.index] or 0
                btn.nameFS:SetText(t.name)
                btn.rankFS:SetText(string.format("%d / %d", currentRank, t.maxRank))
                
                -- Check requirements
                local reqOk = true
                if t.reqIdx then
                    local reqRank = talents[t.reqIdx] or 0
                    if reqRank < t.reqRank then
                        reqOk = false
                    end
                end
                
                if reqOk then
                    btn.nameFS:SetTextColor(0.9, 0.8, 0.2)
                    btn.rankFS:SetTextColor(0.9, 0.8, 0.2)
                    if remainingPoints > 0 and currentRank < t.maxRank then
                        btn:Enable()
                    else
                        btn:Disable()
                    end
                else
                    btn.nameFS:SetTextColor(0.5, 0.5, 0.5)
                    btn.rankFS:SetTextColor(0.5, 0.5, 0.5)
                    btn:Disable()
                end
                
                btn:SetScript("OnClick", function()
                    if remainingPoints > 0 and currentRank < t.maxRank and reqOk then
                        C_Quest.LearnTalent(t.index)
                    end
                end)

                btn:SetScript("OnEnter", function(self)
                    if GameTooltip then
                        GameTooltip:SetPoint("BOTTOMLEFT", self, "TOPRIGHT", 8, 8)
                        GameTooltip:SetText(t.name)
                        GameTooltip:AddLine(t.desc, 0.8, 0.8, 0.8)
                        if t.reqIdx then
                            local reqT = tree[t.reqIdx + 1]
                            GameTooltip:AddLine(string.format("Requires: %s (%d/%d)", reqT.name, t.reqRank, reqT.maxRank), 0.9, 0.3, 0.3)
                        end
                        GameTooltip:Show()
                    end
                end)
                btn:SetScript("OnLeave", function()
                    if GameTooltip then GameTooltip:Hide() end
                end)
                
                -- Draw connection line if there is a requirement
                if t.reqIdx then
                    local reqT = tree[t.reqIdx + 1]
                    if reqT then
                        lineIdx = lineIdx + 1
                        local line = talentLines[lineIdx]
                        if line then
                            local rx = 40 + (reqT.col - 1) * 160 + 60
                            local ry = -45 - (reqT.row - 1) * 90 - 50
                            local tx = 40 + (t.col - 1) * 160 + 60
                            local ty = -45 - (t.row - 1) * 90
                            
                            line:SetPoint("TOPLEFT", talentPanel, "TOPLEFT", rx - 1, ry)
                            line:SetSize(2, ry - ty)
                            local reqRank = talents[t.reqIdx] or 0
                            if reqRank >= t.reqRank then
                                line:SetBackdropColor(0.9, 0.8, 0.2, 0.8) -- gold
                            else
                                line:SetBackdropColor(0.3, 0.3, 0.3, 0.8) -- gray
                            end
                            line:Show()
                        end
                    end
                end
            end
        end
        
        -- Hide remaining buttons
        for i = #tree + 1, 10 do
            if talentBtns[i] then talentBtns[i]:Hide() end
        end
    end
end

-- Help footer
local helpFS = CodexFrame:CreateFontString(nil, "HIGH")
helpFS:SetPoint("BOTTOMLEFT",  CodexFrame, "BOTTOMLEFT",  MARGIN, 8)
helpFS:SetPoint("BOTTOMRIGHT", CodexFrame, "BOTTOMRIGHT", -MARGIN, 8)
helpFS:SetHeight(14)
helpFS:SetFont(9)
helpFS:SetJustifyH("CENTER")
helpFS:SetTextColor(0.50, 0.50, 0.55)
helpFS:SetText("Click an ability icon to pick it up and place it on an action bar.  |  K = close")

-------------------------------------------------------------------------------
-- OnUpdate – key handler + content refresh
-------------------------------------------------------------------------------
local kDebounce = false
local lastTabIdx = -1
CodexFrame:SetScript("OnUpdate", function(self, dt)
    -- Tab changed, reset scroll
    if activeTabIdx ~= lastTabIdx then
        lastTabIdx = activeTabIdx
        scrollOffset = 0
        craftScrollOffset = 0
        selectedRecipeIdx = 1
    end

    updateContent()

    -- Scroll via mouse wheel when shown
    if CodexFrame:IsShown() then
        local mx, my = GetMousePosition()
        local cx, cy, cw, ch = CodexFrame:GetRect()
        if mx >= cx and mx <= cx + cw and my >= cy and my <= cy + ch then
            local wheel = GetMouseWheelMove()
            if wheel ~= 0 then
                local tab = TABS[activeTabIdx]
                if tab.kind == "abilities" then
                    scrollOffset = math.max(0, scrollOffset - wheel)
                else
                    craftScrollOffset = math.max(0, craftScrollOffset - wheel)
                end
                ConsumeMouseWheel()
            end
        end
    end
end)

local keyDebounce = false
local pollFrame = CreateFrame("Frame", "CodexPollFrame", UIParent)
pollFrame:SetScript("OnUpdate", function(self, dt)
    local kPressed = IsKeyPressed(75) -- K
    if kPressed and not keyDebounce then
        keyDebounce = true
        if CodexFrame:IsShown() then
            CodexFrame:Hide()
        else
            CodexFrame:Show()
            CodexFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 20)
        end
    elseif not kPressed then
        keyDebounce = false
    end
end)

-- Register inventory update for crafting ingredient refresh
CodexFrame:RegisterEvent("INVENTORY_UPDATE")
CodexFrame:SetScript("OnEvent", function(self, event) end)
