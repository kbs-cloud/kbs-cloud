-------------------------------------------------------------------------------
-- WorldMap.lua  (CoreUI)
-- Full world map opened by the "M" button on the minimap.
-- Displayed as a moveable, resizable floating panel centred on screen.
--
-- Layout
-- ──────
--   WorldMapFrame   – floating panel (moveable, resizable)
--   ├─ Title bar    – drag handle + title text
--   ├─ Close [×]    – top-right
--   ├─ mapDisplay   – sub-frame with the tile texture + entity dots
--   ├─ posLabel     – player world-position text
--   ├─ tileLabel    – current tile name
--   └─ legendFrame  – colour legend
--
-- Global API
-- ──────────
--   ToggleWorldMap()  – called by MinimapWorldMapBtn OnClick
-------------------------------------------------------------------------------

local WM_W       = 740  -- initial window width
local WM_H       = 780  -- initial window height
local MAP_PAD    = 10   -- padding inside the window for the map area
local TITLE_H    = 28   -- height of the title / drag bar
local BOTTOM_H   = 52   -- height of the bottom status strip
-- Derived map display dimensions (fixed at creation; mapDisplay OnDraw uses GetRect)
local MAP_W = WM_W - MAP_PAD * 2
local MAP_H = WM_H - TITLE_H - MAP_PAD * 2 - BOTTOM_H

-- World Map Viewport variables (Option A)
local wmCenter = { x = 0, z = 0 }
local wmZoom = 600.0
local wmZoomMin = 100.0
local wmZoomMax = 4000.0
local isDraggingMap = false
local lastMouseX = 0
local lastMouseY = 0
local followPlayer = true

-------------------------------------------------------------------------------
-- Quest Objectives Detection Helpers
-------------------------------------------------------------------------------
local KIND_MAP = {
    none = 0, player = 1, container = 2, rabbit = 3, chicken = 4,
    loot = 5, fox = 6, ore_node = 7, flower_node = 8, shopkeeper = 9, questgiver = 10
}

local MOB_DROPS = {
    [3] = { [17] = true, [19] = true, [27] = true, [14] = true }, -- rabbit drops
    [4] = { [17] = true, [16] = true, [18] = true, [22] = true, [23] = true, [12] = true }, -- chicken drops
    [6] = { [17] = true, [20] = true, [21] = true, [9] = true, [10] = true, [2] = true, [4] = true, [28] = true, [13] = true, [29] = true, [26] = true } -- fox drops
}

local function getActiveQuestObjectives()
    local active = C_Quest.GetActiveQuests()
    if not active then return nil end

    local objectives = {}

    local function getInventoryItemCount(itemId)
        if itemId == 30 then
            local stats = C_Quest.GetPlayerStats()
            return stats and stats.coins or 0
        end
        local count = 0
        if GetInventorySlotInfo then
            for slot = 1, INVENTORY_SLOTS do
                local id, c = GetInventorySlotInfo(slot)
                if id == itemId then
                    count = count + c
                end
            end
        end
        return count
    end

    for _, aq in ipairs(active) do
        if not TrackedQuests or TrackedQuests[aq.quest_id] ~= false then
            local qName, _, obj1_type, obj1_target, obj1_count, obj2_type, obj2_target, obj2_count = C_Quest.GetQuestInfo(aq.quest_id)
            if qName then
                -- Check Objective 1
                if obj1_type > 0 then
                    local current = 0
                    if obj1_type == 1 then -- KILL
                        current = aq.progress1
                    elseif obj1_type == 2 then -- GATHER
                        current = getInventoryItemCount(obj1_target)
                    end
                    if current < obj1_count then
                        table.insert(objectives, {
                            type = obj1_type,
                            target = obj1_target,
                        })
                    end
                end

                -- Check Objective 2
                if obj2_type > 0 then
                    local current = 0
                    if obj2_type == 1 then -- KILL
                        current = aq.progress2
                    elseif obj2_type == 2 then -- GATHER
                        current = getInventoryItemCount(obj2_target)
                    end
                    if current < obj2_count then
                        table.insert(objectives, {
                            type = obj2_type,
                            target = obj2_target,
                        })
                    end
                end
            end
        end
    end

    return objectives
end

local function isEntityQuestObjective(kind, ex, ez, activeObjs)
    if not activeObjs or #activeObjs == 0 then return false end
    local kindNum = KIND_MAP[kind]
    if not kindNum then return false end

    for _, obj in ipairs(activeObjs) do
        if obj.type == 1 then -- KILL
            if kindNum == obj.target then
                return true
            end
        elseif obj.type == 2 then -- GATHER
            -- Check if direct source node
            if kindNum == 7 then -- ore_node
                local is_iron = (math.floor(ex * 10.0 + ez * 10.0) % 2) == 0
                local item_id = is_iron and 21 or 20
                if item_id == obj.target then
                    return true
                end
            elseif kindNum == 8 then -- flower_node
                local is_lavender = (math.floor(ex * 10.0 + ez * 10.0) % 2) == 0
                local item_id = is_lavender and 23 or 22
                if item_id == obj.target then
                    return true
                end
            end

            -- Check if mob drop
            local drops = MOB_DROPS[kindNum]
            if drops and drops[obj.target] then
                return true
            end
        elseif obj.type == 3 then -- TALK
            if kindNum == obj.target then
                return true
            end
        end
    end

    return false
end

-------------------------------------------------------------------------------
-- Entity dot colours (same palette as Minimap.lua)
-------------------------------------------------------------------------------
local function entityColor(kind, isPlayer)
    if isPlayer                              then return 0.95, 0.20, 0.20 end
    if kind == "container"                   then return 0.95, 0.87, 0.30 end
    if kind == "loot"                        then return 0.95, 0.63, 0.24 end
    if kind == "shopkeeper"                  then return 0.60, 0.30, 0.90 end
    if kind == "player"                      then return 0.40, 0.60, 1.00 end
    return 0.70, 0.70, 0.70
end

-------------------------------------------------------------------------------
-- WorldMapFrame – floating, moveable, resizable window
-------------------------------------------------------------------------------
WorldMapFrame = CreateFrame("Frame", "WorldMapFrame", UIParent, "BasicPanelTemplate")
WorldMapFrame:SetSize(WM_W, WM_H)
-- Anchor CENTER to screen centre – with an explicit size this works correctly
WorldMapFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
WorldMapFrame:SetFrameStrata("FULLSCREEN")
WorldMapFrame:SetMovable(true)
WorldMapFrame:SetResizable(true)
WorldMapFrame:EnableMouse(true)
WorldMapFrame:Hide()

-- Dark vignette background drawn behind children
WorldMapFrame:SetScript("OnDraw", function(self)
    local sx, sy, sw, sh = self:GetRect()
    -- panel background
    Draw2D.Rect(sx, sy, sw, sh, 0.05, 0.06, 0.10, 0.97)
    Draw2D.RectBorder(sx, sy, sw, sh, 2, 0.45, 0.42, 0.28, 1.0)
end)

-------------------------------------------------------------------------------
-- Title bar (also acts as drag handle)
-------------------------------------------------------------------------------
local titleBar = CreateFrame("Button", "WorldMapTitleBar", WorldMapFrame)
titleBar:SetPoint("TOPLEFT",  WorldMapFrame, "TOPLEFT",  0, 0)
titleBar:SetPoint("TOPRIGHT", WorldMapFrame, "TOPRIGHT", 0, 0)
titleBar:SetHeight(TITLE_H)
titleBar:EnableMouse(true)
titleBar:SetMovable(true)
titleBar:SetScript("OnDraw", function(self)
    local sx, sy, sw, sh = self:GetRect()
    Draw2D.Rect(sx, sy, sw, sh, 0.12, 0.10, 0.16, 0.95)
    Draw2D.Text("World Map", sx + sw * 0.5 - 38, sy + 7, 14, 0.90, 0.82, 0.55, 1.0)
end)
titleBar:SetScript("OnClick", function(self)
    -- drag handled by frame system
    WorldMapFrame:StartMoving()
end)

-------------------------------------------------------------------------------
-- Close button
-------------------------------------------------------------------------------
local closeBtn = CreateFrame("Button", "WorldMapCloseBtn", WorldMapFrame,
                             "UIPanelButtonTemplate")
closeBtn:SetSize(24, 24)
closeBtn:SetPoint("TOPRIGHT", WorldMapFrame, "TOPRIGHT", -4, -2)
closeBtn:SetText("x")
closeBtn:EnableMouse(true)
closeBtn:SetScript("OnClick", function()
    WorldMapFrame:Hide()
end)

-- mapDisplay is a thin invisible frame used only as a hook for the OnDraw script.
-- We DON'T rely on its own GetRect() for size because the frame system stores a
-- static w/h that doesn't update when the parent is resized.  Instead we read
-- WorldMapFrame:GetRect() every draw and derive the map area from that.
local mapDisplay = CreateFrame("Frame", "WorldMapDisplay", WorldMapFrame)
mapDisplay:SetSize(MAP_W, MAP_H)
mapDisplay:SetPoint("TOPLEFT", WorldMapFrame, "TOPLEFT", MAP_PAD, -(TITLE_H + MAP_PAD))

mapDisplay:SetScript("OnDraw", function(self)
    -- Dynamically derive the map draw area from the parent window's current rect
    -- (handles resize correctly without needing multi-point anchor support)
    local wx, wy, ww, wh = WorldMapFrame:GetRect()
    local fx = wx + MAP_PAD
    local fy = wy + TITLE_H + MAP_PAD
    local fw = ww - MAP_PAD * 2
    local fh = wh - TITLE_H - MAP_PAD * 2 - BOTTOM_H

    if fw <= 0 or fh <= 0 then return end

    -- Draw the procedural dynamic world map using Option A
    if GetMinimapBuilt() then
        C_WorldMap.DrawTexture(fx, fy, fw, fh, wmCenter.x, wmCenter.z, wmZoom)
    else
        Draw2D.Rect(fx, fy, fw, fh, 0.05, 0.07, 0.10, 1.0)
        Draw2D.Text("Map not yet received", fx + fw * 0.5 - 70, fy + fh * 0.5 - 8,
                    14, 0.55, 0.55, 0.60, 1.0)
    end

    local wmOX = wmCenter.x - wmZoom / 2
    local wmOZ = wmCenter.z - wmZoom / 2
    local wmWS = wmZoom

    -- 1. Draw Encampments/Flightpoints
    if C_WorldMap.GetEncampments then
        local encampments = C_WorldMap.GetEncampments(wmCenter.x, wmCenter.z, wmZoom) or {}
        for _, ept in ipairs(encampments) do
            local u = (ept.x - wmOX) / wmWS
            local v = (ept.z - wmOZ) / wmWS
            if u >= 0 and u <= 1 and v >= 0 and v <= 1 then
                local sx = fx + u * fw
                local sy = fy + v * fh
                Draw2D.Circle(sx, sy, 5, 0.2, 0.9, 0.4, 0.9)
                Draw2D.CircleLines(sx, sy, 8, 0.2, 0.9, 0.4, 0.5)
                Draw2D.Text(ept.name, sx - 25, sy - 14, 10, 0.4, 0.9, 0.6, 0.9)
            end
        end
    end

    -- 2. Draw Entities
    local px, pz = UnitPosition("player")
    local activeObjectives = getActiveQuestObjectives()

    for i = 0, MAX_ENTITIES - 1 do
        local kind, ex, ez, mhint, alive = GetEntityInfo(i)
        if alive then
            local isPlayer = (kind == "player")
                          and math.abs(ex - px) < 0.5
                          and math.abs(ez - pz) < 0.5

            -- Filter out clutter NPCs (rabbits, chickens, foxes, gathering nodes)
            local shouldDraw = false
            if isPlayer then
                shouldDraw = true
            elseif kind == "player" then
                shouldDraw = true
            elseif kind == "container" or kind == "loot" then
                shouldDraw = true
            elseif kind == "shopkeeper" or kind == "questgiver" then
                shouldDraw = true
            end

            local isQuestTarget = false
            if not isPlayer and kind ~= "player" and kind ~= "shopkeeper" and kind ~= "questgiver" and kind ~= "container" and kind ~= "loot" then
                if isEntityQuestObjective(kind, ex, ez, activeObjectives) then
                    isQuestTarget = true
                    shouldDraw = true
                end
            end

            if shouldDraw then
                -- Project world → display-frame pixels using world map bounds
                local u = (ex - wmOX) / wmWS
                local v = (ez - wmOZ) / wmWS

                if u >= 0 and u <= 1 and v >= 0 and v <= 1 then
                    local sx = fx + u * fw
                    local sy = fy + v * fh

                    if isPlayer then
                        -- Draw player facing direction arrow
                        local yaw = UnitFacing("player")
                        Draw2D.Arrow(sx, sy, 9, yaw, 0.95, 0.20, 0.20, 0.95)
                    elseif isQuestTarget then
                        -- Draw quest target: cyan dot with a black border
                        Draw2D.Circle(sx, sy, 4, 0.0, 0.0, 0.0, 0.8)
                        Draw2D.Circle(sx, sy, 3, 0.1, 0.9, 0.9, 0.95)
                    elseif kind == "questgiver" then
                        -- Draw quest status indicator
                        local qStatus = C_Quest.GetNPCQuestStatus(i)
                        local txt = ""
                        local r, g, b = 0.6, 0.6, 0.6
                        if qStatus == 2 then
                            txt = "?"
                            r, g, b = 0.95, 0.85, 0.10
                        elseif qStatus == 0 then
                            txt = "!"
                            r, g, b = 0.95, 0.85, 0.10
                        elseif qStatus == 1 then
                            txt = "?"
                            r, g, b = 0.6, 0.6, 0.6
                        elseif qStatus == 3 then
                            txt = "!"
                            r, g, b = 0.6, 0.6, 0.6
                        end

                        if txt ~= "" then
                            Draw2D.Text(txt, sx - 3, sy - 6, 16, 0, 0, 0, 0.8)
                            Draw2D.Text(txt, sx - 4, sy - 7, 16, r, g, b, 1.0)
                        else
                            Draw2D.Circle(sx, sy, 3, 0.70, 0.70, 0.70, 0.92)
                        end
                    elseif kind == "shopkeeper" then
                        Draw2D.Circle(sx, sy, 4, 0.6, 0.3, 0.9, 0.95) -- purple
                    else
                        local r_col, g_col, b_col = entityColor(kind, false)
                        Draw2D.Circle(sx, sy, 3, r_col, g_col, b_col, 0.92)
                    end
                end
            end
        end
    end

    -- Compass rose labels at the edges
    Draw2D.Text("N", fx + fw * 0.5 - 4, fy + 4,           13, 0.95, 0.95, 0.80, 1.0)
    Draw2D.Text("S", fx + fw * 0.5 - 4, fy + fh - 16,     13, 0.95, 0.95, 0.80, 1.0)
    Draw2D.Text("W", fx + 6,            fy + fh * 0.5 - 6, 13, 0.95, 0.95, 0.80, 1.0)
    Draw2D.Text("E", fx + fw - 14,      fy + fh * 0.5 - 6, 13, 0.95, 0.95, 0.80, 1.0)

    -- Border
    Draw2D.RectBorder(fx, fy, fw, fh, 1, 0.45, 0.42, 0.28, 0.8)
end)

-------------------------------------------------------------------------------
-- Player position + current tile labels (bottom strip inside the window)
-------------------------------------------------------------------------------
local posLabel = WorldMapFrame:CreateFontString(nil, "HIGH")
posLabel:SetPoint("BOTTOMLEFT", WorldMapFrame, "BOTTOMLEFT", MAP_PAD, 30)
posLabel:SetSize(340, 18)
posLabel:SetFont(13)
posLabel:SetJustifyH("LEFT")
posLabel:SetTextColor(0.75, 0.82, 0.90)
posLabel:SetText("Position: ?, ?")

local tileLabel = WorldMapFrame:CreateFontString(nil, "HIGH")
tileLabel:SetPoint("BOTTOMLEFT", WorldMapFrame, "BOTTOMLEFT", MAP_PAD, 12)
tileLabel:SetSize(340, 16)
tileLabel:SetFont(12)
tileLabel:SetJustifyH("LEFT")
tileLabel:SetTextColor(0.65, 0.72, 0.65)
tileLabel:SetText("Tile: unknown")

local recenterBtn = CreateFrame("Button", "WorldMapRecenterBtn", WorldMapFrame, "UIPanelButtonTemplate")
recenterBtn:SetSize(80, 22)
recenterBtn:SetPoint("BOTTOMLEFT", WorldMapFrame, "BOTTOMLEFT", 220, 16)
recenterBtn:SetText("Recenter")
recenterBtn:SetFrameStrata("HIGH")
recenterBtn:EnableMouse(true)
recenterBtn:SetScript("OnClick", function()
    local px, pz = UnitPosition("player")
    if px and pz then
        wmCenter.x = px
        wmCenter.z = pz
        followPlayer = true
    end
end)

-------------------------------------------------------------------------------
-- Legend  (bottom-right of window)
-------------------------------------------------------------------------------
local legendItems = {
    { label = "You",         r = 0.95, g = 0.20, b = 0.20 },
    { label = "Merchant",    r = 0.60, g = 0.30, b = 0.90 },
    { label = "Quest Giver", r = 0.95, g = 0.85, b = 0.10 },
    { label = "Quest Target",r = 0.10, g = 0.90, b = 0.90 },
    { label = "Container",   r = 0.95, g = 0.87, b = 0.30 },
    { label = "Loot",        r = 0.95, g = 0.63, b = 0.24 },
    { label = "Camp",        r = 0.20, g = 0.90, b = 0.40 },
}

local legendFrame = CreateFrame("Frame", "WorldMapLegend", WorldMapFrame,
                                "BasicPanelTemplate")
legendFrame:SetSize(120, 6 + #legendItems * 18)
legendFrame:SetPoint("BOTTOMRIGHT", WorldMapFrame, "BOTTOMRIGHT", -MAP_PAD, MAP_PAD)

for idx, item in ipairs(legendItems) do
    local dot = legendFrame:CreateFontString(nil, "HIGH")
    dot:SetPoint("TOPLEFT", legendFrame, "TOPLEFT", 6, -(4 + (idx - 1) * 18))
    dot:SetSize(110, 16)
    dot:SetFont(12)
    dot:SetJustifyH("LEFT")
    dot:SetTextColor(item.r, item.g, item.b)
    dot:SetText("● " .. item.label)
end

-------------------------------------------------------------------------------
-- OnUpdate – refresh position + tile labels while open, handle map dragging/zooming
-------------------------------------------------------------------------------
local updateTimer = 0
WorldMapFrame:SetScript("OnUpdate", function(self, dt)
    if not self:IsShown() then return end

    -- Check follow player
    if followPlayer then
        local px, pz = UnitPosition("player")
        if px and pz then
            wmCenter.x = px
            wmCenter.z = pz
        end
    end

    -- Panning & Zooming logic
    local mx, my = GetMousePosition()
    local wx, wy, ww, wh = WorldMapFrame:GetRect()
    local fx = wx + MAP_PAD
    local fy = wy + TITLE_H + MAP_PAD
    local fw = ww - MAP_PAD * 2
    local fh = wh - TITLE_H - MAP_PAD * 2 - BOTTOM_H

    if fw > 0 and fh > 0 then
        -- Scroll wheel zoom
        local wheel = GetMouseWheelMove()
        if wheel ~= 0 and mx >= fx and mx <= fx + fw and my >= fy and my <= fy + fh then
            ConsumeMouseWheel()
            local zoomFactor = 1.15
            if wheel > 0 then
                wmZoom = math.max(wmZoomMin, wmZoom / zoomFactor)
            else
                wmZoom = math.min(wmZoomMax, wmZoom * zoomFactor)
            end
        end

        -- Left click drag to pan
        if IsMouseButtonPressed(0) then -- MOUSE_BUTTON_LEFT = 0
            if mx >= fx and mx <= fx + fw and my >= fy and my <= fy + fh then
                isDraggingMap = true
                lastMouseX = mx
                lastMouseY = my
                followPlayer = false
            end
        end

        if isDraggingMap then
            if IsMouseButtonDown(0) then
                local dx = mx - lastMouseX
                local dy = my - lastMouseY
                if dx ~= 0 or dy ~= 0 then
                    local worldDX = -(dx / fw) * wmZoom
                    local worldDZ = -(dy / fh) * wmZoom
                    wmCenter.x = wmCenter.x + worldDX
                    wmCenter.z = wmCenter.z + worldDZ
                    lastMouseX = mx
                    lastMouseY = my
                end
            else
                isDraggingMap = false
            end
        end
    end

    updateTimer = updateTimer + dt
    if updateTimer >= 0.25 then
        updateTimer = 0
        local px, pz = UnitPosition("player")
        posLabel:SetText(string.format("Position:  %.1f,  %.1f", px, pz))

        local tile = GetTileAt(px, pz)
        tileLabel:SetText("Tile:  " .. (tile or "unknown"))
    end
end)

-------------------------------------------------------------------------------
-- ToggleWorldMap – global, called by MinimapWorldMapBtn
-------------------------------------------------------------------------------
function ToggleWorldMap()
    if WorldMapFrame:IsShown() then
        WorldMapFrame:Hide()
    else
        -- Re-centre on screen every time it opens so it's never off-screen
        WorldMapFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
        WorldMapFrame:Show()

        -- Center on player when opened
        local px, pz = UnitPosition("player")
        if px and pz then
            wmCenter.x = px
            wmCenter.z = pz
            followPlayer = true
        end
    end
end

-------------------------------------------------------------------------------
-- Key listener for 'M' (keycode 77) to toggle the world map
-------------------------------------------------------------------------------
local mapKeyDebounce = false
local mapKeyPoller = CreateFrame("Frame", "WorldMapKeyPoller", UIParent)
mapKeyPoller:SetScript("OnUpdate", function(self, dt)
    local mPressed = IsKeyPressed(77)
    if mPressed and not mapKeyDebounce then
        mapKeyDebounce = true
        ToggleWorldMap()
    elseif not mPressed then
        mapKeyDebounce = false
    end
end)
