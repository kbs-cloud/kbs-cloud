-------------------------------------------------------------------------------
-- ActionBar.lua  (CoreUI)
-- Four action bars:
--   BottomBar1  – 10 slots, bottom-center
--   BottomBar2  – 10 slots, above BottomBar1
--   RightBar1   – 10 slots, vertical, right edge
--   RightBar2   – 10 slots, vertical, left of RightBar1
--
-- Race/class profiles: GLIMMERWOOD_AB_PROFILES[key] = {bar1={}, bar2={}, rb1={}, rb2={}}
-- Profile key: "race_R_class_C"
-- On class/race change: if new profile exists, load it; else inherit current state.
-- Profiles are serialised via C_SavedVars.Save / C_SavedVars.Load on connect.
--
-- Hotkey sets:
--   BottomBar1: keys 1-9, 0 (codes 49-57, 48)
--   BottomBar2: no keybinds (manual bar click only)
--   RightBar1:  no keybinds (manual bar click only)
--   RightBar2:  no keybinds (manual bar click only)
-------------------------------------------------------------------------------

local SLOT_SIZE  = 46
local SLOT_GAP   = 5
local BAR_SLOTS  = 10
local RBAR_SLOTS = 10

-- Right-bar geometry
local RBAR_W     = SLOT_SIZE + 8
local RBAR_H     = RBAR_SLOTS * SLOT_SIZE + (RBAR_SLOTS - 1) * SLOT_GAP + 8
local RBAR_PAD   = 4    -- gap between the two right bars

-- Bottom-bar geometry
local BBAR_W    = BAR_SLOTS * SLOT_SIZE + (BAR_SLOTS - 1) * SLOT_GAP + 8
local BBAR_H    = SLOT_SIZE + 8

-- How far right bars push UI inward
GLIMMERWOOD_RIGHT_BAR_W = (RBAR_W + RBAR_PAD) * 2 + 8   -- exported global

-- Ensure globals exist even if loaded standalone
GLIMMERWOOD_BAG_OPEN         = GLIMMERWOOD_BAG_OPEN         or false
GLIMMERWOOD_HOVERED_INV_SLOT = GLIMMERWOOD_HOVERED_INV_SLOT or 0

-------------------------------------------------------------------------------
-- Profile storage (persisted via C_SavedVars)
-------------------------------------------------------------------------------
GLIMMERWOOD_AB_PROFILES = GLIMMERWOOD_AB_PROFILES or {}

local currentProfileKey = "race_0_class_0"

local function makeProfileKey(race, class_id)
    return string.format("race_%d_class_%d", race or 0, class_id or 0)
end

-- Serialize the current 4 bars into a profile table
local function serializeCurrentBars()
    local b1, b2, rb1, rb2 = {}, {}, {}, {}
    for i = 1, BAR_SLOTS do
        b1[i]  = GetHotbarItem(i) or 0
        b2[i]  = GetHotbarItem(i + BAR_SLOTS) or 0
    end
    for i = 1, RBAR_SLOTS do
        rb1[i] = GetHotbarItem(i + BAR_SLOTS * 2) or 0
        rb2[i] = GetHotbarItem(i + BAR_SLOTS * 2 + RBAR_SLOTS) or 0
    end
    return { bar1 = b1, bar2 = b2, rb1 = rb1, rb2 = rb2 }
end

-- Load a profile into the hotbar slots
local function applyProfile(prof)
    if not prof then return end
    local b1  = prof.bar1  or {}
    local b2  = prof.bar2  or {}
    local rb1 = prof.rb1   or {}
    local rb2 = prof.rb2   or {}
    for i = 1, BAR_SLOTS do
        SetHotbarItem(i, b1[i] or 0)
        SetHotbarItem(i + BAR_SLOTS, b2[i] or 0)
    end
    for i = 1, RBAR_SLOTS do
        SetHotbarItem(i + BAR_SLOTS * 2,              rb1[i] or 0)
        SetHotbarItem(i + BAR_SLOTS * 2 + RBAR_SLOTS, rb2[i] or 0)
    end
end

-- Encode profiles table to JSON string (simple, no deep nesting)
local function encodeProfilesToJSON()
    local parts = {}
    for key, prof in pairs(GLIMMERWOOD_AB_PROFILES) do
        local b1  = table.concat(prof.bar1  or {}, ",")
        local b2  = table.concat(prof.bar2  or {}, ",")
        local rb1 = table.concat(prof.rb1   or {}, ",")
        local rb2 = table.concat(prof.rb2   or {}, ",")
        table.insert(parts, string.format(
            '"%s":{"bar1":[%s],"bar2":[%s],"rb1":[%s],"rb2":[%s]}',
            key, b1, b2, rb1, rb2))
    end
    return "{" .. table.concat(parts, ",") .. "}"
end

-- Decode JSON string back to profiles table (simple parser for our format)
local function decodeProfilesFromJSON(json)
    if not json or json == "" then return {} end
    local result = {}
    -- Match each key:value block
    for key, inner in json:gmatch('"(race_%d+_class_%d+)":{([^}]+)}') do
        local prof = { bar1 = {}, bar2 = {}, rb1 = {}, rb2 = {} }
        for barName, nums in inner:gmatch('"(%w+)":%[([^%]]*)]') do
            local arr = {}
            for n in nums:gmatch("[%-]?%d+") do
                table.insert(arr, tonumber(n) or 0)
            end
            prof[barName] = arr
        end
        result[key] = prof
    end
    return result
end

local function saveProfilesToServer()
    if C_SavedVars and C_SavedVars.Save then
        -- Save current bars into the current profile before uploading
        GLIMMERWOOD_AB_PROFILES[currentProfileKey] = serializeCurrentBars()
        local json = encodeProfilesToJSON()
        C_SavedVars.Save(json)
    end
end

-------------------------------------------------------------------------------
-- Item category → colour
-------------------------------------------------------------------------------
local function itemCategoryColor(cat)
    if cat == "weapon"     then return 0.78, 0.31, 0.27 end
    if cat == "shield"     then return 0.35, 0.47, 0.78 end
    if cat == "armor"      then return 0.55, 0.55, 0.59 end
    if cat == "jewelry"    then return 0.82, 0.59, 0.86 end
    if cat == "consumable" then return 0.47, 0.78, 0.47 end
    if cat == "material"   then return 0.67, 0.55, 0.43 end
    if cat == "light"      then return 0.90, 0.78, 0.35 end
    if cat == "ability"    then return 0.60, 0.20, 0.70 end
    return 0.47, 0.47, 0.47
end

local function abilityColor(itemId)
    -- Fixed colors per known ability id
    local cols = {
        [1001] = {0.78, 0.25, 0.25},
        [1002] = {0.25, 0.60, 0.78},
        [1003] = {0.25, 0.75, 0.35},
        [1004] = {0.88, 0.45, 0.15},
        [1010] = {0.75, 0.35, 0.20},
        [1011] = {0.80, 0.55, 0.15},
        [1020] = {0.45, 0.75, 0.30},
        [1021] = {0.20, 0.65, 0.80},
        [1022] = {0.55, 0.80, 0.20},
        [1023] = {0.50, 0.40, 0.60},
        [1030] = {0.30, 0.65, 0.90},
        [1031] = {0.65, 0.25, 0.90},
        [1032] = {0.35, 0.85, 0.60},
    }
    return cols[itemId] or {0.60, 0.20, 0.70}
end

local function abilityName(itemId)
    if itemId == 1023 then
        local stats = C_Quest.GetPlayerStats()
        if stats and stats.is_stealthed then
            return "Unstealth"
        end
    end
    local names = {
        [1001]="Slash",[1002]="Sprint",[1003]="Regen",[1004]="Fireball",
        [1010]="Bash",[1011]="War Cry",[1020]="Backstab",[1021]="Dodge",
        [1022]="Psn Dart",[1023]="Stealth",[1030]="Frostbolt",[1031]="Arcsurge",[1032]="Mend",
    }
    return names[itemId] or "Ability"
end

-------------------------------------------------------------------------------
-- Slot data cache
-------------------------------------------------------------------------------
-- Total logical slots: BAR_SLOTS*2 (bottom bars) + RBAR_SLOTS*2 (right bars)
local TOTAL_SLOTS = BAR_SLOTS * 2 + RBAR_SLOTS * 2
local slotData = {}    -- slotData[i] = { itemId, count, name, cat, equipSlot }
local cooldowns = {}   -- cooldowns[abilityId] = remaining_seconds
local wasStealthed = false

local function isAbilityId(id)
    return id and id >= 1000
end

local function refreshSlotData(i)
    local itemId = GetHotbarItem(i)
    if itemId and isAbilityId(itemId) then
        local name = abilityName(itemId)
        local col  = abilityColor(itemId)
        slotData[i] = { itemId = itemId, count = 1, name = name, cat = "ability",
                         equipSlot = "none", abilityColor = col }
    elseif itemId and itemId > 0 then
        local name, cat, equipSlot = GetItemInfo(itemId)
        local count = 0
        for s = 1, INVENTORY_SLOTS do
            local sid, sc = GetInventorySlotInfo(s)
            if sid == itemId then count = sc; break end
        end
        slotData[i] = { itemId = itemId, count = count,
                         name = name or "?", cat = cat or "",
                         equipSlot = equipSlot or "" }
    else
        slotData[i] = nil
    end
end

local function refreshAllSlots()
    for i = 1, TOTAL_SLOTS do refreshSlotData(i) end
end

-------------------------------------------------------------------------------
-- Generic slot draw function
-------------------------------------------------------------------------------
local function drawSlot(self)
    local sx, sy, sw, sh = self:GetRect()
    local data = slotData[self.slotIndex]
    if data then
        local r, g, b = itemCategoryColor(data.cat)
        if data.cat == "ability" and data.abilityColor then
            r, g, b = data.abilityColor[1], data.abilityColor[2], data.abilityColor[3]
        end
        if data.itemId == 1023 then
            local stats = C_Quest.GetPlayerStats()
            if stats and stats.is_stealthed then
                r, g, b = 0.55, 0.35, 0.75
            end
        end
        if data.itemId < 1000 then
            Draw2D.ItemIcon(data.itemId, sx+2, sy+2, sw-4, sh-4)
        else
            Draw2D.Rect(sx+2, sy+2, sw-4, sh-4, r, g, b, 0.55)
            local displayName = data.name
            if data.itemId == 1023 then
                displayName = abilityName(1023)
            end
            if #displayName > 8 then displayName = displayName:sub(1,7) .. "." end
            Draw2D.Text(displayName, sx+3, sy+sh*0.38, 9, 1, 1, 1, 0.88)
        end
        if data.itemId == 1023 then
            local stats = C_Quest.GetPlayerStats()
            if stats and stats.is_stealthed then
                Draw2D.RectBorder(sx+2, sy+2, sw-4, sh-4, 1.5, 0.95, 0.85, 0.10, 1.0)
            end
        end
        if data.count > 1 then
            self.cntLabel:SetText(tostring(data.count))
        else
            self.cntLabel:SetText("")
        end
        if data.cat == "ability" then
            local cd = cooldowns[data.itemId] or 0
            if cd > 0 then
                Draw2D.Rect(sx+2, sy+2, sw-4, sh-4, 0, 0, 0, 0.65)
                Draw2D.Text(string.format("%.1fs", cd), sx+6, sy+sh*0.38, 9, 1.0, 0.3, 0.3, 0.95)
            end
        end
    else
        Draw2D.RectBorder(sx+3, sy+3, sw-6, sh-6, 1, 0.22, 0.22, 0.28, 0.45)
        self.cntLabel:SetText("")
    end
end

local function castAbility(data)
    if not data or data.cat ~= "ability" then return end
    local cd = cooldowns[data.itemId] or 0
    if cd <= 0 then
        -- Check if target is in range first
        if C_Item.IsTargetInRange and not C_Item.IsTargetInRange(data.itemId) then
            if ShowRaidWarning then
                ShowRaidWarning("Out of Range", 2.0, 255, 100, 100)
            end
            return
        end

        local castTimes = {
            [1003] = 1.0, -- Regen
            [1004] = 1.5, -- Fireball
            [1030] = 1.0, -- Frostbolt
            [1032] = 1.5, -- Mend
        }
        local ct = castTimes[data.itemId] or 0
        if ct > 0 then
            if StartCasting then
                StartCasting(data.itemId, ct, data.name, function()
                    local castSuccess = C_Item.CastAbility(data.itemId)
                    if castSuccess then
                        -- Set cooldown only if cast succeeded
                        local cdTimes = {[1001]=0,[1002]=10,[1003]=15,[1004]=5,
                                         [1010]=8,[1011]=20,[1020]=6,[1021]=12,
                                         [1022]=4,[1030]=3,[1031]=18,[1032]=10}
                        if data.itemId ~= 1023 then
                            cooldowns[data.itemId] = cdTimes[data.itemId] or 5
                        end
                    end
                end)
            end
        else
            local castSuccess = C_Item.CastAbility(data.itemId)
            if castSuccess then
                local cdTimes = {[1001]=0,[1002]=10,[1003]=15,[1004]=5,
                                 [1010]=8,[1011]=20,[1020]=6,[1021]=12,
                                 [1022]=4,[1030]=3,[1031]=18,[1032]=10}
                if data.itemId ~= 1023 then
                    cooldowns[data.itemId] = cdTimes[data.itemId] or 5
                end
            end
        end
    end
end

local function handleSlotClick(self, button)
    local idx = self.slotIndex
    if button == "Right" then
        SetHotbarItem(idx, 0)
        refreshSlotData(idx)
        saveProfilesToServer()
        return
    end

    if GLIMMERWOOD_HELD_ITEM then
        SetHotbarItem(idx, GLIMMERWOOD_HELD_ITEM.itemId)
        refreshSlotData(idx)
        GLIMMERWOOD_HELD_ITEM = nil
        saveProfilesToServer()
    elseif GLIMMERWOOD_BAG_OPEN and GLIMMERWOOD_HOVERED_INV_SLOT and GLIMMERWOOD_HOVERED_INV_SLOT > 0 then
        local itemId, _ = GetInventorySlotInfo(GLIMMERWOOD_HOVERED_INV_SLOT)
        if itemId and itemId > 0 then
            SetHotbarItem(idx, itemId)
            refreshSlotData(idx)
            saveProfilesToServer()
        end
    else
        local data = slotData[idx]
        if data then
            if data.cat == "ability" then
                castAbility(data)
            else
                for s = 1, INVENTORY_SLOTS do
                    local sid, _ = GetInventorySlotInfo(s)
                    if sid == data.itemId then
                        local cat = data.cat
                        if cat == "weapon" or cat == "shield" or cat == "armor"
                           or cat == "jewelry" or cat == "light" then
                            C_Item.EquipItem(s)
                        else
                            C_Item.UseItem(s)
                        end
                        refreshSlotData(idx)
                        break
                    end
                end
            end
        end
    end
end

local function slotOnDragStart(self)
    local idx = self.slotIndex
    local data = slotData[idx]
    if data then
        local typ = data.cat == "ability" and "ability" or "item"
        local color = data.abilityColor or {0.8, 0.8, 0.8}
        local icon = typ == "item" and data.itemId or -1
        C_Cursor.StartDrag(typ, tostring(data.itemId), icon, data.name, color[1], color[2], color[3])
        if GameTooltip then GameTooltip:Hide() end
    end
end

local function slotOnReceiveDrag(self, dragType, dragData, srcFrame)
    local dstIdx = self.slotIndex
    local itemId = tonumber(dragData)
    if itemId and itemId > 0 then
        if srcFrame and srcFrame.slotIndex then
            local srcIdx = srcFrame.slotIndex
            local dstItem = slotData[dstIdx] and slotData[dstIdx].itemId or 0
            SetHotbarItem(dstIdx, itemId)
            SetHotbarItem(srcIdx, dstItem)
            refreshSlotData(dstIdx)
            refreshSlotData(srcIdx)
        else
            SetHotbarItem(dstIdx, itemId)
            refreshSlotData(dstIdx)
        end
        saveProfilesToServer()
    end
end

local function slotOnDragStop(self, dragType, dragData, targetFrame)
    if not targetFrame then
        local idx = self.slotIndex
        SetHotbarItem(idx, 0)
        refreshSlotData(idx)
        saveProfilesToServer()
    end
    C_Cursor.ClearDrag()
end

local function getAbilityInfo(abilityId)
    local abils = {
        [1001] = { name = "Slash",     castTime = "Instant",  range = "Melee",      cdText = "No Cooldown",   desc = "A quick melee sweep dealing physical damage to enemies in front." },
        [1002] = { name = "Sprint",    castTime = "Instant",  range = "Self",       cdText = "10s Cooldown",  desc = "Boost movement speed by 50% for 3 seconds." },
        [1003] = { name = "Regen",     castTime = "1.0s cast",range = "Self",       cdText = "15s Cooldown",  desc = "Restore 15 HP over 5 seconds." },
        [1004] = { name = "Fireball",  castTime = "1.5s cast",range = "20m range",  cdText = "5s Cooldown",   desc = "Hurl a ball of fire at the nearest target within 20m for 8 damage." },
        [1010] = { name = "Bash",      castTime = "Instant",  range = "Melee",      cdText = "8s Cooldown",   desc = "A powerful overhead strike that stuns the target briefly." },
        [1011] = { name = "War Cry",   castTime = "Instant",  range = "Self",       cdText = "20s Cooldown",  desc = "Unleash a battle cry that boosts your attack power for 8 seconds." },
        [1020] = { name = "Backstab",  castTime = "Instant",  range = "Melee",      cdText = "6s Cooldown",   desc = "Strike from the shadows dealing double damage if behind the target." },
        [1021] = { name = "Dodge",     castTime = "Instant",  range = "Self",       cdText = "12s Cooldown",  desc = "Sidestep attacks for 2 seconds, reducing incoming damage by 80%." },
        [1022] = { name = "Psn Dart",  castTime = "Instant",  range = "10m range",  cdText = "4s Cooldown",   desc = "Launch a poison dart that deals damage over 6 seconds." },
        [1030] = { name = "Frostbolt", castTime = "1.0s cast",range = "12m range",  cdText = "3s Cooldown",   desc = "A bolt of frost that slows and damages the target." },
        [1031] = { name = "Arcsurge",  castTime = "Instant",  range = "Self",       cdText = "18s Cooldown",  desc = "Release arcane energy in a burst, damaging all nearby enemies." },
        [1032] = { name = "Mend",      castTime = "1.5s cast",range = "12m range",  cdText = "10s Cooldown",  desc = "Channel arcane energy to restore 30 HP to yourself or an ally." },
    }
    return abils[abilityId]
end

local function slotOnEnter(self)
    local data = slotData[self.slotIndex]
    if data and data.itemId > 0 then
        self:SetHighlightColor(0.55, 0.65, 0.90, 0.65)
        if GameTooltip then
            GameTooltip:SetPoint("BOTTOMLEFT", self, "TOPRIGHT", 8, 8)
            if isAbilityId(data.itemId) then
                local abInfo = getAbilityInfo(data.itemId)
                if abInfo then
                    GameTooltip:SetText(abInfo.name)
                    local info = (abInfo.castTime or "Instant") .. "  |  " .. (abInfo.range or "Melee")
                    GameTooltip:AddLine(info, 1.0, 0.85, 0.40)
                    GameTooltip:AddLine(abInfo.desc, 0.8, 0.8, 0.8)
                    GameTooltip:AddLine(abInfo.cdText, 0.65, 0.40, 0.80)
                else
                    GameTooltip:SetText(data.name)
                end
            else
                GameTooltip:SetItem(data.itemId)
            end
        end
    end
end

local function slotOnLeave(self)
    self:SetHighlightColor(0.35, 0.45, 0.70, 0.55)
    if GameTooltip then GameTooltip:Hide() end
end

-------------------------------------------------------------------------------
-- Build a horizontal bar (bottom bars)
-------------------------------------------------------------------------------
local function buildHorizontalBar(frameName, slotOffset, anchorPoint, anchorParent, anchorRelative, ox, oy)
    local frame = CreateFrame("Frame", frameName, UIParent, "BasicPanelTemplate")
    frame:SetSize(BBAR_W, BBAR_H)
    frame:SetPoint(anchorPoint, anchorParent, anchorRelative, ox, oy)
    frame:SetFrameStrata("MEDIUM")
    frame:SetMovable(true)
    frame:EnableMouse(true)

    local slots = {}
    for i = 1, BAR_SLOTS do
        local slotIdx = slotOffset + i
        local ox2 = 4 + (i-1) * (SLOT_SIZE + SLOT_GAP)

        local slot = CreateFrame("Button", frameName .. "Slot" .. i, frame, "UIPanelButtonTemplate")
        slot:SetSize(SLOT_SIZE, SLOT_SIZE)
        slot:SetPoint("TOPLEFT", frame, "TOPLEFT", ox2, -3)
        slot:SetBackdropColor(0.10, 0.10, 0.13, 0.82)
        slot:EnableMouse(true)
        slot.slotIndex = slotIdx

        local numLabel = slot:CreateFontString(nil, "HIGH")
        numLabel:SetPoint("TOPLEFT", slot, "TOPLEFT", 3, -2)
        numLabel:SetFont(9)
        numLabel:SetTextColor(0.65, 0.65, 0.65)
        if slotOffset == 0 then
            if i <= 9 then
                numLabel:SetText(tostring(i))
            elseif i == 10 then
                numLabel:SetText("0")
            else
                numLabel:SetText("")
            end
        else
            numLabel:SetText("")
        end

        local cntLabel = slot:CreateFontString(nil, "HIGH")
        cntLabel:SetPoint("BOTTOMRIGHT", slot, "BOTTOMRIGHT", -2, 2)
        cntLabel:SetFont(10)
        cntLabel:SetTextColor(1.0, 1.0, 0.8)
        cntLabel:SetText("")
        slot.cntLabel = cntLabel

        slot:SetScript("OnDraw",   drawSlot)
        slot:SetScript("OnClick",  handleSlotClick)
        slot:SetScript("OnEnter",  slotOnEnter)
        slot:SetScript("OnLeave",  slotOnLeave)
        slot:RegisterForDrag("Left")
        slot:SetScript("OnDragStart", slotOnDragStart)
        slot:SetScript("OnReceiveDrag", slotOnReceiveDrag)
        slot:SetScript("OnDragStop", slotOnDragStop)

        slots[i] = slot
    end

    return frame, slots
end

-------------------------------------------------------------------------------
-- Build a vertical bar (right bars)
-------------------------------------------------------------------------------
local function buildVerticalBar(frameName, slotOffset)
    local frame = CreateFrame("Frame", frameName, UIParent, "BasicPanelTemplate")
    frame:SetSize(RBAR_W, RBAR_H)
    frame:SetFrameStrata("MEDIUM")
    frame:SetMovable(true)
    frame:EnableMouse(true)

    local slots = {}
    for i = 1, RBAR_SLOTS do
        local slotIdx = slotOffset + i
        local oy2 = -4 - (i-1) * (SLOT_SIZE + SLOT_GAP)

        local slot = CreateFrame("Button", frameName .. "Slot" .. i, frame, "UIPanelButtonTemplate")
        slot:SetSize(SLOT_SIZE, SLOT_SIZE)
        slot:SetPoint("TOPLEFT", frame, "TOPLEFT", 4, oy2)
        slot:SetBackdropColor(0.10, 0.10, 0.13, 0.82)
        slot:EnableMouse(true)
        slot.slotIndex = slotIdx

        local numLabel = slot:CreateFontString(nil, "HIGH")
        numLabel:SetPoint("TOPLEFT", slot, "TOPLEFT", 3, -2)
        numLabel:SetFont(9)
        numLabel:SetTextColor(0.65, 0.65, 0.65)
        numLabel:SetText("")

        local cntLabel = slot:CreateFontString(nil, "HIGH")
        cntLabel:SetPoint("BOTTOMRIGHT", slot, "BOTTOMRIGHT", -2, 2)
        cntLabel:SetFont(10)
        cntLabel:SetTextColor(1.0, 1.0, 0.8)
        cntLabel:SetText("")
        slot.cntLabel = cntLabel

        slot:SetScript("OnDraw",  drawSlot)
        slot:SetScript("OnClick", handleSlotClick)
        slot:SetScript("OnEnter", slotOnEnter)
        slot:SetScript("OnLeave", slotOnLeave)
        slot:RegisterForDrag("Left")
        slot:SetScript("OnDragStart", slotOnDragStart)
        slot:SetScript("OnReceiveDrag", slotOnReceiveDrag)
        slot:SetScript("OnDragStop", slotOnDragStop)

        slots[i] = slot
    end

    return frame, slots
end

-------------------------------------------------------------------------------
-- Create all 4 bars
--
-- Layout:
--   BottomBar2 sits just above BottomBar1.
--   BottomBar1 is the primary bar at bottom-center.
--   RightBar1 is the outer (rightmost) vertical bar.
--   RightBar2 is to the left of RightBar1.
--
-- Right bars clear 12px from the right edge.
-- Bottom bars are centered (shifted left by half their width from center),
-- but displaced left by the total right-bar width.
-------------------------------------------------------------------------------

local rbarRightOffset = -(RBAR_W + 8)                -- outer right bar x
local rbar2RightOffset = -(RBAR_W * 2 + RBAR_PAD + 8) -- inner right bar x

ActionBarFrame, _ = buildHorizontalBar(
    "ActionBarFrame", 0,
    "BOTTOM", UIParent, "BOTTOM", 0, 12)

ActionBar2Frame, _ = buildHorizontalBar(
    "ActionBar2Frame", BAR_SLOTS,
    "BOTTOM", ActionBarFrame, "TOP", 0, SLOT_GAP)

RightBar1Frame, _ = buildVerticalBar("RightBar1Frame", BAR_SLOTS * 2)
RightBar1Frame:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", rbarRightOffset, 12)

RightBar2Frame, _ = buildVerticalBar("RightBar2Frame", BAR_SLOTS * 2 + RBAR_SLOTS)
RightBar2Frame:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", rbar2RightOffset, 12)

-------------------------------------------------------------------------------
-- Race/Class profile switching
-------------------------------------------------------------------------------
local lastRace    = 0
local lastClassId = 0

local function onRaceClassChanged(race, class_id)
    local newKey = makeProfileKey(race, class_id)
    if newKey == currentProfileKey then return end

    -- Save current bars into old profile
    GLIMMERWOOD_AB_PROFILES[currentProfileKey] = serializeCurrentBars()

    -- Load new profile if it exists, else inherit current
    if GLIMMERWOOD_AB_PROFILES[newKey] then
        applyProfile(GLIMMERWOOD_AB_PROFILES[newKey])
    else
        -- Copy current bars as starting point for new profile
        GLIMMERWOOD_AB_PROFILES[newKey] = serializeCurrentBars()
    end

    currentProfileKey = newKey
    refreshAllSlots()
    saveProfilesToServer()
end

-------------------------------------------------------------------------------
-- Events
-------------------------------------------------------------------------------
ActionBarFrame:RegisterEvent("INVENTORY_UPDATE")
ActionBarFrame:RegisterEvent("QUEST_STATE_UPDATE")
ActionBarFrame:RegisterEvent("SAVED_VARS_LOADED")

ActionBarFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "INVENTORY_UPDATE" then
        refreshAllSlots()
    elseif event == "QUEST_STATE_UPDATE" then
        -- Check if race/class changed
        local stats = C_Quest.GetPlayerStats and C_Quest.GetPlayerStats()
        if stats then
            local race     = stats.race     or 0
            local class_id = stats.class_id or 0
            if race ~= lastRace or class_id ~= lastClassId then
                lastRace    = race
                lastClassId = class_id
                onRaceClassChanged(race, class_id)
            end
        end
    elseif event == "SAVED_VARS_LOADED" then
        -- Load profiles from server
        if C_SavedVars and C_SavedVars.Load then
            local json = C_SavedVars.Load()
            if json and json ~= "" then
                local decoded = decodeProfilesFromJSON(json)
                if decoded then
                    GLIMMERWOOD_AB_PROFILES = decoded
                    -- Apply the current profile if available
                    if GLIMMERWOOD_AB_PROFILES[currentProfileKey] then
                        applyProfile(GLIMMERWOOD_AB_PROFILES[currentProfileKey])
                        refreshAllSlots()
                    end
                end
            end
        end
    end
end)

-------------------------------------------------------------------------------
-- OnUpdate – init, cooldowns, keybinds
-------------------------------------------------------------------------------
local initialised = false
ActionBarFrame:SetScript("OnUpdate", function(self, dt)
    if not initialised then
        initialised = true
        refreshAllSlots()
    end

    -- Advance cooldowns
    for id, cd in pairs(cooldowns) do
        if cd > 0 then
            cooldowns[id] = math.max(0, cd - dt)
        end
    end

    local stats = C_Quest.GetPlayerStats()
    local isStealthed = false
    if stats and stats.is_stealthed then
        isStealthed = true
    end
    if wasStealthed and not isStealthed then
        cooldowns[1023] = 10
    end
    wasStealthed = isStealthed

    -- Hotbar keybinds 1-9, 0 for BottomBar1 (keys 49-57, 48)
    local codexShown = CodexFrame and CodexFrame:IsShown() or false
    if not GLIMMERWOOD_BAG_OPEN and not codexShown then
        for i = 1, 10 do
            local key = (i == 10) and 48 or (48 + i)
            if IsKeyPressed(key) then
                local data = slotData[i]
                if data and data.cat == "ability" then
                    castAbility(data)
                end
            end
        end
    end
end)
