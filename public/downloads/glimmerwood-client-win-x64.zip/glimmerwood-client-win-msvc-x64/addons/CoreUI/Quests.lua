-------------------------------------------------------------------------------
-- Quests.lua (CoreUI)
-- NPC Quest Dialog, Character Stats Sheet, Quest Log (L key), and Quest Tracker.
-------------------------------------------------------------------------------

local PANEL_W = 460
local PANEL_H = 340
local MARGIN  = 12

-------------------------------------------------------------------------------
-- Quest Giver Dialog Panel
-------------------------------------------------------------------------------
QuestGiverFrame = CreateFrame("Frame", "QuestGiverFrame", UIParent, "BasicPanelTemplate")
QuestGiverFrame:SetSize(PANEL_W, PANEL_H)
QuestGiverFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
QuestGiverFrame:SetFrameStrata("HIGH")
QuestGiverFrame:Hide()

-- Close button
local qgClose = CreateFrame("Button", "QuestGiverCloseBtn", QuestGiverFrame, "UIPanelButtonTemplate")
qgClose:SetSize(28, 28)
qgClose:SetPoint("TOPRIGHT", QuestGiverFrame, "TOPRIGHT", -8, -8)
qgClose:SetScript("OnDraw", function(self)
    local sx, sy, sw, sh = self:GetRect()
    Draw2D.Text("X", sx + 8, sy + 6, 12, 1.0, 0.4, 0.4, 0.95)
end)
qgClose:SetScript("OnClick", function(self, button)
    if button == "Left" then
        C_Quest.CloseQuestGiver()
        QuestGiverFrame:Hide()
    end
end)

-- Sidebar for quest list (left side)
local qgSidebar = CreateFrame("Frame", "QuestGiverSidebar", QuestGiverFrame)
qgSidebar:SetSize(140, PANEL_H - MARGIN * 2 - 20)
qgSidebar:SetPoint("TOPLEFT", QuestGiverFrame, "TOPLEFT", MARGIN, -MARGIN - 20)

-- Detail panel (right side)
local qgDetails = CreateFrame("Frame", "QuestGiverDetails", QuestGiverFrame)
qgDetails:SetSize(280, PANEL_H - MARGIN * 2 - 20)
qgDetails:SetPoint("TOPLEFT", QuestGiverFrame, "TOPLEFT", MARGIN + 150, -MARGIN - 20)

-- Title string for details
local qgQuestTitle = qgDetails:CreateFontString(nil, "HIGH")
qgQuestTitle:SetPoint("TOPLEFT", qgDetails, "TOPLEFT", 0, 0)
qgQuestTitle:SetSize(280, 20)
qgQuestTitle:SetFont(14)
qgQuestTitle:SetTextColor(0.88, 0.82, 0.60)
qgQuestTitle:SetJustifyH("LEFT")
qgQuestTitle:Show()


-- Description text
local qgQuestDesc = qgDetails:CreateFontString(nil, "HIGH")
qgQuestDesc:SetPoint("TOPLEFT", qgQuestTitle, "BOTTOMLEFT", 0, -8)
qgQuestDesc:SetSize(280, 70)
qgQuestDesc:SetFont(10)
qgQuestDesc:SetTextColor(0.8, 0.8, 0.8)
qgQuestDesc:SetJustifyH("LEFT")
qgQuestDesc:Show()


-- Objectives header
local qgObjHeader = qgDetails:CreateFontString(nil, "HIGH")
qgObjHeader:SetPoint("TOPLEFT", qgQuestDesc, "BOTTOMLEFT", 0, -10)
qgObjHeader:SetSize(280, 15)
qgObjHeader:SetFont(11)
qgObjHeader:SetTextColor(0.88, 0.82, 0.60)
qgObjHeader:SetJustifyH("LEFT")
qgObjHeader:SetText("Objectives:")
qgObjHeader:Show()


-- Objectives text
local qgQuestObj = qgDetails:CreateFontString(nil, "HIGH")
qgQuestObj:SetPoint("TOPLEFT", qgObjHeader, "BOTTOMLEFT", 0, -4)
qgQuestObj:SetSize(280, 45)
qgQuestObj:SetFont(10)
qgQuestObj:SetTextColor(0.7, 0.7, 0.7)
qgQuestObj:SetJustifyH("LEFT")
qgQuestObj:Show()


-- Rewards header
local qgRewHeader = qgDetails:CreateFontString(nil, "HIGH")
qgRewHeader:SetPoint("TOPLEFT", qgQuestObj, "BOTTOMLEFT", 0, -10)
qgRewHeader:SetSize(280, 15)
qgRewHeader:SetFont(11)
qgRewHeader:SetTextColor(0.88, 0.82, 0.60)
qgRewHeader:SetJustifyH("LEFT")
qgRewHeader:SetText("Rewards:")
qgRewHeader:Show()


-- Rewards text
local qgQuestRew = qgDetails:CreateFontString(nil, "HIGH")
qgQuestRew:SetPoint("TOPLEFT", qgRewHeader, "BOTTOMLEFT", 0, -4)
qgQuestRew:SetSize(280, 45)
qgQuestRew:SetFont(10)
qgQuestRew:SetTextColor(0.8, 0.6, 0.95)
qgQuestRew:SetJustifyH("LEFT")
qgQuestRew:Show()


-- Action Button (Accept / Complete)
local qgActionBtn = CreateFrame("Button", "QuestGiverActionBtn", qgDetails, "UIPanelButtonTemplate")
qgActionBtn:SetSize(140, 28)
qgActionBtn:SetPoint("BOTTOMLEFT", qgDetails, "BOTTOMLEFT", 0, 0)
qgActionBtn:Hide()

local selectedGiverQuestId = 0
local selectedGiverQuestStatus = 0

-- Update right-side quest details
local function updateQuestDetails(questId, status, name, desc, xp, coins, itemId, itemCount)
    selectedGiverQuestId = questId
    selectedGiverQuestStatus = status

    if not questId then
        qgQuestTitle:SetText("")
        qgQuestDesc:SetText("")
        qgQuestObj:SetText("")
        qgQuestRew:SetText("")
        qgActionBtn:Hide()
        return
    end

    qgQuestTitle:SetText(name)
    qgQuestDesc:SetText(desc)

    -- Retrieve objectives from DB using GetQuestInfo
    local _, _, obj1_type, obj1_target, obj1_count, obj2_type, obj2_target, obj2_count = C_Quest.GetQuestInfo(questId)
    local objs = {}
    if obj1_type == 1 then -- KILL
        table.insert(objs, string.format("- Slay %d Foxes", obj1_count))
    elseif obj1_type == 2 then -- GATHER
        local itemName = GetItemInfo(obj1_target) or "Items"
        table.insert(objs, string.format("- Gather %d %s", obj1_count, itemName))
    end
    if obj2_type == 1 then
        table.insert(objs, string.format("- Slay %d Foxes", obj2_count))
    elseif obj2_type == 2 then
        local itemName = GetItemInfo(obj2_target) or "Items"
        table.insert(objs, string.format("- Gather %d %s", obj2_count, itemName))
    end
    if #objs == 0 then
        table.insert(objs, "- Speak to the NPC")
    end
    qgQuestObj:SetText(table.concat(objs, "\n"))

    -- Format rewards
    local rews = {}
    if xp > 0 then table.insert(rews, xp .. " XP") end
    if coins > 0 then table.insert(rews, coins .. " Coins") end
    if itemId > 0 and itemCount > 0 then
        local rName = GetItemInfo(itemId) or "Item"
        table.insert(rews, itemCount .. "x " .. rName)
    end
    qgQuestRew:SetText(table.concat(rews, ", "))

    qgActionBtn:Show()
    if status == 0 then
        qgActionBtn:SetText("Accept Quest")
    elseif status == 2 then
        qgActionBtn:SetText("Complete Quest")
    else
        qgActionBtn:Hide()
    end
end

-- Refresh sidebar and select first quest
local function refreshQuestGiver()
    local numQuests = C_Quest.GetQuestGiverNumQuests()
    if numQuests == 0 then
        QuestGiverFrame:Hide()
        return
    end

    -- Create sidebar buttons dynamically
    for idx = 1, 6 do
        local btn = _G["QuestGiverListBtn" .. idx]
        if not btn then
            btn = CreateFrame("Button", "QuestGiverListBtn" .. idx, qgSidebar, "UIPanelButtonTemplate")
            btn:SetSize(130, 24)
            btn:SetPoint("TOPLEFT", qgSidebar, "TOPLEFT", 0, -(idx - 1) * 28)
            btn:EnableMouse(true)
        end
        if idx <= numQuests then
            local qid, status, name = C_Quest.GetQuestGiverQuestInfo(idx)
            btn:SetText(name)
            btn:SetScript("OnClick", function(self, button)
                if button == "Left" then
                    local _, st, n, d, xp, coins, itemId, itemCount = C_Quest.GetQuestGiverQuestInfo(idx)
                    updateQuestDetails(qid, st, n, d, xp, coins, itemId, itemCount)
                end
            end)
            btn:Show()
        else
            btn:Hide()
        end
    end

    -- Select first quest by default
    local qid, st, n, d, xp, coins, itemId, itemCount = C_Quest.GetQuestGiverQuestInfo(1)
    updateQuestDetails(qid, st, n, d, xp, coins, itemId, itemCount)
end

qgActionBtn:SetScript("OnClick", function(self, button)
    if button == "Left" and selectedGiverQuestId > 0 then
        if selectedGiverQuestStatus == 0 then
            C_Quest.AcceptQuest(selectedGiverQuestId)
        elseif selectedGiverQuestStatus == 2 then
            C_Quest.CompleteQuest(selectedGiverQuestId)
        end
        QuestGiverFrame:Hide()
    end
end)

QuestGiverFrame:RegisterEvent("QUEST_LIST_OPEN")
QuestGiverFrame:RegisterEvent("QUEST_STATE_UPDATE")
QuestGiverFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "QUEST_LIST_OPEN" then
        QuestGiverFrame:Show()
        refreshQuestGiver()
    elseif event == "QUEST_STATE_UPDATE" then
        if QuestGiverFrame:IsShown() then
            refreshQuestGiver()
        end
    end
end)


-------------------------------------------------------------------------------
-- Character Info & Quest Log (L Key Window)
-------------------------------------------------------------------------------
QuestLogFrame = CreateFrame("Frame", "QuestLogFrame", UIParent, "BasicPanelTemplate")
QuestLogFrame:SetSize(PANEL_W, PANEL_H)
QuestLogFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
QuestLogFrame:SetFrameStrata("HIGH")
QuestLogFrame:Hide()

-- Movable panel setup
QuestLogFrame:SetMovable(true)
QuestLogFrame:EnableMouse(true)
QuestLogFrame:SetScript("OnMouseDown", function(self, button)
    if button == "Left" then
        self:StartMoving()
    end
end)
QuestLogFrame:SetScript("OnMouseUp", function(self, button)
    if button == "Left" then
        self:StopMovingOrSizing()
    end
end)


-- Header Title
local qlHeader = QuestLogFrame:CreateFontString(nil, "HIGH")
qlHeader:SetPoint("TOPLEFT", QuestLogFrame, "TOPLEFT", MARGIN, -6)
qlHeader:SetPoint("TOPRIGHT", QuestLogFrame, "TOPRIGHT", -MARGIN, -6)
qlHeader:SetHeight(20)
qlHeader:SetFont(14)
qlHeader:SetJustifyH("CENTER")
qlHeader:SetTextColor(0.88, 0.82, 0.60)
qlHeader:SetText("Character Sheet & Quest Log")

-- Tab selection state (1 = Character, 2 = Quest Log)
local currentTab = 1

local charTabBtn = CreateFrame("Button", "QuestLogTab1", QuestLogFrame, "UIPanelButtonTemplate")
charTabBtn:SetSize(110, 24)
charTabBtn:SetPoint("TOPLEFT", QuestLogFrame, "TOPLEFT", MARGIN, -28)
charTabBtn:SetText("Character")

local questTabBtn = CreateFrame("Button", "QuestLogTab2", QuestLogFrame, "UIPanelButtonTemplate")
questTabBtn:SetSize(110, 24)
questTabBtn:SetPoint("TOPLEFT", charTabBtn, "TOPRIGHT", 6, 0)
questTabBtn:SetText("Quest Log")

-- Sub-panels for Tabs
local charPanel = CreateFrame("Frame", "QuestLogCharPanel", QuestLogFrame)
charPanel:SetSize(PANEL_W - MARGIN * 2, PANEL_H - 70)
charPanel:SetPoint("TOPLEFT", QuestLogFrame, "TOPLEFT", MARGIN, -60)

local logPanel = CreateFrame("Frame", "QuestLogPanelSub", QuestLogFrame)
logPanel:SetSize(PANEL_W - MARGIN * 2, PANEL_H - 70)
logPanel:SetPoint("TOPLEFT", QuestLogFrame, "TOPLEFT", MARGIN, -60)
logPanel:Hide()

-- Close button
local qlClose = CreateFrame("Button", "QuestLogCloseBtn", QuestLogFrame, "UIPanelButtonTemplate")
qlClose:SetSize(28, 28)
qlClose:SetPoint("TOPRIGHT", QuestLogFrame, "TOPRIGHT", -8, -8)
qlClose:SetScript("OnDraw", function(self)
    local sx, sy, sw, sh = self:GetRect()
    Draw2D.Text("X", sx + 8, sy + 6, 12, 1.0, 0.4, 0.4, 0.95)
end)
qlClose:SetScript("OnClick", function(self, button)
    if button == "Left" then
        QuestLogFrame:Hide()
    end
end)

--------------------- Tab 1: Character Panel Layout ---------------------
local charStatsFS = charPanel:CreateFontString(nil, "HIGH")
charStatsFS:SetPoint("TOPLEFT", charPanel, "TOPLEFT", 0, 0)
charStatsFS:SetSize(200, 100)
charStatsFS:SetFont(11)
charStatsFS:SetTextColor(0.9, 0.9, 0.9)
charStatsFS:SetJustifyH("LEFT")

-- Class/Race selection sub-panel (shown if class_id/race unselected or editable)
local choosePanel = CreateFrame("Frame", "ChooseClassRacePanel", charPanel)
choosePanel:SetSize(220, 140)
choosePanel:SetPoint("TOPRIGHT", charPanel, "TOPRIGHT", 0, 0)
choosePanel:Hide()

choosePanel:SetScript("OnDraw", function(self)
    local sx, sy, sw, sh = self:GetRect()
    Draw2D.RectBorder(sx, sy, sw, sh, 1, 0.4, 0.4, 0.4, 0.2)
    Draw2D.Rect(sx + 1, sy + 1, sw - 2, sh - 2, 0.05, 0.05, 0.05, 0.3)
end)

local chooseRaceLabel = choosePanel:CreateFontString(nil, "HIGH")
chooseRaceLabel:SetPoint("TOPLEFT", choosePanel, "TOPLEFT", 8, -6)
chooseRaceLabel:SetSize(200, 15)
chooseRaceLabel:SetFont(10)
chooseRaceLabel:SetTextColor(0.88, 0.82, 0.60)
chooseRaceLabel:SetText("Choose Race:")
chooseRaceLabel:SetJustifyH("LEFT")

-- Race Buttons
local btnRaceH = CreateFrame("Button", "ChooseRaceBtn0", choosePanel, "UIPanelButtonTemplate")
btnRaceH:SetSize(60, 20)
btnRaceH:SetPoint("TOPLEFT", choosePanel, "TOPLEFT", 8, -24)
btnRaceH:SetText("Human")
btnRaceH:SetScript("OnClick", function(self, button) if button == "Left" then C_Quest.ChooseRace(0) end end)

local btnRaceE = CreateFrame("Button", "ChooseRaceBtn1", choosePanel, "UIPanelButtonTemplate")
btnRaceE:SetSize(60, 20)
btnRaceE:SetPoint("LEFT", btnRaceH, "RIGHT", 4, 0)
btnRaceE:SetText("Elf")
btnRaceE:SetScript("OnClick", function(self, button) if button == "Left" then C_Quest.ChooseRace(1) end end)

local btnRaceD = CreateFrame("Button", "ChooseRaceBtn2", choosePanel, "UIPanelButtonTemplate")
btnRaceD:SetSize(60, 20)
btnRaceD:SetPoint("LEFT", btnRaceE, "RIGHT", 4, 0)
btnRaceD:SetText("Dwarf")
btnRaceD:SetScript("OnClick", function(self, button) if button == "Left" then C_Quest.ChooseRace(2) end end)

local chooseClassLabel = choosePanel:CreateFontString(nil, "HIGH")
chooseClassLabel:SetPoint("TOPLEFT", choosePanel, "TOPLEFT", 8, -50)
chooseClassLabel:SetSize(200, 15)
chooseClassLabel:SetFont(10)
chooseClassLabel:SetTextColor(0.88, 0.82, 0.60)
chooseClassLabel:SetText("Choose Class:")
chooseClassLabel:SetJustifyH("LEFT")

-- Class Buttons
local btnClassW = CreateFrame("Button", "ChooseClassBtn0", choosePanel, "UIPanelButtonTemplate")
btnClassW:SetSize(60, 20)
btnClassW:SetPoint("TOPLEFT", choosePanel, "TOPLEFT", 8, -68)
btnClassW:SetText("Warrior")
btnClassW:SetScript("OnClick", function(self, button) if button == "Left" then C_Quest.ChooseClass(0) end end)

local btnClassM = CreateFrame("Button", "ChooseClassBtn1", choosePanel, "UIPanelButtonTemplate")
btnClassM:SetSize(60, 20)
btnClassM:SetPoint("LEFT", btnClassW, "RIGHT", 4, 0)
btnClassM:SetText("Mage")
btnClassM:SetScript("OnClick", function(self, button) if button == "Left" then C_Quest.ChooseClass(1) end end)

local btnClassR = CreateFrame("Button", "ChooseClassBtn2", choosePanel, "UIPanelButtonTemplate")
btnClassR:SetSize(60, 20)
btnClassR:SetPoint("LEFT", btnClassM, "RIGHT", 4, 0)
btnClassR:SetText("Rogue")
btnClassR:SetScript("OnClick", function(self, button) if button == "Left" then C_Quest.ChooseClass(2) end end)

-- Skills & Professions Display
local skillsFS = charPanel:CreateFontString(nil, "HIGH")
skillsFS:SetPoint("TOPLEFT", charPanel, "TOPLEFT", 0, -110)
skillsFS:SetSize(420, 140)
skillsFS:SetFont(10)
skillsFS:SetTextColor(0.85, 0.85, 0.9)
skillsFS:SetJustifyH("LEFT")

local function refreshCharPanel()
    local stats = C_Quest.GetPlayerStats()
    if not stats then return end

    local raceNames = { [0] = "Human", [1] = "Elf", [2] = "Dwarf" }
    local classNames = { [0] = "Warrior", [1] = "Mage", [2] = "Rogue" }
    
    local rName = raceNames[stats.race] or "Unchosen"
    local cName = classNames[stats.class_id] or "Unchosen"
    
    charStatsFS:SetText(string.format(
        "Race:  |cffffddaa%s|r\nClass: |cffffddaa%s|r\nLevel: %d\nXP:    %d / %d",
        rName, cName, UnitLevel(), UnitXP(), UnitXPMax()
    ))

    local skNames = { [0] = "Swordplay", [1] = "Spellcasting", [2] = "Stealth" }
    local profNames = { [0] = "Mining", [1] = "Herbalism", [2] = "Blacksmith" }

    local skLines = { "|cffeebbaa[ Combat Skills ]|r" }
    for i = 0, 2 do
        local lv = stats.skills[i] or 0
        table.insert(skLines, string.format("  - %s: Level %d", skNames[i] or "Skill " .. i, lv))
    end
    
    table.insert(skLines, "")
    table.insert(skLines, "|cffeebbaa[ Professions ]|r")
    for i = 0, 1 do
        local lv = stats.professions[i] or 0
        table.insert(skLines, string.format("  - %s: Level %d", profNames[i] or "Profession " .. i, lv))
    end

    skillsFS:SetText(table.concat(skLines, "\n"))
end

--------------------- Tab 2: Quest Log Layout ---------------------
local selectedLogQuestId = 0
TrackedQuests = {}
local trackedQuests = TrackedQuests

local logSidebar = CreateFrame("Frame", "QuestLogSidebar", logPanel)
logSidebar:SetSize(130, PANEL_H - 90)
logSidebar:SetPoint("TOPLEFT", logPanel, "TOPLEFT", 0, 0)

local logDetails = CreateFrame("Frame", "QuestLogDetails", logPanel)
logDetails:SetSize(280, PANEL_H - 90)
logDetails:SetPoint("TOPLEFT", logPanel, "TOPLEFT", 140, 0)

local logQuestTitle = logDetails:CreateFontString(nil, "HIGH")
logQuestTitle:SetPoint("TOPLEFT", logDetails, "TOPLEFT", 0, 0)
logQuestTitle:SetSize(280, 20)
logQuestTitle:SetFont(13)
logQuestTitle:SetTextColor(0.88, 0.82, 0.60)
logQuestTitle:SetJustifyH("LEFT")

local logQuestDesc = logDetails:CreateFontString(nil, "HIGH")
logQuestDesc:SetPoint("TOPLEFT", logQuestTitle, "BOTTOMLEFT", 0, -6)
logQuestDesc:SetSize(280, 70)
logQuestDesc:SetFont(10)
logQuestDesc:SetTextColor(0.8, 0.8, 0.8)
logQuestDesc:SetJustifyH("LEFT")

local logQuestObjHeader = logDetails:CreateFontString(nil, "HIGH")
logQuestObjHeader:SetPoint("TOPLEFT", logQuestDesc, "BOTTOMLEFT", 0, -8)
logQuestObjHeader:SetSize(280, 15)
logQuestObjHeader:SetFont(11)
logQuestObjHeader:SetTextColor(0.88, 0.82, 0.60)
logQuestObjHeader:SetText("Objectives Progress:")
logQuestObjHeader:SetJustifyH("LEFT")

local logQuestObjText = logDetails:CreateFontString(nil, "HIGH")
logQuestObjText:SetPoint("TOPLEFT", logQuestObjHeader, "BOTTOMLEFT", 0, -4)
logQuestObjText:SetSize(280, 60)
logQuestObjText:SetFont(10)
logQuestObjText:SetTextColor(0.7, 0.7, 0.7)
logQuestObjText:SetJustifyH("LEFT")

local logQuestRewardsText = logDetails:CreateFontString(nil, "HIGH")
logQuestRewardsText:SetPoint("TOPLEFT", logQuestObjText, "BOTTOMLEFT", 0, -8)
logQuestRewardsText:SetSize(280, 50)
logQuestRewardsText:SetFont(10)
logQuestRewardsText:SetTextColor(0.8, 0.6, 0.95)
logQuestRewardsText:SetJustifyH("LEFT")

-- Action Buttons at the bottom of logDetails: Track, Restart, Abandon
local trackBtn = CreateFrame("Button", "QuestLogTrackBtn", logDetails, "UIPanelButtonTemplate")
trackBtn:SetSize(80, 22)
trackBtn:SetPoint("BOTTOMLEFT", logDetails, "BOTTOMLEFT", 0, 0)
trackBtn:SetText("Track")

local restartBtn = CreateFrame("Button", "QuestLogRestartBtn", logDetails, "UIPanelButtonTemplate")
restartBtn:SetSize(80, 22)
restartBtn:SetPoint("LEFT", trackBtn, "RIGHT", 10, 0)
restartBtn:SetText("Restart")

local abandonBtn = CreateFrame("Button", "QuestLogAbandonBtn", logDetails, "UIPanelButtonTemplate")
abandonBtn:SetSize(80, 22)
abandonBtn:SetPoint("LEFT", restartBtn, "RIGHT", 10, 0)
abandonBtn:SetText("Abandon")

local function refreshTrackButton()
    if selectedLogQuestId > 0 then
        if trackedQuests[selectedLogQuestId] == false then
            trackBtn:SetText("Track")
        else
            trackBtn:SetText("Untrack")
        end
    end
end

trackBtn:SetScript("OnClick", function(self, button)
    if button == "Left" and selectedLogQuestId > 0 then
        if trackedQuests[selectedLogQuestId] == false then
            trackedQuests[selectedLogQuestId] = true
        else
            trackedQuests[selectedLogQuestId] = false
        end
        refreshTrackButton()
    end
end)

restartBtn:SetScript("OnClick", function(self, button)
    if button == "Left" and selectedLogQuestId > 0 then
        C_Quest.RestartQuest(selectedLogQuestId)
    end
end)

abandonBtn:SetScript("OnClick", function(self, button)
    if button == "Left" and selectedLogQuestId > 0 then
        C_Quest.AbandonQuest(selectedLogQuestId)
    end
end)

local function updateLogQuestDetails(questId, prog1, prog2)
    selectedLogQuestId = questId
    if not questId then return end
    local qName, qDesc, obj1_type, obj1_target, obj1_count, obj2_type, obj2_target, obj2_count, rxp, rcoins, ritem, ritem_cnt = C_Quest.GetQuestInfo(questId)
    if not qName then return end

    logQuestTitle:SetText(qName)
    logQuestDesc:SetText(qDesc)

    -- Objectives progress
    local objs = {}
    if obj1_type == 1 then -- KILL
        table.insert(objs, string.format("Slay Foxes: %d / %d", prog1, obj1_count))
    elseif obj1_type == 2 then -- GATHER
        local itemName = GetItemInfo(obj1_target) or "Items"
        local currentCount = 0
        for slot = 1, INVENTORY_SLOTS do
            local id, count = GetInventorySlotInfo(slot)
            if id == obj1_target then
                currentCount = currentCount + count
            end
        end
        table.insert(objs, string.format("Gather %s: %d / %d", itemName, currentCount, obj1_count))
    end
    if obj2_type == 1 then
        table.insert(objs, string.format("Slay Foxes: %d / %d", prog2, obj2_count))
    elseif obj2_type == 2 then
        local itemName = GetItemInfo(obj2_target) or "Items"
        local currentCount = 0
        for slot = 1, INVENTORY_SLOTS do
            local id, count = GetInventorySlotInfo(slot)
            if id == obj2_target then
                currentCount = currentCount + count
            end
        end
        table.insert(objs, string.format("Gather %s: %d / %d", itemName, currentCount, obj2_count))
    end
    if #objs == 0 then
        table.insert(objs, "Speak to the NPC")
    end
    logQuestObjText:SetText(table.concat(objs, "\n"))

    -- Rewards
    local rews = { "Rewards:" }
    if rxp > 0 then table.insert(rews, "  - XP: " .. rxp) end
    if rcoins > 0 then table.insert(rews, "  - Coins: " .. rcoins) end
    if ritem > 0 and ritem_cnt > 0 then
        local rName = GetItemInfo(ritem) or "Item"
        table.insert(rews, "  - Item: " .. ritem_cnt .. "x " .. rName)
    end
    logQuestRewardsText:SetText(table.concat(rews, "\n"))
    
    refreshTrackButton()
end

local function refreshQuestLogPanel()
    local active = C_Quest.GetActiveQuests()
    local numActive = active and #active or 0

    for idx = 1, 6 do
        local btn = _G["QuestLogListBtn" .. idx]
        if not btn then
            btn = CreateFrame("Button", "QuestLogListBtn" .. idx, logSidebar, "UIPanelButtonTemplate")
            btn:SetSize(120, 24)
            btn:SetPoint("TOPLEFT", logSidebar, "TOPLEFT", 0, -(idx - 1) * 28)
            btn:EnableMouse(true)
        end
        if idx <= numActive then
            local qid = active[idx].quest_id
            local p1 = active[idx].progress1
            local p2 = active[idx].progress2
            local name = C_Quest.GetQuestInfo(qid) or "Quest " .. qid
            btn:SetText(name)
            btn:SetScript("OnClick", function(self, button)
                if button == "Left" then
                    updateLogQuestDetails(qid, p1, p2)
                end
            end)
            btn:Show()
        else
            btn:Hide()
        end
    end

    local activeIndex = 1
    if numActive > 0 and selectedLogQuestId > 0 then
        for idx = 1, numActive do
            if active[idx].quest_id == selectedLogQuestId then
                activeIndex = idx
                break
            end
        end
    end

    if numActive > 0 then
        local qid = active[activeIndex].quest_id
        updateLogQuestDetails(qid, active[activeIndex].progress1, active[activeIndex].progress2)
        logQuestTitle:Show()
        logQuestDesc:Show()
        logQuestObjHeader:Show()
        logQuestObjText:Show()
        logQuestRewardsText:Show()
        trackBtn:Show()
        restartBtn:Show()
        abandonBtn:Show()
    else
        selectedLogQuestId = 0
        logQuestTitle:Hide()
        logQuestDesc:Hide()
        logQuestObjHeader:Hide()
        logQuestObjText:Hide()
        logQuestRewardsText:Hide()
        trackBtn:Hide()
        restartBtn:Hide()
        abandonBtn:Hide()
    end
end

-- Tab selection OnClick
charTabBtn:SetScript("OnClick", function(self)
    currentTab = 1
    charPanel:Show()
    logPanel:Hide()
    refreshCharPanel()
end)

questTabBtn:SetScript("OnClick", function(self)
    currentTab = 2
    charPanel:Hide()
    logPanel:Show()
    refreshQuestLogPanel()
end)

-- Key listener for 'L' (keycode 76)
local logDebounce = false
local logPoller = CreateFrame("Frame", "QuestLogKeyPoller", UIParent)
logPoller:SetScript("OnUpdate", function(self, dt)
    local lPressed = IsKeyPressed(76)
    if lPressed and not logDebounce then
        logDebounce = true
        if QuestLogFrame:IsShown() then
            if currentTab == 2 then
                QuestLogFrame:Hide()
            else
                currentTab = 2
                charPanel:Hide()
                logPanel:Show()
                refreshQuestLogPanel()
            end
        else
            QuestLogFrame:Show()
            currentTab = 2
            charPanel:Hide()
            logPanel:Show()
            refreshQuestLogPanel()
        end
    elseif not lPressed then
        logDebounce = false
    end
end)

QuestLogFrame:RegisterEvent("QUEST_STATE_UPDATE")
QuestLogFrame:RegisterEvent("INVENTORY_UPDATE")
QuestLogFrame:SetScript("OnEvent", function(self, event, ...)
    if currentTab == 1 then
        refreshCharPanel()
    else
        refreshQuestLogPanel()
    end
end)

QuestLogFrame:SetScript("OnShow", function(self)
    if currentTab == 1 then
        charPanel:Show()
        logPanel:Hide()
        refreshCharPanel()
    else
        charPanel:Hide()
        logPanel:Show()
        refreshQuestLogPanel()
    end
end)


-------------------------------------------------------------------------------
-- Quest Tracker UI (Side of the Screen)
-------------------------------------------------------------------------------
QuestTrackerFrame = CreateFrame("Frame", "QuestTrackerFrame", UIParent)
QuestTrackerFrame:SetSize(220, 200)
QuestTrackerFrame:SetPoint("TOPRIGHT", MinimapFrame, "BOTTOMRIGHT", -(GLIMMERWOOD_RIGHT_BAR_W or 124), -64)

QuestTrackerFrame:SetScript("OnDraw", function(self)
    local active = C_Quest.GetActiveQuests()
    if not active or #active == 0 then return end

    -- Check if we have any tracked quests
    local hasTracked = false
    for _, aq in ipairs(active) do
        if trackedQuests[aq.quest_id] ~= false then
            hasTracked = true
            break
        end
    end
    if not hasTracked then return end

    local sx, sy, sw, sh = self:GetRect()
    local oy = 0
    
    Draw2D.Text("Active Quests:", sx, sy + oy, 11, 0.88, 0.82, 0.60, 0.95)
    oy = oy + 16

    for idx, aq in ipairs(active) do
        if trackedQuests[aq.quest_id] ~= false then
            local qName, _, obj1_type, obj1_target, obj1_count, obj2_type, obj2_target, obj2_count = C_Quest.GetQuestInfo(aq.quest_id)
            if qName then
                -- Draw quest title
                Draw2D.Text(qName, sx + 4, sy + oy, 10, 0.95, 0.95, 0.95, 0.9)
                oy = oy + 14

                -- Format objective lines
                local lines = {}
                if obj1_type == 1 then
                    table.insert(lines, string.format("   Fox Slayed: %d/%d", aq.progress1, obj1_count))
                elseif obj1_type == 2 then
                    local itemName = GetItemInfo(obj1_target) or "Items"
                    local currentCount = 0
                    for slot = 1, INVENTORY_SLOTS do
                        local id, count = GetInventorySlotInfo(slot)
                        if id == obj1_target then currentCount = currentCount + count end
                    end
                    table.insert(lines, string.format("   Gather %s: %d/%d", itemName, currentCount, obj1_count))
                end
                
                if obj2_type == 1 then
                    table.insert(lines, string.format("   Fox Slayed: %d/%d", aq.progress2, obj2_count))
                elseif obj2_type == 2 then
                    local itemName = GetItemInfo(obj2_target) or "Items"
                    local currentCount = 0
                    for slot = 1, INVENTORY_SLOTS do
                        local id, count = GetInventorySlotInfo(slot)
                        if id == obj2_target then currentCount = currentCount + count end
                    end
                    table.insert(lines, string.format("   Gather %s: %d/%d", itemName, currentCount, obj2_count))
                end
                if #lines == 0 then
                    table.insert(lines, "   Speak to the NPC")
                end

                for _, line in ipairs(lines) do
                    Draw2D.Text(line, sx + 8, sy + oy, 9, 0.75, 0.75, 0.75, 0.85)
                    oy = oy + 12
                end
                oy = oy + 6
            end
        end
    end
end)




