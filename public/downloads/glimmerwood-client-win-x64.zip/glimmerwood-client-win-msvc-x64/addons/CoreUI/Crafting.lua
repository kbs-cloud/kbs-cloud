-------------------------------------------------------------------------------
-- Crafting.lua  (CoreUI)
-- Crafting recipes list, details, and crafting execution.
-------------------------------------------------------------------------------

local CRAFT_W = 300
local CRAFT_H = 500

CraftingFrame = CreateFrame("Frame", "CraftingFrame", UIParent, "BasicPanelTemplate")
CraftingFrame:SetSize(CRAFT_W, CRAFT_H)
CraftingFrame:SetPoint("CENTER", UIParent, "CENTER", -100, 0)
CraftingFrame:SetFrameStrata("DIALOG")
CraftingFrame:SetMovable(true)
CraftingFrame:EnableMouse(true)
CraftingFrame:Hide()

local function addTitle(parent, text)
    local fs = parent:CreateFontString(nil, "HIGH")
    fs:SetPoint("TOPLEFT",  parent, "TOPLEFT",  8, -6)
    fs:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -8, -6)
    fs:SetHeight(18)
    fs:SetFont(15)
    fs:SetJustifyH("CENTER")
    fs:SetTextColor(0.88, 0.82, 0.60)
    fs:SetText(text)
    return fs
end

local function addCloseButton(parent, onClose)
    local btn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    btn:SetSize(22, 22)
    btn:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -4, -4)
    btn:SetText("x")
    btn:EnableMouse(true)
    btn:SetScript("OnClick", onClose)
    return btn
end

addTitle(CraftingFrame, "Crafting Recipes")
addCloseButton(CraftingFrame, function()
    CraftingFrame:Hide()
end)

-- Selected recipe ID (1-based index in recipes DB)
local selectedRecipeIdx = 1

-------------------------------------------------------------------------------
-- Helper: Get count of an item in player inventory
-------------------------------------------------------------------------------
local function GetItemCountInBag(itemId)
    local total = 0
    for s = 1, INVENTORY_SLOTS do
        local id, count = GetInventorySlotInfo(s)
        if id == itemId then
            total = total + count
        end
    end
    return total
end

-------------------------------------------------------------------------------
-- Recipe Detail Panel widgets
-------------------------------------------------------------------------------
local detailPanel = CreateFrame("Frame", "CraftingDetailPanel", CraftingFrame)
detailPanel:SetSize(CRAFT_W - 16, 200)
detailPanel:SetPoint("BOTTOMLEFT", CraftingFrame, "BOTTOMLEFT", 8, 8)

-- Draw a border around the details panel
detailPanel:SetScript("OnDraw", function(self)
    local sx, sy, sw, sh = self:GetRect()
    Draw2D.RectBorder(sx, sy, sw, sh, 1, 0.3, 0.3, 0.35, 0.5)
end)

local detailTitle = detailPanel:CreateFontString(nil, "HIGH")
detailTitle:SetPoint("TOPLEFT", detailPanel, "TOPLEFT", 8, -8)
detailTitle:SetFont(13)
detailTitle:SetTextColor(0.9, 0.85, 0.6)

local detailIngredients = {}
for i = 1, 4 do
    local ing = detailPanel:CreateFontString(nil, "HIGH")
    ing:SetPoint("TOPLEFT", detailPanel, "TOPLEFT", 12, -26 - (i-1)*20)
    ing:SetFont(11)
    detailIngredients[i] = ing
end

local craftBtn = CreateFrame("Button", "CraftItemBtn", detailPanel, "UIPanelButtonTemplate")
craftBtn:SetSize(120, 26)
craftBtn:SetPoint("BOTTOM", detailPanel, "BOTTOM", 0, 10)
craftBtn:SetText("Craft")
craftBtn:EnableMouse(true)

craftBtn:SetScript("OnClick", function()
    local recipeCount = C_Craft.GetRecipeCount()
    if selectedRecipeIdx >= 1 and selectedRecipeIdx <= recipeCount then
        local id, _, _, _, _ = C_Craft.GetRecipeInfo(selectedRecipeIdx)
        if id and C_Craft.CanCraft(id) then
            C_Craft.Craft(id)
        end
    end
end)

-------------------------------------------------------------------------------
-- Recipe List Panel buttons
-------------------------------------------------------------------------------
local recipeButtons = {}
local MAX_VISIBLE_RECIPES = 8

for r = 1, MAX_VISIBLE_RECIPES do
    local btn = CreateFrame("Button", "RecipeBtn" .. r, CraftingFrame, "UIPanelButtonTemplate")
    btn:SetSize(CRAFT_W - 16, 26)
    btn:SetPoint("TOPLEFT", CraftingFrame, "TOPLEFT", 8, -28 - (r-1)*30)
    btn:EnableMouse(true)
    btn.recipeIdx = r

    btn:SetScript("OnClick", function(self)
        selectedRecipeIdx = self.recipeIdx
    end)

    btn:SetScript("OnDraw", function(self)
        local recipeCount = C_Craft.GetRecipeCount()
        if self.recipeIdx <= recipeCount then
            self:Show()
            local id, name, out_id, out_cnt, _ = C_Craft.GetRecipeInfo(self.recipeIdx)
            local canCraft = C_Craft.CanCraft(id)

            local sx, sy, sw, sh = self:GetRect()
            
            -- Selection highlight
            if selectedRecipeIdx == self.recipeIdx then
                Draw2D.Rect(sx + 1, sy + 1, sw - 2, sh - 2, 0.4, 0.4, 0.45, 0.5)
            end

            -- Color code text by canCraft status
            local r, g, b = 0.8, 0.8, 0.8
            if canCraft then
                r, g, b = 0.3, 0.9, 0.3 -- green
            else
                r, g, b = 0.6, 0.6, 0.6 -- muted gray
            end

            local text = string.format("%s (x%d)", name or "?", out_cnt or 1)
            Draw2D.Text(text, sx + 8, sy + sh*0.35, 11, r, g, b, 0.9)
        else
            self:Hide()
        end
    end)

    recipeButtons[r] = btn
end

-------------------------------------------------------------------------------
-- Details Refresh Loop
-------------------------------------------------------------------------------
detailPanel:SetScript("OnUpdate", function()
    local recipeCount = C_Craft.GetRecipeCount()
    if selectedRecipeIdx < 1 or selectedRecipeIdx > recipeCount then
        detailTitle:SetText("No recipe selected")
        for i = 1, 4 do detailIngredients[i]:SetText("") end
        craftBtn:SetText("Craft")
        return
    end

    local id, name, out_id, out_cnt, ing_count = C_Craft.GetRecipeInfo(selectedRecipeIdx)
    if not id then
        detailTitle:SetText("Error loading recipe")
        return
    end

    detailTitle:SetText("Requires:")

    for i = 1, 4 do
        if i <= ing_count then
            local ing_item_id, ing_req = C_Craft.GetRecipeIngredient(id, i)
            if ing_item_id then
                local ing_name, _, _ = GetItemInfo(ing_item_id)
                local current = GetItemCountInBag(ing_item_id)
                local display = string.format("- %s: %d / %d", ing_name or "?", current, ing_req)
                detailIngredients[i]:SetText(display)
                if current >= ing_req then
                    detailIngredients[i]:SetTextColor(0.4, 0.9, 0.4)
                else
                    detailIngredients[i]:SetTextColor(0.9, 0.3, 0.3)
                end
            else
                detailIngredients[i]:SetText("")
            end
        else
            detailIngredients[i]:SetText("")
        end
    end

    local canCraft = C_Craft.CanCraft(id)
    if canCraft then
        craftBtn:SetText("Craft " .. (name or ""))
    else
        craftBtn:SetText("Lacking Materials")
    end
end)

-- NOTE: CraftingFrame is kept available for C_Craft API compatibility.
-- Crafting is now accessed via the Codex (K key) crafting tabs.
-- The standalone P-key binding has been removed.

CraftingFrame:RegisterEvent("INVENTORY_UPDATE")
