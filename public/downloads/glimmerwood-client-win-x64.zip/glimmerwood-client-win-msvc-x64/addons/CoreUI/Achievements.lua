-------------------------------------------------------------------------------
-- Achievements.lua (CoreUI)
-- A robust, beautiful Achievements Panel with search, filtering, categories,
-- collapsible sections, progress bars, and scrolling support.
-------------------------------------------------------------------------------

local PANEL_W = 460
local PANEL_H = 360
local MARGIN  = 12

-- Category definition
local categories = { "General", "Combat", "Exploration" }

local achCategories = {
    glimmerwood_first_login    = "General",
    glimmerwood_gold_hoarder   = "General",
    glimmerwood_craft_item     = "General",
    glimmerwood_kill_fox       = "Combat",
    glimmerwood_full_gear      = "Combat",
    glimmerwood_light_torch    = "Exploration",
    glimmerwood_explore_world  = "Exploration",
}

-- Collapse state per category
local collapsed = {
    General     = false,
    Combat      = false,
    Exploration = false,
}

-- Current active filter: "ALL", "UNLOCKED", "LOCKED"
local currentFilter = "ALL"

-- Search state
local searchQuery = ""
local searchFocused = false

-- Scrolling state
local scrollOffset = 0
local ITEMS_PER_PAGE = 5 -- How many items fit in the scroll area

-- Create achievements window
AchievementsFrame = CreateFrame("Frame", "AchievementsFrame", UIParent, "BasicPanelTemplate")
AchievementsFrame:SetSize(PANEL_W, PANEL_H)
AchievementsFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 30)
AchievementsFrame:SetFrameStrata("HIGH")
AchievementsFrame:Hide()

-- Movable panel setup
AchievementsFrame:SetMovable(true)
AchievementsFrame:EnableMouse(true)
AchievementsFrame:SetScript("OnMouseDown", function(self, button)
    if button == "Left" then
        self:StartMoving()
    end
end)
AchievementsFrame:SetScript("OnMouseUp", function(self, button)
    if button == "Left" then
        self:StopMovingOrSizing()
    end
end)

AchievementsFrame:SetScript("OnUpdate", function(self, dt)

    -- Capture text input for search if focused
    if searchFocused and self:IsShown() then
        -- Blink cursor
        local cursor = (math.floor(GetTime() * 2) % 2 == 0) and "_" or ""
        local dispText = searchQuery
        if dispText == "" then
            dispText = "Search..."
        else
            dispText = dispText .. cursor
        end
        AchievementsSearchText:SetText(dispText)
        if searchQuery == "" then
            AchievementsSearchText:SetTextColor(0.5, 0.5, 0.5)
        else
            AchievementsSearchText:SetTextColor(0.9, 0.9, 0.9)
        end

        local char = GetCharPressed()
        local changed = false
        while char > 0 do
            if char >= 32 and char <= 126 then
                if string.len(searchQuery) < 20 then
                    searchQuery = searchQuery .. string.char(char)
                    changed = true
                end
            end
            char = GetCharPressed()
        end

        if IsKeyPressed(259) then -- Backspace
            if string.len(searchQuery) > 0 then
                searchQuery = string.sub(searchQuery, 1, -2)
                changed = true
            end
        end

        if IsKeyPressed(257) or IsKeyPressed(256) then -- Enter or Escape to unfocus
            searchFocused = false
        end

        if changed then
            scrollOffset = 0
        end
    else
        if AchievementsSearchText then
            if searchQuery == "" then
                AchievementsSearchText:SetText("Search...")
                AchievementsSearchText:SetTextColor(0.5, 0.5, 0.5)
            else
                AchievementsSearchText:SetText(searchQuery)
                AchievementsSearchText:SetTextColor(0.9, 0.9, 0.9)
            end
        end
    end

    -- Scroll Wheel support over the frame
    local wheel = GetMouseWheelMove()
    if wheel ~= 0 and self:IsShown() then
        local _, _, mx, my = self:GetRect()
        local mouseX, mouseY = GetMousePosition()
        -- Only scroll if mouse is over the achievements window
        local x, y, w, h = self:GetRect()
        if mouseX >= x and mouseX <= x + w and mouseY >= y and mouseY <= y + h then
            scrollOffset = scrollOffset - wheel
            if scrollOffset < 0 then scrollOffset = 0 end
            ConsumeMouseWheel()
        end
    end
end)

-- Title
local title = AchievementsFrame:CreateFontString(nil, "HIGH")
title:SetPoint("TOPLEFT", AchievementsFrame, "TOPLEFT", MARGIN, -8)
title:SetPoint("TOPRIGHT", AchievementsFrame, "TOPRIGHT", -MARGIN, -8)
title:SetHeight(20)
title:SetFont(14)
title:SetJustifyH("CENTER")
title:SetTextColor(0.88, 0.82, 0.60)
title:SetText("Achievements")

-- Close Button
local closeBtn = CreateFrame("Button", "AchievementsCloseBtn", AchievementsFrame, "UIPanelButtonTemplate")
closeBtn:SetSize(24, 24)
closeBtn:SetPoint("TOPRIGHT", AchievementsFrame, "TOPRIGHT", -8, -8)
closeBtn:SetScript("OnDraw", function(self)
    local sx, sy, sw, sh = self:GetRect()
    Draw2D.Text("X", sx + 6, sy + 5, 11, 1.0, 0.4, 0.4, 0.95)
end)
closeBtn:SetScript("OnClick", function(self, button)
    if button == "Left" then
        AchievementsFrame:Hide()
        searchFocused = false
    end
end)

-- Filter tabs (All, Unlocked, Locked)
local tabFilters = { "ALL", "UNLOCKED", "LOCKED" }
local filterButtons = {}

for idx, filterName in ipairs(tabFilters) do
    local btn = CreateFrame("Button", "AchievementsTab_" .. filterName, AchievementsFrame, "UIPanelButtonTemplate")
    btn:SetSize(72, 20)
    btn:SetPoint("TOPLEFT", AchievementsFrame, "TOPLEFT", MARGIN + (idx - 1) * 78, -32)
    btn:SetText(filterName:sub(1,1) .. filterName:sub(2):lower())
    btn:SetScript("OnClick", function(self, button)
        if button == "Left" then
            currentFilter = filterName
            scrollOffset = 0
            PlaySoundEffect("click")
        end
    end)
    btn:SetScript("OnUpdate", function(self)
        if currentFilter == filterName then
            self:SetBackdropColor(0.28, 0.35, 0.50, 0.95)
            self:SetBackdropBorderColor(0.60, 0.70, 0.90)
        else
            self:SetBackdropColor(0.14, 0.16, 0.22, 0.85)
            self:SetBackdropBorderColor(0.35, 0.40, 0.50)
        end
    end)
    filterButtons[filterName] = btn
end

-- Search Input Box
local searchBox = CreateFrame("Frame", "AchievementsSearchBox", AchievementsFrame, "BasicPanelTemplate")
searchBox:SetSize(130, 20)
searchBox:SetPoint("TOPRIGHT", AchievementsFrame, "TOPRIGHT", -MARGIN, -32)
searchBox:SetBackdropColor(0.06, 0.06, 0.08, 0.9)
searchBox:SetBackdropBorderColor(0.3, 0.3, 0.35)
searchBox:EnableMouse(true)
searchBox:SetScript("OnMouseDown", function(self, button)
    if button == "Left" then
        searchFocused = true
        PlaySoundEffect("click")
    end
end)

AchievementsSearchText = searchBox:CreateFontString(nil, "HIGH")
AchievementsSearchText:SetPreEscaped(true)
AchievementsSearchText:SetPoint("TOPLEFT", searchBox, "TOPLEFT", 6, -4)
AchievementsSearchText:SetSize(118, 12)
AchievementsSearchText:SetFont(10)
AchievementsSearchText:SetTextColor(0.5, 0.5, 0.5)
AchievementsSearchText:SetText("Search...")
AchievementsSearchText:SetJustifyH("LEFT")

-- Scroll Up/Down Buttons
local scrollUpBtn = CreateFrame("Button", "AchievementsScrollUp", AchievementsFrame, "UIPanelButtonTemplate")
scrollUpBtn:SetSize(20, 20)
scrollUpBtn:SetPoint("TOPRIGHT", AchievementsFrame, "TOPRIGHT", -8, -60)
scrollUpBtn:SetScript("OnDraw", function(self)
    local sx, sy, sw, sh = self:GetRect()
    Draw2D.Text("^", sx + 6, sy + 3, 12, 0.8, 0.8, 0.9, 0.9)
end)
scrollUpBtn:SetScript("OnClick", function(self, button)
    if button == "Left" then
        if scrollOffset > 0 then
            scrollOffset = scrollOffset - 1
            PlaySoundEffect("click")
        end
    end
end)

local scrollDownBtn = CreateFrame("Button", "AchievementsScrollDown", AchievementsFrame, "UIPanelButtonTemplate")
scrollDownBtn:SetSize(20, 20)
scrollDownBtn:SetPoint("BOTTOMRIGHT", AchievementsFrame, "BOTTOMRIGHT", -8, 8)
scrollDownBtn:SetScript("OnDraw", function(self)
    local sx, sy, sw, sh = self:GetRect()
    Draw2D.Text("v", sx + 6, sy + 5, 10, 0.8, 0.8, 0.9, 0.9)
end)
scrollDownBtn:SetScript("OnClick", function(self, button)
    if button == "Left" then
        scrollOffset = scrollOffset + 1
        PlaySoundEffect("click")
    end
end)

-- Main rendering OnDraw
AchievementsFrame:SetScript("OnDraw", function(self)
    local x, y, w, h = self:GetRect()
    
    -- Verify if logged in
    if not C_Achievement.GetNumAchievements or C_Achievement.GetNumAchievements() == 0 then
        Draw2D.Text("Not logged in or achievements loading...", x + 40, y + 150, 12, 0.8, 0.4, 0.4, 0.9)
        return
    end

    local numAchs = C_Achievement.GetNumAchievements()
    local achList = {}
    local totalXP = 0
    local earnedXP = 0
    local totalCompleted = 0

    -- Categorized progress counters
    local catTotal = { General = 0, Combat = 0, Exploration = 0 }
    local catCompleted = { General = 0, Combat = 0, Exploration = 0 }

    for i = 1, numAchs do
        local info = C_Achievement.GetAchievementInfo(i)
        if info then
            local cat = achCategories[info.id] or "General"
            catTotal[cat] = catTotal[cat] + 1
            totalXP = totalXP + info.xpValue
            
            if info.unlocked then
                catCompleted[cat] = catCompleted[cat] + 1
                earnedXP = earnedXP + info.xpValue
                totalCompleted = totalCompleted + 1
            end

            -- Match active filters and search query
            local matchFilter = true
            if currentFilter == "UNLOCKED" and not info.unlocked then
                matchFilter = false
            elseif currentFilter == "LOCKED" and info.unlocked then
                matchFilter = false
            end

            local matchSearch = true
            if searchQuery ~= "" then
                local term = searchQuery:lower()
                local titleMatch = info.title:lower():find(term, 1, true)
                local descMatch = info.description:lower():find(term, 1, true)
                if not titleMatch and not descMatch then
                    matchSearch = false
                end
            end

            if matchFilter and matchSearch then
                info.category = cat
                table.insert(achList, info)
            end
        end
    end

    -- Draw summary points at the top-right (above search box / title row)
    local summaryStr = string.format("Completed: %d/%d (%d XP)", totalCompleted, numAchs, earnedXP)
    Draw2D.Text(summaryStr, x + PANEL_W - 190, y + 10, 10, 0.8, 0.8, 0.6, 0.9)

    -- Build visual list containing category headers and matching achievements
    local renderList = {}
    
    for _, catName in ipairs(categories) do
        -- Check if any achievement in this category matches the filters
        local hasItems = false
        for _, info in ipairs(achList) do
            if info.category == catName then
                hasItems = true
                break
            end
        end

        if hasItems or searchQuery == "" then
            table.insert(renderList, {
                isHeader = true,
                title = catName,
                total = catTotal[catName],
                completed = catCompleted[catName]
            })
            
            if not collapsed[catName] then
                for _, info in ipairs(achList) do
                    if info.category == catName then
                        table.insert(renderList, info)
                    end
                end
            end
        end
    end

    -- Constrain scroll offset
    local maxScroll = math.max(0, #renderList - ITEMS_PER_PAGE)
    if scrollOffset > maxScroll then
        scrollOffset = maxScroll
    end

    -- Show/hide scroll buttons
    if maxScroll > 0 then
        scrollUpBtn:Show()
        scrollDownBtn:Show()
    else
        scrollUpBtn:Hide()
        scrollDownBtn:Hide()
    end

    -- Render the visible items
    local startY = y + 62
    local itemH = 54
    
    for i = 1, ITEMS_PER_PAGE do
        local listIdx = scrollOffset + i
        local item = renderList[listIdx]
        if not item then break end

        local itemY = startY + (i - 1) * itemH
        
        if item.isHeader then
            -- Draw Collapsible Category Header
            local hover = false
            local mx, my = GetMousePosition()
            if mx >= x + 12 and mx <= x + PANEL_W - 36 and my >= itemY and my <= itemY + 24 then
                hover = true
            end

            -- Click to toggle collapse
            if hover and IsMouseButtonPressed(0) then
                collapsed[item.title] = not collapsed[item.title]
                PlaySoundEffect("click")
            end

            -- Background box
            local bgColor = hover and { 0.22, 0.25, 0.35, 0.85 } or { 0.12, 0.14, 0.18, 0.8 }
            Draw2D.Rect(x + 12, itemY, PANEL_W - 48, 24, bgColor[1], bgColor[2], bgColor[3], bgColor[4])
            Draw2D.RectBorder(x + 12, itemY, PANEL_W - 48, 24, 1, 0.3, 0.35, 0.45, 0.6)

            -- Collapse arrow
            local arrow = collapsed[item.title] and ">" or "v"
            Draw2D.Text(arrow, x + 20, itemY + 6, 11, 0.9, 0.85, 0.6, 0.9)

            -- Category Title
            Draw2D.Text(item.title, x + 36, itemY + 6, 11, 0.9, 0.85, 0.6, 0.9)

            -- Progress Bar & text
            local pct = item.total > 0 and (item.completed / item.total) or 0
            local barW = 120
            local barX = x + PANEL_W - 176
            Draw2D.Rect(barX, itemY + 7, barW, 10, 0.05, 0.05, 0.05, 0.9)
            Draw2D.Rect(barX + 1, itemY + 8, math.floor((barW - 2) * pct), 8, 0.25, 0.55, 0.25, 0.9)
            Draw2D.RectBorder(barX, itemY + 7, barW, 10, 1, 0.3, 0.3, 0.35, 0.7)

            local progStr = string.format("%d/%d", item.completed, item.total)
            Draw2D.Text(progStr, barX - 42, itemY + 6, 9, 0.8, 0.8, 0.8, 0.9)
        else
            -- Draw Achievement List Item
            local ach = item
            local hover = false
            local mx, my = GetMousePosition()
            if mx >= x + 12 and mx <= x + PANEL_W - 36 and my >= itemY and my <= itemY + itemH - 4 then
                hover = true
            end

            -- Draw Card Background
            local bgR, bgG, bgB, bgA = 0.08, 0.09, 0.12, 0.7
            if ach.unlocked then
                bgR, bgG, bgB, bgA = 0.10, 0.14, 0.12, 0.85
            end
            if hover then
                bgA = bgA + 0.1
            end
            Draw2D.Rect(x + 12, itemY, PANEL_W - 48, itemH - 4, bgR, bgG, bgB, bgA)
            
            local borderR, borderG, borderB = 0.25, 0.25, 0.3
            if ach.unlocked then
                borderR, borderG, borderB = 0.35, 0.65, 0.35
            end
            Draw2D.RectBorder(x + 12, itemY, PANEL_W - 48, itemH - 4, 1, borderR, borderG, borderB, 0.5)

            -- Draw Icon Box
            Draw2D.Rect(x + 18, itemY + 6, 36, 36, 0.05, 0.05, 0.06, 0.9)
            Draw2D.RectBorder(x + 18, itemY + 6, 36, 36, 1, borderR, borderG, borderB, 0.4)
            -- Render Icon (Emoji)
            local iconStr = ach.icon or "🏆"
            Draw2D.Text(iconStr, x + 24, itemY + 12, 18, 1.0, 1.0, 1.0, 0.9)

            -- Text Details (Title, Description)
            local titleColor = ach.unlocked and { 0.85, 0.95, 0.85 } or { 0.65, 0.65, 0.68 }
            Draw2D.Text(ach.title, x + 62, itemY + 8, 11, titleColor[1], titleColor[2], titleColor[3], 0.95)
            
            local descStr = ach.description
            if #descStr > 55 then
                descStr = descStr:sub(1, 52) .. "..."
            end
            Draw2D.Text(descStr, x + 62, itemY + 26, 8, 0.55, 0.55, 0.58, 0.9)

            -- Reward XP Badge
            local xpStr = string.format("+%d XP", ach.xpValue)
            Draw2D.Text(xpStr, x + PANEL_W - 104, itemY + 8, 9, 0.9, 0.75, 0.3, 0.9)

            -- Status Date/Lock
            if ach.unlocked then
                local dateStr = "Completed!"
                if ach.unlockedAt and ach.unlockedAt ~= "" then
                    -- Format simple Date ISO string substring "YYYY-MM-DD"
                    dateStr = ach.unlockedAt:sub(1, 10)
                end
                Draw2D.Text(dateStr, x + PANEL_W - 104, itemY + 26, 8, 0.5, 0.8, 0.5, 0.85)
            else
                Draw2D.Text("Locked", x + PANEL_W - 104, itemY + 26, 8, 0.6, 0.6, 0.6, 0.7)
            end
        end
    end
end)
