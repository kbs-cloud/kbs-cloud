-------------------------------------------------------------------------------
-- MyAddon.lua  (ExampleAddon)
--
-- A self-contained reference addon demonstrating the full glimmerwood Lua API:
--   • CreateFrame / templates
--   • Event registration and handling
--   • OnUpdate with a dt accumulator
--   • OnDraw with Draw2D primitives
--   • Querying game state (HP, position, tile, inventory)
--   • Reacting to entity deaths
--
-- This file is intentionally verbose and commented — it is meant to be read
-- and copied when writing new addons.
-------------------------------------------------------------------------------

local ADDON_NAME    = "ExampleAddon"
local ADDON_VERSION = "1.0"

print(string.format("[%s v%s] Loading...", ADDON_NAME, ADDON_VERSION))

-------------------------------------------------------------------------------
-- § 1  Small info overlay  (top-left, below any engine debug text)
--
--   Shows: player HP/max, world position, current tile
--   Text colour: green (healthy) → yellow (wounded) → red (critical)
--   Border: pulses red when HP < 30 %
-------------------------------------------------------------------------------

-- (infoFrame has been merged into CoreUI's PlayerFrame)

-------------------------------------------------------------------------------
-- § 3  Mini entity counter overlay  (top-left, below PlayerFrame)
--
-- Counts alive entities by kind and displays a summary.
-- Only visible when debug mode is enabled (F3).
-------------------------------------------------------------------------------
local counterFrame = CreateFrame("Frame", "ExampleCounterFrame", UIParent,
                                 "BasicPanelTemplate")
counterFrame:SetSize(220, 70)
counterFrame:SetPoint("TOPLEFT", PlayerFrame, "BOTTOMLEFT", 0, -6)
counterFrame:SetFrameStrata("LOW")
counterFrame:Hide() -- Hide by default

local counterLabel = counterFrame:CreateFontString(nil, "HIGH")
counterLabel:SetPoint("TOPLEFT",     counterFrame, "TOPLEFT",     8, -6)
counterLabel:SetSize(204, 58)
counterLabel:SetFont(12)
counterLabel:SetJustifyH("LEFT")
counterLabel:SetTextColor(0.80, 0.85, 0.80)
counterLabel:SetText("Entities: counting...")

-- Throttle entity iteration to twice per second (it touches 1 024 entities)
local entityAccum    = 0.0
local ENTITY_INTERVAL = 0.5

counterFrame:SetScript("OnUpdate", function(self, dt)
    local debugMode = GetDebugMode()
    if not debugMode then
        if self:IsShown() then self:Hide() end
        return
    else
        if not self:IsShown() then self:Show() end
    end

    entityAccum = entityAccum + dt
    if entityAccum < ENTITY_INTERVAL then return end
    entityAccum = 0

    local counts = { rabbit = 0, chicken = 0, fox = 0,
                     container = 0, loot = 0, player = 0 }
    local total = 0

    for i = 0, MAX_ENTITIES - 1 do
        local kind, _, _, _, alive = GetEntityInfo(i)
        if alive then
            total = total + 1
            if counts[kind] ~= nil then
                counts[kind] = counts[kind] + 1
            end
        end
    end

    counterLabel:SetText(string.format(
        "Alive: %d  Foxes: %d\nRabbits: %d  Chickens: %d\nLoot: %d  Chests: %d",
        total, counts.fox,
        counts.rabbit, counts.chicken,
        counts.loot, counts.container
    ))
end)

-------------------------------------------------------------------------------
-- § 4  Template inheritance demonstration
--
-- Create a button using "UIPanelButtonTemplate" and attach a click handler.
-- The button prints a greeting and shows current inventory item count.
-------------------------------------------------------------------------------
local demoBtn = CreateFrame("Button", "ExampleDemoButton", counterFrame,
                            "UIPanelButtonTemplate")
demoBtn:SetSize(130, 28)
demoBtn:SetPoint("TOPLEFT", counterFrame, "BOTTOMLEFT", 0, -6)
demoBtn:SetText("Count Items")
demoBtn:EnableMouse(true)
demoBtn:SetFrameStrata("MEDIUM")

demoBtn:SetScript("OnClick", function()
    local itemCount = 0
    for s = 1, INVENTORY_SLOTS do
        local itemId, count = GetInventorySlotInfo(s)
        if itemId and itemId > 0 and itemId ~= 30 then
            itemCount = itemCount + count
        end
    end
    print(string.format("[%s] You are carrying %d item(s).", ADDON_NAME, itemCount))
end)

-------------------------------------------------------------------------------
-- § 5  Convenience global — other addons can call this to see if ExampleAddon
--      is loaded.  A common game UI pattern.
-------------------------------------------------------------------------------
ExampleAddon = {
    version = ADDON_VERSION,
    name    = ADDON_NAME,
}

function ExampleAddon:IsLoaded()
    return true
end

-------------------------------------------------------------------------------
print(string.format("[%s v%s] Loaded.  Press I to open inventory.",
                    ADDON_NAME, ADDON_VERSION))
