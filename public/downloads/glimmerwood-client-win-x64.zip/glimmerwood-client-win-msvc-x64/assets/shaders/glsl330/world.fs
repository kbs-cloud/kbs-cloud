#version 330

in vec3 fragPosition;
in vec2 fragTexCoord;
in vec4 fragColor;
in vec3 fragNormal;

uniform sampler2D texture0;
uniform vec4 colDiffuse;

out vec4 finalColor;

// Lighting: one directional "sun" (no falloff) plus one point "torch" that the
// player carries when a light item is equipped. Kept deliberately simple — flat
// Lambert + ambient, no specular/gamma, so pixel-art texel colors stay crisp.
uniform vec3  ambient;     // base light everywhere (raised by day, low at night)
uniform vec3  sunDir;      // direction TOWARD the sun (normalized)
uniform vec3  sunColor;

#define MAX_LIGHTS 16
uniform int   lightCount;
uniform vec3  lightPos[MAX_LIGHTS];
uniform vec3  lightColor[MAX_LIGHTS];
uniform float lightRange[MAX_LIGHTS];

void main()
{
    vec4 texel = texture(texture0, fragTexCoord);
    vec4 tint  = colDiffuse*fragColor;
    vec3 n     = normalize(fragNormal);

    vec3 light = ambient;

    // Directional sun/moon.
    float sd = max(dot(n, normalize(sunDir)), 0.0);
    light += sunColor*sd;

    // Point torches with smooth distance falloff.
    for (int i = 0; i < lightCount; i++)
    {
        if (i >= MAX_LIGHTS) break;
        vec3 L     = lightPos[i] - fragPosition;
        float dist = length(L);
        float ndl  = max(dot(n, normalize(L)), 0.0);
        float att  = clamp(1.0 - dist/lightRange[i], 0.0, 1.0);
        att *= att;
        light += lightColor[i]*ndl*att;
    }

    vec3 col   = texel.rgb*tint.rgb*light;
    finalColor = vec4(col, texel.a*tint.a);
}
