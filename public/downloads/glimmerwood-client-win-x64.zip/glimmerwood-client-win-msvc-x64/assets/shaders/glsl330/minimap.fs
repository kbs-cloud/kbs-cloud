#version 330

// Input vertex attributes (from vertex shader)
in vec2 fragTexCoord;
in vec4 fragColor;

// Input uniform values
uniform sampler2D texture0;
uniform vec4 colDiffuse;

// Output fragment color
out vec4 finalColor;

void main()
{
    // Texture coordinates range from 0 to 1 across the render texture.
    // Center is (0.5, 0.5).
    vec2 uv = fragTexCoord - vec2(0.5);
    
    // Circle clipping: check if distance squared is greater than 0.25 (r^2 for r=0.5)
    float distSq = dot(uv, uv);
    if (distSq > 0.246) {
        discard;
    }
    
    // Fetch texture pixel
    vec4 texel = texture(texture0, fragTexCoord);
    finalColor = texel * fragColor * colDiffuse;
}
